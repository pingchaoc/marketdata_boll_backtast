# -*- coding: utf-8 -*-
"""
@author: QuantInfoTech
"""

from finonelib.interface.api import submit_orders, create_order
from finonelib.interface.exchange import on_cancel_rejected
from finonelib.interface.exchange import on_order_cancelled
from finonelib.interface.exchange import on_order_executed
from finonelib.interface.exchange import on_order_partial_executed
from finonelib.interface.exchange import on_receive_marketdata
from finonelib.interface.exchange import on_receive_heartbeat
from finonelib.interface.exchange import on_receive_transaction
from finonelib.interface.exchange import on_submit_accepted
from finonelib.interface.exchange import on_submit_rejected
from finonelib.state import state, ExecutorParams
from finonelib.structs import ClobData
from finonelib.structs import ExecutedTrade
from finonelib.structs import Execution
from finonelib.structs import ExecutionStatus
from finonelib.structs import Order
from finonelib.structs import OrderAction
from finonelib.structs import OrderOwnership
from finonelib.structs import OrderSide
from finonelib.structs import OrderType
from finonelib.structs import Repository


class Strategy(object):
    bid_qty = 1
    ask_qty = 1

    def on_receive_marketdata(self, marketdata: ClobData):
        best_bid_price = marketdata.p_bid_array[0]
        bid_order = create_order(marketdata.symbol, OrderType.LIMIT, OrderSide.BID, best_bid_price, self.bid_qty)
        best_ask_price = marketdata.p_ask_array[0]
        ask_order = create_order(marketdata.symbol, OrderType.LIMIT, OrderSide.ASK, best_bid_price, self.ask_qty)
        submit_orders([bid_order, ask_order])

    def on_receive_transaction(self, trade: ExecutedTrade):
        pass

    def on_submit_accepted(self, execution: Execution):
        pass

    def on_submit_rejected(self, execution: Execution):
        pass

    def on_cancel_rejected(self, execution: Execution):
        pass

    def on_order_partial_executed(self, execution: Execution):
        pass

    def on_order_executed(self, execution: Execution):
        pass

    def on_order_cancelled(self, execution: Execution):
        pass

    def on_receive_heartbeat(self, timestamp: int):
        pass


# 这一行应该被CPP plugin调用
state.apama_initialize(Strategy, {'bid_qty': 20, 'ask_qty': 20})