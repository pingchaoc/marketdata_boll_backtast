from finonelib.interface.api import *
from finonelib import *
del globals()['logger']
import numpy as np
import pandas as pd
import time

class Strategy(object):
    bid_qty = 1
    ask_qty = 1
    marketdata_counter = 0
    cancelled_counter = 0

    submited_in_cancel = 0
    submited_in_marketdata = 0

    def on_receive_marketdata(self, marketdata: ClobData):
        # print(f'on receive marketdata {time.time()}, pendings {len(get_my_pending_orders(marketdata.symbol))}')
        self.marketdata_counter += 1
        print(f'marketdata: {self.marketdata_counter}')
        # logger.warning('on_receive_marketdata')
        pending_orders = get_my_pending_orders(marketdata.symbol)
        print(f'pending bid: {len([order for order in pending_orders if order.side == OrderSide.BID])}')
        print(f'pending ask: {len([order for order in pending_orders if order.side == OrderSide.ASK])}')
        if pending_orders:
            for order in pending_orders:
                if order.side == OrderSide.BID:
                    if order.price != get_best_bid_price(marketdata.symbol):
                        cancel_orders(order)
                elif order.side == OrderSide.ASK:
                    if order.price != get_best_ask_price(marketdata.symbol):
                        cancel_orders(order)
            # cancel_orders(pending_orders)
        else:
            if marketdata.p_bid_array:
                best_bid = marketdata.p_bid_array[0]
                bid_order = create_order(marketdata.symbol, OrderType.LIMIT,OrderSide.BID, best_bid, self.bid_qty)
                submit_orders(bid_order)
            if marketdata.p_ask_array:
                best_ask = marketdata.p_ask_array[0]
                ask_order = create_order(marketdata.symbol, OrderType.LIMIT, OrderSide.ASK, best_ask, self.ask_qty)
                submit_orders(ask_order)
            self.submited_in_marketdata += 1
            print(f'submited in marketdata: {self.submited_in_marketdata}')
        pass

    def on_receive_transaction(self, trade: ExecutedTrade):
        pass

    def on_submit_accepted(self, execution: Execution):
        pass

    def on_submit_rejected(self, execution: Execution):
        # logger.warning('on_submit_rejected')
        pass

    def on_cancel_rejected(self, execution: Execution):
        # logger.warning('on_cancel_rejected')
        pass

    def on_order_partial_executed(self, execution: Execution):
        # logger.warning('on_order_partial_executed')
        pass

    def on_order_executed(self, execution: Execution):
        pass

    def on_order_cancelled(self, execution: Execution):
        self.cancelled_counter += 1
        print(f'cancelled: {self.cancelled_counter}')
        # logger.warning(f'on_order_cancelled: {execution.order_id}')
        pending_orders = get_my_pending_orders(get_symbol('marketdata'))
        if not pending_orders:
            marketdata = get_marketdata(execution.symbol, 0)
            if marketdata.p_bid_array:
                best_bid = marketdata.p_bid_array[0]
                bid_order = create_order(marketdata.symbol, OrderType.LIMIT,OrderSide.BID, best_bid, self.bid_qty)
                submit_orders(bid_order)
            if marketdata.p_ask_array:
                best_ask = marketdata.p_ask_array[0]
                ask_order = create_order(marketdata.symbol, OrderType.LIMIT,OrderSide.ASK, best_ask, self.ask_qty)
                submit_orders(ask_order)
            self.submited_in_cancel += 1
            print(f'submited in cancel: {self.submited_in_cancel}')
        pass

    def on_receive_status_update(self, repository: Repository):
        pass

    def on_receive_heartbeat(self, timestamp: int):
        pass

    def custom_settings(self):
        return {}

    def init_econ_data(self):
        return []
