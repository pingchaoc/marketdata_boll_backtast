# -*- coding: utf-8 -*-
"""
@author: QuantInfoTech
"""
import typeguard
from typing import Callable
import os
def pass_typechecked(func: Callable = None, *, always: bool = False):
    return func
# bypass typechecked to guarantee a quick performance
typeguard.typechecked = pass_typechecked

from pyspark import SparkConf, SparkContext
from pyspark.sql import HiveContext

__conf = SparkConf().setAppName('{{ STRATEGY_NAME }}_{{ BACKTEST_NAME }}_{{ RECORD_ID }}')
__conf.set('spark.task.maxFailures', 0)
__conf.set('spark.memory.fraction', 0.1)
__sc__ = SparkContext(conf=__conf)


import inspect
import requests


{{ BACKTESTPATTERN }}

TIME_ZONE = 'Asia/Shanghai'

{{ STRATEGY }}


os.environ['TZ'] = TIME_ZONE


all_params = {{ALL_PARAMS}}


settings = {
    'START_TIME': {{ START_TIME }},
    'END_TIME': {{ END_TIME }},
    'STRATEGY_NAME': '{{ STRATEGY_NAME }}',
    'BACKTEST_NAME': '{{ BACKTEST_NAME }}',
    'HADOOP_MASTER_HOST': "{{ HADOOP_MASTER_HOST }}",
    'HADOOP_IMPALA_HOST': "{{ HADOOP_IMPALA_HOST }}",
    'HADOOP_WORKER_HOSTS': {{ HADOOP_WORKER_HOSTS }},
    'STRATEGY_FILE_HDFS_PATH': "{{ STRATEGY_FILE_HDFS_PATH }}",
    'SPARK_KEY': "{{ SPARK_KEY }}",
    'PERFORMANCE': {{ PERFORMANCE }},
    'SERVER_HOST': "{{ SERVER_HOST }}",
    'RECORD_ID': '{{ RECORD_ID }}',
    'USER_TOKEN': "{{ USER_TOKEN }}",
    'LOG_LEVEL': "{{ LOG_LEVEL }}",
    'DATASOURCE': 'hadoop',
    'OUTPUT_REPORT': True,
    'SPARK_REDIS_HOST': "{{ REDIS_HOST }}",
    'SPARK_REDIS_PORT': "{{ REDIS_PORT }}",
    'SPARK_REDIS_DB': {{ REDIS_DB }},
    'SEND_MATCH_INFO': {{ SEND_MATCH_INFO }},
    'PRECISION': {},
    'MARKETDATA_INTERVAL': 5000, # in ms, 5seconds
    'ORDER_DELAY': 5, # in ms
    'SEND_MARKETDATA_PERIODICALLY': True, # to or not to send marketdata every MARKETDATA_INTERVAL
    'SPARK': True,
    'DEBUG': False,
    'SEND_HEARTBEAT': True,
    'HEARTBEAT_INTERVAL': 3600000,
    'METADATA': {{ METADATA }},
    'REPORTING_CURRENCY': '{{ REPORTING_CURRENCY }}',
    'TIME_ZONE': TIME_ZONE,
    'EXPORT_PARAMS': {{ EXPORT_PARAMS }}
}


def __start():
    # change the status
    import time
    st = time.time() * 1000
    print(f'[TEST] __start start_ts: {st}')

    for _ in range(3):
        res = requests.post(f'{{SERVER_HOST}}/api/v1/backtest/record/status_update',
                            data={'record_id': '{{ RECORD_ID }}', 'spark_key': "{{ SPARK_KEY }}"},
                            headers={"Accept": "application/json"}).json()

        if res['success']:
            print('[INFO]: PROCESS START, SERVER UPDATE SUCCEED !')
            break
        else:
            print('[INFO]: PROCESS START, SERVER UPDATE FAILED , RETRY !!!')
            
    try:
        paramsRDD = __sc__.parallelize(all_params)
        collect_result = paramsRDD.map(__process).collect()
        for process_ret in collect_result:
            if process_ret[0] == False:
                raise process_ret[1]
        # send msg PROCESS SUCCESS
        res = requests.post(f'{{SERVER_HOST}}/api/v1/backtest/strategy/run_return',
                           data={'record_id': '{{ RECORD_ID }}', 'spark_key': "{{ SPARK_KEY }}", 'spark_status': 'SUCCESSED'},
                           headers={"Accept": "application/json"}).json()

        if not res['success']:
            print('[ERROR]: PROCESS SUCCESS, SERVER UPDATE FAILED !')
        else:
            print('[INFO]: PROCESS SUCCESS, SERVER UPDATE SUCCEED !')
    except Exception as e:
        # send msg PROCESS FAIL
        res = requests.post(f'{{SERVER_HOST}}/api/v1/backtest/strategy/run_return',
                            data={'record_id': '{{ RECORD_ID }}', 'spark_key': "{{ SPARK_KEY }}",
                                  'spark_status': 'FAILED'},
                            headers={"Accept": "application/json"}).json()
        if not res['success']:
            print('[ERROR]: PROCESS FAILED, SERVER UPDATE FAILED !')
        else:
            print('[INFO]: PROCESS FAILED, SERVER UPDATE SUCCEED !')
    print(f'[TEST] __start end_ts: {time.time() * 1000 - st}')

def __process(param):
    import time
    st = time.time() * 1000
    print(f'[TEST] {param} __process start_ts: {st}')
    import typeguard
    from typing import Callable
    import os
    def pass_typechecked(func: Callable = None, *, always: bool = False):
        return func
    os.environ['TZ'] = settings['TIME_ZONE']
    # bypass typechecked to guarantee a quick performance
    typeguard.typechecked = pass_typechecked
    from finonelib.async_backtest import start_backtest
    from finonelib.state import state, ExecutorParams

    file_cls = Strategy if 'Strategy' in globals() else Script

    settings['RESULT_ID'] = param[0]
    settings['ORDER_TABLE'] = param[1]['symbol_dataset_detail']['symbol_table']
    settings['SYMBOL_TIME_TYPE'] = param[1]['symbol_dataset_detail']['symbol_time_type']
    strategy_params = param[1]['strategy_params']
    if '__no_strategy_param__' in strategy_params:
        strategy_params = {}
    pattern_params = param[1]['pattern_params']
    if '__no_pattern_param__' in pattern_params:
        pattern_params = {}
    args = inspect.getfullargspec(file_cls.on_receive_marketdata).args
    if args[0] == 'self':
        del args[0]
    symbols = [param[1]['symbol_dataset_detail']['param_symbol'][k] for k in args]
    params = ExecutorParams(strategy_params=strategy_params, pattern_params=pattern_params)
    
    state.initialize(file_cls,
                     BackTestPattern,
                     symbols=symbols,
                     params=params,
                     settings=settings)
    start_backtest()
    requests.post(url=settings['SERVER_HOST'] + '/api/v1/backtest/strategy/result_return',
                        data={'record_id': settings['RECORD_ID'], 'result_id': settings['RESULT_ID']})
    print(f'[TEST] {param} __process end_ts: {time.time() * 1000 - st}')
    return True, None


if __name__ == '__main__':
    __start()
