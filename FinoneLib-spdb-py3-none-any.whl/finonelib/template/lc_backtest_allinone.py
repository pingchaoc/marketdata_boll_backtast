# -*- coding: utf-8 -*-
"""
@author: QuantInfoTech
"""

from finonelib.async_backtest import start_backtest
from finonelib.interface.api import filter_cancel_rejected
from finonelib.interface.api import filter_order_cancelled
from finonelib.interface.api import filter_order_executed
from finonelib.interface.api import filter_order_partial_executed
from finonelib.interface.api import filter_receive_transaction
from finonelib.interface.api import filter_submit_accepted
from finonelib.interface.api import filter_submit_rejected
from finonelib.interface.api import submit_orders, create_order
from finonelib.interface.exchange import BaseBackTestPattern
from finonelib.interface.exchange import fetch_orders
from finonelib.interface.exchange import on_cancel_rejected
from finonelib.interface.exchange import on_order_cancelled
from finonelib.interface.exchange import on_order_executed
from finonelib.interface.exchange import on_order_partial_executed
from finonelib.interface.exchange import on_receive_marketdata
from finonelib.interface.exchange import on_receive_heartbeat
from finonelib.interface.exchange import on_receive_transaction
from finonelib.interface.exchange import on_submit_accepted
from finonelib.interface.exchange import on_submit_rejected
from finonelib.interface.exchange import create_execution_from_order
from finonelib.interface.exchange import read_symbol_ohlc
from finonelib.interface.exchange import current_timestamp
from finonelib.methods import limit_orders_to_clob
from finonelib.methods import clob_to_limit_orders
from finonelib.match import DefaultLCMatcher
from finonelib.state import state, ExecutorParams
from finonelib.structs import ClobData
from finonelib.structs import OHLCData
from finonelib.structs import ExecutedTrade
from finonelib.structs import Execution
from finonelib.structs import ExecutionStatus
from finonelib.structs import Order
from finonelib.structs import OHLCOrderUpdater
from finonelib.structs import OrderAction
from finonelib.structs import OrderOwnership
from finonelib.structs import OrderSide
from finonelib.structs import OrderType
from finonelib.structs import Repository
import time
import random
from datetime import datetime


class BackTestPattern(BaseBackTestPattern):
    SLIPPAGE = 5
    MIN_MOVE = 0.00001
    SPREAD = 0.005

    def __init__(self):
        self.symbol_matchers = {}
        self.last_clob = None

    def generate_orders(self, symbol: str):
        print('BackTestPattern start generate orders')
        for timestamp, order in read_symbol_ohlc(symbol):
            yield order

    def match(self, symbol: str, order):
        if not symbol in self.symbol_matchers:
            self.symbol_matchers[symbol] = DefaultLCMatcher(symbol, slippage=self.SLIPPAGE, min_move=self.MIN_MOVE, spread=self.SPREAD)
        return self.symbol_matchers[symbol].match(order)

    def finalize(self):
        print('Data playback complete, calculating performance metrics.')


class Strategy(object):

    def on_receive_marketdata(self, marketdata: ClobData):
        print(marketdata)
        pass

    def on_receive_ohlc(self, ohlc: OHLCData):
        pass

    def on_receive_transaction(self, trade: ExecutedTrade):
        pass

    def on_submit_accepted(self, execution: Execution):
        pass

    def on_submit_rejected(self, execution: Execution):
        pass

    def on_cancel_rejected(self, execution: Execution):
        pass

    def on_order_partial_executed(self, execution: Execution):
        pass

    def on_order_executed(self, execution: Execution):
        pass

    def on_order_cancelled(self, execution: Execution):
        pass

    def custom_settings(self):
        return {}

def parse_settings(path):
    return {
        'START_TIME': 1540136330000,
        'END_TIME': 1544173090000,
        'HADOOP_MASTER_HOST': 'master.hadoop.com',
        'HADOOP_IMPALA_HOST': 'worker.hadoop.com',
        'HADOOP_WORKER_HOSTS': ['worker.hadoop.com'],
        'STRATEGY_FILE_HDFS_PATH': '/user/admin',
        'SPARK_KEY': 'spark_key',
        'PERFORMANCE': ['max_drawdown'],
        'SERVER_HOST': 'localhost',
        'RECORD_ID': '100',
        'USER_TOKEN': '00000000-0000-0000-0000-000000000000',
        'LOG_LEVEL': 'strategy',
        'ORDER_TABLE': {
            'USDJPY': 'default.usdjpy_1min',
        },
        'DATASOURCE': 'local',
        'LOCAL_DATA_PATH': {
            'USDJPY': './usdjpy_1min.csv',
        },
        'SPARK': True,
        'STRATEGY_NAME': 'Top',
        'BACKTEST_NAME': 'LocalHs',
        'RESULT_ID': 0,
        'OUTPUT_REPORT': True,
        # 'PLAY_SPEED': 1
        'MARKETDATA_INTERVAL': 60000,
        'SEND_MATCH_INFO': True,
        'SPARK_REDIS_HOST': "127.0.0.1",
        'SPARK_REDIS_PORT': "6379",
        'SPARK_REDIS_DB': 4
    }

def load_strategy(script):
    def load_module():
        import importlib.util
        spec = importlib.util.spec_from_file_location('__strategy__', script)
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        return m

    def get_strategy(m):
        import inspect
        all_clazz = inspect.getmembers(m, inspect.isclass)
        all_strategies = [cls for (_, cls) in all_clazz if cls.__module__ == '__strategy__']
        if len(all_strategies) == 0:
            raise Exception("Unable to find a strategy class")

        return all_strategies[0]

    return get_strategy(load_module())

def run(strategy, pattern_params, datapath, *args, **kwargs):
    params = ExecutorParams(strategy_params={}, 
                            pattern_params=pattern_params)
    state.initialize(strategy,
                     BackTestPattern,
                     symbols=['USDJPY'],
                     params=params,
                     settings=parse_settings(datapath))
    start_backtest()
    # from finonelib.methods import plt_position_report

    # for symbol in state.symbols:
    #     plt_position_report(symbol)

if __name__ == '__main__':

    run(Strategy, {}, None)

    