# -*- coding: utf-8 -*-
"""
@author: QuantInfoTech
"""

from finonelib import *
from finonelib.state import state
import pandas as pd
import numpy as np
from datetime import datetime

class BackTestPattern(BaseBackTestPattern):
    min_move = 0.01
    slippage = 2

    def __init__(self):
        self.symbol_df = {}
        self.symbol_last_clob = {}
        state.match_type = MatchType.LP

    def read_symbol_orders(self, symbol: str):
        if state.settings.DATASOURCE == 'hadoop':
            import ibis
            ibis.options.sql.default_limit = None
            hdfs = ibis.hdfs_connect(host=state.settings.HADOOP_MASTER_HOST, port=50070, user='admin')
            client = ibis.impala.connect(host=state.settings.HADOOP_WORKER_HOSTS[0], hdfs_client=hdfs)
        elif state.settings.DATASOURCE == 'local':
            client = None
        start = state.settings.START_TIME
        time_offset = 3600000 * 6 # 6 hours
        while start < state.settings.END_TIME:
            df_order = get_df_order(client, start, min(start+time_offset, state.settings.END_TIME), symbol)
            self.symbol_df[symbol] = df_order
            last_ts = 0
            for row in df_order.iterrows():
                order_info = row[1]
                if order_info['ts'] != last_ts:
                    state.generate_bundle_id()
                    last_ts = order_info['ts']
                order = Order(timestamp=int(row.ts),
                              symbol=symbol,
                              price=1,
                              qty=1,
                              order_type=0,
                              side=0,
                              action=0,
                              ownership=OrderOwnership.OTHERS,
                              bundle_id=state.get_bundle_id())
                order.order_id = -1
                order.market_order_id = state.generate_market_order_id()
                order.index = row[0]
                logger.debug(f'current order id {order_info["id"]}')
                yield last_ts, order
            start += time_offset

    def generate_orders(self, symbol: str):
        print('ClobPattern start generate orders')
        for ts, order in self.read_symbol_orders(symbol):
            yield order

    def match(self, symbol: str, order):
        if order.ownership == OrderOwnership.OTHERS:
            row = self.symbol_df[symbol].iloc[[order.index]]
            clob = ClobData(int(row.ts),
                            symbol,
                            q_bid_array = [int(row.vBID1) or 1,int(row.vBID2) or 1,int(row.vBID3) or 1,int(row.vBID4) or 1,int(row.vBID5) or 1],
                            p_bid_array = [float(row.pBID1),float(row.pBID2),float(row.pBID3),float(row.pBID4),float(row.pBID5)],
                            q_ask_array = [int(row.vASK1) or 1,int(row.vASK2) or 1,int(row.vASK3) or 1,int(row.vASK4) or 1,int(row.vASK5) or 1],
                            p_ask_array = [float(row.pASK1),float(row.pASK2),float(row.pASK3),float(row.pASK4),float(row.pASK5)]
                            )
            self.symbol_last_clob[symbol] = clob
            # print(datetime.fromtimestamp(clob.timestamp / 1000))
            return clob, [], []
        else:
            last_clob = self.symbol_last_clob[symbol]
            if order.action == OrderAction.CANCEL:
                execution = create_execution_from_order(order, ExecutionStatus.CANCEL_REJECTED)
                return last_clob, [], [execution]
            else:
                if order.side == OrderSide.BID:
                    execution = create_execution_from_order(order, ExecutionStatus.FILLED_FULLY)
                    if order.order_type == OrderType.MARKET:
                        execution.price = round(last_clob.p_ask_price[0] + self.min_move * self.slippage, 6)
                    else:
                        execution.price = round(order.price + self.min_move * self.slippage, 6)
                    trade = create_trade_from_execution(execution)
                    return last_clob, [trade], [execution]
                else:
                    execution = create_execution_from_order(order, ExecutionStatus.FILLED_FULLY)
                    if order.order_type == OrderType.MARKET:
                        execution.price = round(last_clob.p_bid_price[0] - self.min_move * self.slippage, 6)
                    else:
                        execution.price = round(order.price - self.min_move * self.slippage, 6)
                    trade = create_trade_from_execution(execution)
                    return last_clob, [trade], [execution]

    def finalize(self):
        print('pattern finalize!')
