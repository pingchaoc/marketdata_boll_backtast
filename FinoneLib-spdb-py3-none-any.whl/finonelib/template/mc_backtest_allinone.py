# -*- coding: utf-8 -*-
"""
@author: QuantInfoTech
"""

from datetime import datetime
from finonelib.main_backtest import start_backtest
from finonelib.interface.exchange import BaseBackTestPattern
from finonelib.methods import clob_to_limit_orders
from finonelib.methods import limit_orders_to_clob
from finonelib.state import state, ExecutorParams
from finonelib.structs import ClobData
from finonelib.structs import ExecutedTrade
from finonelib.structs import Execution
from finonelib.structs import ExecutionStatus
from finonelib.structs import Order
from finonelib.structs import OrderAction
from finonelib.structs import OrderOwnership
from finonelib.structs import OrderSide
from finonelib.structs import OrderType
from finonelib.structs import Repository
from finonelib.interface.exchange import current_timestamp
from finonelib.interface.exchange import create_execution_from_order
from typing import Union, Tuple, List
import random
import time
import math
import numpy as np
import scipy.stats as st

class DefaultMatcher(object):
    simulated_clob_bid_list = []
    simulated_clob_ask_list = []
    symbol = ''

    def __init__(self, symbol: str, 
                 init_clob: Union[ClobData, None]=None) -> None:
        self.symbol = symbol
        if init_clob:
            self.simulated_clob_bid_list, self.simulated_clob_ask_list = clob_to_limit_orders(init_clob)

    def match(self, order: Order) -> Tuple[Union[ClobData, None], List[ExecutedTrade], List[Execution]]:
        if order.action == OrderAction.CANCEL:
            trades, executions =  self.match_cancel_order(order)
        elif order.order_type == OrderType.MARKET:
            trades, executions = self.match_market_order(order)
        else:
            trades, executions = self.match_limit_order(order)
        if self.simulated_clob_bid_list and self.simulated_clob_ask_list:
            clob = limit_orders_to_clob(self.simulated_clob_bid_list, self.simulated_clob_ask_list, current_timestamp(), self.symbol)
        else:
            clob = None
        return clob, trades, executions

    def match_cancel_order(self, cancel_order: Order) -> Tuple[List[ExecutedTrade], List[Execution]]:
        executions = []
        executed_trades = []
        if cancel_order.side == OrderSide.BID:
            if not self.simulated_clob_bid_list:
                execution = create_execution_from_order(cancel_order, ExecutionStatus.CANCEL_REJECTED)
                executions.append(execution)
                return [], executions
            self.simulated_clob_bid_list.sort(key=lambda x: (-x.price, x.timestamp))
            del_list = list()
            for limit_order in self.simulated_clob_bid_list:
                # 只能撤回自己的单子
                if limit_order.cancelled:
                    continue
                if cancel_order.ownership == limit_order.ownership and cancel_order.price == limit_order.price:
                    if cancel_order.ownership == OrderOwnership.OTHERS:
                        if cancel_order.qty > limit_order.qty:
                            cancel_order.qty -= limit_order.qty
                            limit_order.cancelled = True
                            del_list.append(limit_order)
                        elif cancel_order.qty == limit_order.qty:
                            limit_order.cancelled = True
                            del_list.append(limit_order)
                            break
                        else:
                            limit_order.qty -= cancel_order.qty
                            break
                    else:
                        if cancel_order.order_id == limit_order.order_id:
                            if cancel_order.qty > limit_order.qty:
                                execution = create_execution_from_order(cancel_order, ExecutionStatus.CANCEL_REJECTED)
                                executions.append(execution)
                                break
                            if cancel_order.qty == limit_order.qty:
                                limit_order.cancelled = True
                                execution = create_execution_from_order(cancel_order, ExecutionStatus.CANCELLED)
                                executions.append(execution)
                                del_list.append(limit_order)
                                break
                            else:
                                limit_order.qty -= cancel_order.qty
                                execution = create_execution_from_order(cancel_order, ExecutionStatus.CANCELLED)
                                executions.append(execution)
                                break
            self.simulated_clob_bid_list = [x for x in self.simulated_clob_bid_list if x not in del_list]
            self.simulated_clob_bid_list.sort(key=lambda x: (-x.price, x.timestamp))
            return [], executions
        else:
            if not self.simulated_clob_ask_list:
                execution = create_execution_from_order(cancel_order, ExecutionStatus.CANCEL_REJECTED)
                executions.append(execution)
                return [], executions
            self.simulated_clob_ask_list.sort(key=lambda x: (x.price, x.timestamp))
            del_list = list()
            for limit_order in self.simulated_clob_ask_list:
                if limit_order.cancelled:
                    continue
                if cancel_order.ownership == limit_order.ownership and cancel_order.price == limit_order.price:
                    if cancel_order.ownership == OrderOwnership.OTHERS:
                        if cancel_order.qty > limit_order.qty:
                            cancel_order.qty -= limit_order.qty
                            limit_order.cancelled = True
                            del_list.append(limit_order)
                        elif cancel_order.qty == limit_order.qty:
                            limit_order.cancelled = True
                            del_list.append(limit_order)
                            break
                        else:
                            limit_order.qty -= cancel_order.qty
                            break
                    else:
                        if cancel_order.order_id == limit_order.order_id:
                            if cancel_order.qty > limit_order.qty:
                                execution = create_execution_from_order(cancel_order, ExecutionStatus.CANCEL_REJECTED)
                                executions.append(execution)
                                break
                            if cancel_order.qty == limit_order.qty:
                                limit_order.cancelled = True
                                execution = create_execution_from_order(cancel_order, ExecutionStatus.CANCELLED)
                                executions.append(execution)
                                del_list.append(limit_order)
                                break
                            else:
                                limit_order.qty -= cancel_order.qty
                                execution = create_execution_from_order(cancel_order, ExecutionStatus.CANCELLED)
                                executions.append(execution)
                                break
            self.simulated_clob_ask_list = [x for x in self.simulated_clob_ask_list if x not in del_list]
            self.simulated_clob_ask_list.sort(key=lambda x: (x.price, x.timestamp))

            return [], executions

    def match_limit_order(self, limit_order: Order) -> Tuple[List[ExecutedTrade], List[Execution]]:
        timestamp = current_timestamp()
        match_flag = False
        executions = []
        executed_trades = list()
        if limit_order.side == OrderSide.BID:
            self.simulated_clob_bid_list.append(limit_order)
            self.simulated_clob_bid_list.sort(key=lambda x: (-x.price, x.timestamp))
            if self.simulated_clob_ask_list:
                if limit_order.price >= self.simulated_clob_ask_list[0].price:
                    match_flag = True
        elif limit_order.side == OrderSide.ASK:
            self.simulated_clob_ask_list.append(limit_order)
            self.simulated_clob_ask_list.sort(key=lambda x: (x.price, x.timestamp))
            if self.simulated_clob_bid_list:
                if limit_order.price <= self.simulated_clob_bid_list[0].price:
                    match_flag = True

        if match_flag:
            del_list = list()

            best_ask_price = self.simulated_clob_ask_list[0].price
            for index, bid_order in enumerate(self.simulated_clob_bid_list):
                if bid_order.matched:
                    continue
                if bid_order.price < best_ask_price:
                    break
                for ask_order in self.simulated_clob_ask_list:
                    if ask_order.matched:
                        continue
                    if bid_order.price >= ask_order.price:
                        if bid_order.timestamp > ask_order.timestamp:
                            # side = OrderSide.ASK
                            price = ask_order.price
                        else:
                            # side = OrderSide.BID
                            price = bid_order.price
                        # ownership = OrderOwnership.OTHERS

                        # if bid_order.ownership == OrderOwnership.MARKET_MAKER:
                        #     ownership = OrderOwnership.MARKET_MAKER
                        #     side = OrderSide.BID
                        # if ask_order.ownership == OrderOwnership.MARKET_MAKER:
                        #     ownership = OrderOwnership.MARKET_MAKER
                        #     side = OrderSide.ASK

                        if bid_order.qty > ask_order.qty:
                            bid_trade = ExecutedTrade(timestamp, self.symbol, bid_order.side, price, ask_order.qty, bid_order.ownership)
                            ask_trade = ExecutedTrade(timestamp, self.symbol, ask_order.side, price, ask_order.qty, ask_order.ownership)
                            executed_trades.append(bid_trade)
                            executed_trades.append(ask_trade)
                            bid_order.qty -= ask_order.qty
                            ask_order.matched = True
                            if (index + 1) < len(self.simulated_clob_ask_list):
                                best_ask_price = self.simulated_clob_ask_list[index + 1].price
                            elif index < len(self.simulated_clob_ask_list):
                                best_ask_price = self.simulated_clob_ask_list[index].price
                            execution = create_execution_from_order(ask_order, ExecutionStatus.FILLED_FULLY)
                            executions.append(execution)
                            execution = create_execution_from_order(bid_order, ExecutionStatus.FILLED_PARTIALLY, ask_order.qty)
                            executions.append(execution)
                            del_list.append(ask_order)
                        elif bid_order.qty == ask_order.qty:
                            bid_trade = ExecutedTrade(timestamp, self.symbol, bid_order.side, price, ask_order.qty, bid_order.ownership)
                            ask_trade = ExecutedTrade(timestamp, self.symbol, ask_order.side, price, ask_order.qty, ask_order.ownership)
                            executed_trades.append(bid_trade)
                            executed_trades.append(ask_trade)
                            ask_order.matched = True
                            if (index + 1) < len(self.simulated_clob_ask_list):
                                best_ask_price = self.simulated_clob_ask_list[index + 1].price
                            # 原版else
                            elif index < len(self.simulated_clob_ask_list):
                                best_ask_price = self.simulated_clob_ask_list[index].price
                            bid_order.matched = True
                            execution = create_execution_from_order(ask_order, ExecutionStatus.FILLED_FULLY)
                            executions.append(execution)
                            execution = create_execution_from_order(bid_order, ExecutionStatus.FILLED_FULLY)
                            executions.append(execution)
                            del_list.append(ask_order)
                            del_list.append(bid_order)
                            break
                        elif bid_order.qty < ask_order.qty:
                            bid_trade = ExecutedTrade(timestamp, self.symbol, bid_order.side, price, bid_order.qty, bid_order.ownership)
                            ask_trade = ExecutedTrade(timestamp, self.symbol, ask_order.side, price, bid_order.qty, ask_order.ownership)
                            executed_trades.append(bid_trade)
                            executed_trades.append(ask_trade)
                            ask_order.qty -= bid_order.qty
                            bid_order.matched = True
                            execution = create_execution_from_order(ask_order, ExecutionStatus.FILLED_PARTIALLY, bid_order.qty)
                            executions.append(execution)
                            execution = create_execution_from_order(bid_order, ExecutionStatus.FILLED_FULLY)
                            executions.append(execution)
                            del_list.append(bid_order)
                            break
                    else:
                        break
            self.simulated_clob_ask_list = [x for x in self.simulated_clob_ask_list if x not in del_list]
            self.simulated_clob_bid_list = [x for x in self.simulated_clob_bid_list if x not in del_list]

            maker_bid_list = [x for x in self.simulated_clob_bid_list if
                                     x.ownership == OrderOwnership.MARKET_MAKER ]
            maker_ask_list = [x for x in self.simulated_clob_ask_list if
                                     x.ownership == OrderOwnership.MARKET_MAKER ]

            other_bid_list = [x for x in self.simulated_clob_bid_list if
                                     x.ownership == OrderOwnership.OTHERS ]
            other_ask_list = [x for x in self.simulated_clob_ask_list if
                                     x.ownership == OrderOwnership.OTHERS ]

            unique_ask_prices = list(set([ask_order.price for ask_order in other_ask_list]))
            unique_bid_prices = list(set([bid_order.price for bid_order in other_bid_list]))

            unique_bid_prices.sort(reverse=True)
            unique_ask_prices.sort(reverse=False)

            if len(unique_bid_prices) >= 10:
                unique_bid_prices = unique_bid_prices[:10]
            if len(unique_ask_prices) >= 10:
                unique_ask_prices = unique_ask_prices[:10]

            new_clob_limit_bid_order_list = list(
                filter(lambda x: x.price in unique_bid_prices, other_bid_list))

            new_clob_limit_ask_order_list = list(
                filter(lambda x: x.price in unique_ask_prices, other_ask_list))

            new_clob_limit_bid_order_list.extend(maker_bid_list)
            new_clob_limit_ask_order_list.extend(maker_ask_list)
            new_clob_limit_bid_order_list.sort(key=lambda x: (-x.price, x.timestamp))
            new_clob_limit_ask_order_list.sort(key=lambda x: (x.price, x.timestamp))

            self.simulated_clob_bid_list = new_clob_limit_bid_order_list
            self.simulated_clob_ask_list = new_clob_limit_ask_order_list
            return executed_trades, executions
        else:
            return executed_trades, executions

    def match_market_order(self, market_order: Order) -> Tuple[List[ExecutedTrade], List[Execution]]:
        executions = []
        executed_trades = list()
        if market_order.side == OrderSide.BID:

            del_list = list()
            if self.simulated_clob_ask_list:
                self.simulated_clob_ask_list.sort(key=lambda x: (x.price, x.timestamp))
                temp_qty = market_order.qty

                for limit_ask_order in self.simulated_clob_ask_list:
                    if limit_ask_order.matched:
                        continue
                    if temp_qty < limit_ask_order.qty:
                        trade = ExecutedTrade(current_timestamp(), self.symbol, OrderSide.ASK, limit_ask_order.price,
                                              temp_qty, limit_ask_order.ownership)
                        trade.isMarketOrder = True
                        executed_trades.append(trade)
                        trade = ExecutedTrade(current_timestamp(), self.symbol, market_order.side, limit_ask_order.price, 
                                              temp_qty, market_order.ownership)
                        trade.isMarketOrder = True
                        executed_trades.append(trade)
                        limit_ask_order.qty -= temp_qty
                        execution = create_execution_from_order(market_order, ExecutionStatus.FILLED_FULLY)
                        executions.append(execution)
                        execution = create_execution_from_order(limit_ask_order, ExecutionStatus.FILLED_PARTIALLY, temp_qty)
                        executions.append(execution)
                        break
                    elif temp_qty == limit_ask_order.qty:
                        trade = ExecutedTrade(current_timestamp(), self.symbol, OrderSide.ASK, limit_ask_order.price,
                                              temp_qty, limit_ask_order.ownership)
                        trade.isMarketOrder = True
                        executed_trades.append(trade)
                        trade = ExecutedTrade(current_timestamp(), self.symbol, market_order.side, limit_ask_order.price, 
                                              temp_qty, market_order.ownership)
                        trade.isMarketOrder = True
                        executed_trades.append(trade)
                        limit_ask_order.matched = True
                        execution = create_execution_from_order(market_order, ExecutionStatus.FILLED_FULLY)
                        executions.append(execution)
                        execution = create_execution_from_order(limit_ask_order, ExecutionStatus.FILLED_FULLY)
                        executions.append(execution)
                        del_list.append(limit_ask_order)
                        break
                    else:
                        trade = ExecutedTrade(current_timestamp(), self.symbol, OrderSide.ASK, limit_ask_order.price,
                                              limit_ask_order.qty, limit_ask_order.ownership)
                        trade.isMarketOrder = True
                        executed_trades.append(trade)
                        trade = ExecutedTrade(current_timestamp(), self.symbol, market_order.side, limit_ask_order.price, 
                                              limit_ask_order.qty, market_order.ownership)
                        trade.isMarketOrder = True
                        executed_trades.append(trade)
                        temp_qty -= limit_ask_order.qty
                        limit_ask_order.matched = True
                        execution = create_execution_from_order(market_order, ExecutionStatus.FILLED_PARTIALLY, limit_ask_order.qty)
                        executions.append(execution)
                        execution = create_execution_from_order(limit_ask_order, ExecutionStatus.FILLED_FULLY)
                        executions.append(execution)
                        del_list.append(limit_ask_order)
                self.simulated_clob_ask_list = [x for x in self.simulated_clob_ask_list if x not in del_list]
                self.simulated_clob_ask_list.sort(key=lambda x: (x.price, x.timestamp))
            return executed_trades, executions

        elif market_order.side == OrderSide.ASK:
            del_list = list()
            if self.simulated_clob_bid_list:
                self.simulated_clob_bid_list.sort(key=lambda x: (-x.price, x.timestamp))
                temp_qty = market_order.qty

                for limit_bid_order in self.simulated_clob_bid_list:
                    if limit_bid_order.matched:
                        continue
                    if temp_qty < limit_bid_order.qty:
                        trade = ExecutedTrade(current_timestamp(), self.symbol, OrderSide.BID, limit_bid_order.price,
                                              temp_qty, limit_bid_order.ownership)
                        trade.isMarketOrder = True
                        executed_trades.append(trade)
                        trade = ExecutedTrade(current_timestamp(), self.symbol, market_order.side, limit_bid_order.price, 
                                              temp_qty, market_order.ownership)
                        executed_trades.append(trade)
                        limit_bid_order.qty -= temp_qty
                        execution = create_execution_from_order(market_order, ExecutionStatus.FILLED_FULLY)
                        executions.append(execution)
                        execution = create_execution_from_order(limit_bid_order, ExecutionStatus.FILLED_PARTIALLY, temp_qty)
                        executions.append(execution)
                        break
                    elif temp_qty == limit_bid_order.qty:
                        trade = ExecutedTrade(current_timestamp(), self.symbol, OrderSide.BID, limit_bid_order.price,
                                              temp_qty, limit_bid_order.ownership)
                        trade.isMarketOrder = True
                        executed_trades.append(trade)
                        trade = ExecutedTrade(current_timestamp(), self.symbol, market_order.side, limit_bid_order.price, 
                                              temp_qty, market_order.ownership)
                        executed_trades.append(trade)
                        limit_bid_order.matched = True
                        execution = create_execution_from_order(market_order, ExecutionStatus.FILLED_FULLY)
                        executions.append(execution)
                        execution = create_execution_from_order(limit_bid_order, ExecutionStatus.FILLED_FULLY)
                        executions.append(execution)
                        del_list.append(limit_bid_order)
                        break
                    else:
                        trade = ExecutedTrade(current_timestamp(), self.symbol, OrderSide.BID, limit_bid_order.price,
                                              limit_bid_order.qty, limit_bid_order.ownership)
                        trade.isMarketOrder = True
                        executed_trades.append(trade)
                        trade = ExecutedTrade(current_timestamp(), self.symbol, market_order.side, limit_bid_order.price, 
                                              limit_bid_order.qty, market_order.ownership)
                        executed_trades.append(trade)
                        temp_qty -= limit_bid_order.qty
                        limit_bid_order.matched = True
                        execution = create_execution_from_order(market_order, ExecutionStatus.FILLED_PARTIALLY, limit_bid_order.qty)
                        executions.append(execution)
                        execution = create_execution_from_order(limit_bid_order, ExecutionStatus.FILLED_FULLY)
                        executions.append(execution)
                        del_list.append(limit_bid_order)
                self.simulated_clob_bid_list = [x for x in self.simulated_clob_bid_list if x not in del_list]
                self.simulated_clob_bid_list.sort(key=lambda x: (-x.price, x.timestamp))
            return executed_trades, executions


class OrderSimulator:
    def __init__(self, symbol, depth, min_move, qty_min, qty_max):
        self.symbol = symbol
        self.depth = depth
        self.min_move = min_move
        self.qty_min = qty_min
        self.qty_max = qty_max
        self.bid_limit_lambda = []
        self.bid_cancel_lambda = []
        self.bid_market_lambda = []
        self.ask_limit_lambda = []
        self.ask_cancel_lambda = []
        self.ask_market_lambda = []

    def get_buy_market_order(self, time, rate_mean, rate_var):
        rate = max(0, np.random.normal(rate_mean, rate_var))
        qty = self.poisson_generator(rate, self.qty_max)
        mkt_order = list()
        if qty >= 1:
            order = Order(timestamp=time,
                          symbol=self.symbol,
                          price=0,
                          qty=qty,
                          order_type=OrderType.MARKET,
                          side=OrderSide.BID,
                          action=OrderAction.PLACE,
                          ownership=OrderOwnership.OTHERS,
                          bundle_id=state.get_bundle_id())

            # this order is not from maker, set order_id to -1
            order.order_id = -1
            order.market_order_id = state.generate_market_order_id()

            mkt_order.append(order)

        return mkt_order

    def get_sell_market_order(self, time, rate_mean, rate_var):
        rate = max(0, np.random.normal(rate_mean, rate_var))
        qty = self.poisson_generator(rate, self.qty_max)
        mkt_order = list()
        if qty >= 1:
            order = Order(timestamp=time,
                          symbol=self.symbol,
                          price=0,
                          qty=qty,
                          order_type=OrderType.MARKET,
                          side=OrderSide.ASK,
                          action=OrderAction.PLACE,
                          ownership=OrderOwnership.OTHERS,
                          bundle_id=state.get_bundle_id())

            # this order is not from maker, set order_id to -1
            order.order_id = -1
            order.market_order_id = state.generate_market_order_id()

            mkt_order.append(order)
        return mkt_order

    def get_bid_cancellation_orders(self, clob_limit_bid_list, clob_limit_ask_list, time, A_up, A_down, K_up,
                                    K_down):
        order_list = []
        clob = limit_orders_to_clob(clob_limit_bid_list, clob_limit_ask_list, time, self.symbol)
        length = len(clob.p_bid_array)
        A = round(random.uniform(A_down, A_up), 3)
        K = round(random.uniform(K_down, K_up), 3)
        if len(clob.p_ask_array) == 0:
            return list()
        p_ask_best = clob.p_ask_array[0]
        for i in range(length):
            cancel_rate = self.bid_cancel_order_ratio(clob.p_bid_array[i], p_ask_best, A, K)
            cancel_qty = int(cancel_rate * clob.q_bid_array[i])
            if cancel_qty >= 1:
                order = Order(timestamp=time,
                              symbol=self.symbol,
                              price=clob.p_bid_array[i],
                              qty=cancel_qty,
                              order_type=OrderType.LIMIT,
                              side=OrderSide.BID,
                              action=OrderAction.CANCEL,
                              ownership=OrderOwnership.OTHERS,
                              bundle_id=state.get_bundle_id())

                # this order is not from maker, set order_id to -1
                order.order_id = -1
                order.market_order_id = state.generate_market_order_id()
                order_list.append(order)
        return order_list

    def get_ask_cancellation_orders(self, clob_limit_bid_list, clob_limit_ask_list, time, A_up, A_down, K_up,
                                    K_down):
        order_list = []
        clob = limit_orders_to_clob(clob_limit_bid_list, clob_limit_ask_list, time, self.symbol)
        length = len(clob.p_ask_array)
        A = round(random.uniform(A_down, A_up), 3)
        K = round(random.uniform(K_down, K_up), 3)
        if len(clob.p_bid_array) == 0:
            return list()
        p_bid_best = clob.p_bid_array[0]
        for i in range(length):
            cancel_rate = self.ask_cancel_order_ratio(clob.p_ask_array[i], p_bid_best, A, K)
            cancel_qty = int(cancel_rate * clob.q_ask_array[i])
            if cancel_qty >= 1:
                order = Order(timestamp=time,
                              symbol=self.symbol,
                              price=clob.p_ask_array[i],
                              qty=cancel_qty,
                              order_type=OrderType.LIMIT,
                              side=OrderSide.ASK,
                              action=OrderAction.CANCEL,
                              ownership=OrderOwnership.OTHERS,
                              bundle_id=state.get_bundle_id())

                # this order is not from maker, set order_id to -1
                order.order_id = -1
                order.market_order_id = state.generate_market_order_id()
                order_list.append(order)
        return order_list

    def get_bid_limit_orders(self, clob_limit_bid_list, clob_limit_ask_list, time, A_up, A_down, K_up, K_down):
        order_list = []
        A = round(random.uniform(A_down, A_up), 3)
        K = round(random.uniform(K_down, K_up), 3)
        # TODO simulate limit order
        if len(clob_limit_ask_list) == 0:
            return list()
        p_ask_best = clob_limit_ask_list[0].price
        # 生成此时刻的市场新limit order
        for i in range(self.depth):
            bid = p_ask_best - (i + 1) * self.min_move
            qty = int(self.limit_bid_arrive_order_generator(bid, p_ask_best, A, K, self.qty_max))
            # print("Bid Order Qty:" + str(qty) + ", Price:" + str(bid))
            if qty >= 1:
                order = Order(timestamp=time,
                              symbol=self.symbol,
                              price=bid,
                              qty=qty,
                              order_type=OrderType.LIMIT,
                              side=OrderSide.BID,
                              action=OrderAction.PLACE,
                              ownership=OrderOwnership.OTHERS,
                              bundle_id=state.get_bundle_id())

                # this order is not from maker, set order_id to -1
                order.order_id = -1
                order.market_order_id = state.generate_market_order_id()
                order_list.append(order)

        return order_list

    def get_ask_limit_orders(self, clob_limit_bid_list, clob_limit_ask_list, time, A_up, A_down, K_up, K_down):
        order_list = []
        A = round(random.uniform(A_down, A_up), 3)
        K = round(random.uniform(K_down, K_up), 3)
        # TODO simulate limit order
        if len(clob_limit_bid_list) == 0:
            return list()
        p_bid_best = clob_limit_bid_list[0].price
        for i in range(self.depth):
            ask = p_bid_best + (i + 1) * self.min_move
            qty = int(self.limit_ask_arrive_order_generator(ask, p_bid_best, A, K, self.qty_max))
            # print("Ask Order Qty:" + str(qty) + ", Price:" + str(ask))
            if qty >= 1:
                order = Order(timestamp=time,
                              symbol=self.symbol,
                              price=ask,
                              qty=qty,
                              order_type=OrderType.LIMIT,
                              side=OrderSide.ASK,
                              action=OrderAction.PLACE,
                              ownership=OrderOwnership.OTHERS,
                              bundle_id=state.get_bundle_id())

                # this order is not from maker, set order_id to -1
                order.order_id = -1
                order.market_order_id = state.generate_market_order_id()
                order_list.append(order)
        return order_list

    def get_init_clob(self, time, price_mid, depth, spread):

        q_bid_array = []
        q_ask_array = []
        p_bid_array = []
        p_ask_array = []

        ask_p = price_mid + spread * self.min_move / 2
        bid_p = price_mid - spread * self.min_move / 2

        for i in range(depth):
            ask_p += self.min_move
            p_ask_array.append(ask_p)
            qty_ask = int(self.func_qty(ask_p, price_mid, self.qty_max, self.qty_min))
            q_ask_array.append(qty_ask)

            bid_p -= self.min_move
            p_bid_array.append(bid_p)
            qty_bid = int(self.func_qty(bid_p, price_mid, self.qty_max, self.qty_min))
            q_bid_array.append(qty_bid)

        clob = ClobData(time, self.symbol, q_bid_array, p_bid_array, q_ask_array, p_ask_array)

        return clob

    def func_qty(self, price, price_mid, qty_max, qty_min):
        rate = 10
        return (qty_max - qty_min) * (1 - math.exp(-rate * abs(price - price_mid)))

    def poisson_generator(self, rate, qty_max):
        rand_prob = random.random()
        return self.poisson_num(rate, rand_prob, qty_max)

    def poisson_num(self, rate, prob, vol_max):
        index = int(st.poisson.ppf(prob, rate))
        return min(index, vol_max)

    def limit_bid_arrive_order_generator(self, bid, p_ask_best, A, K, qty_max):
        delta = p_ask_best - bid
        arrive_rate = A * math.exp(-K * delta)
        rand_prob = random.random()
        return self.poisson_num(arrive_rate, rand_prob, qty_max)

    def limit_ask_arrive_order_generator(self, ask, p_bid_best, A, K, qty_max):
        delta = ask - p_bid_best
        arrive_rate = A * math.exp(-K * delta)
        rand_prob = random.random()
        return self.poisson_num(arrive_rate, rand_prob, qty_max)

    def bid_cancel_order_ratio(self, bid, p_ask_best, A, K):
        delta = p_ask_best - bid
        mean = A * math.exp(-K * delta)
        vari = 0.01 * mean
        return min(0.6, abs(np.random.normal(mean, vari)))

    def ask_cancel_order_ratio(self, ask, p_bid_best, A, K):
        delta = ask - p_bid_best
        mean = A * math.exp(-K * delta)
        vari = 0.01 * mean
        return min(0.6, abs(np.random.normal(mean, vari)))


class BackTestPattern(BaseBackTestPattern):
    hb_frequency = 3
    time_points = 2000
    depth = 20
    min_move = 1
    qty_min = 10
    qty_max = 100
    init_mid_price = 65000
    init_spread = 6

    bid_limit_param_k_up = 0.4
    bid_limit_param_k_down = 0.3
    ask_limit_param_k_up = 0.4
    ask_limit_param_k_down = 0.3
    bid_limit_param_a_up = 40
    bid_limit_param_a_down = 20
    ask_limit_param_a_up = 40
    ask_limit_param_a_down = 20

    buy_mkt_order_rate_mean = 15
    buy_mkt_order_rate_var = 5
    sell_mkt_order_rate_mean = 15
    sell_mkt_order_rate_var = 5
    bid_cancel_param_k_up = 0.7
    bid_cancel_param_k_down = 0.5
    ask_cancel_param_k_up = 0.7
    ask_cancel_param_k_down = 0.5
    bid_cancel_param_a_up = 7
    bid_cancel_param_a_down = 5
    ask_cancel_param_a_up = 7
    ask_cancel_param_a_down = 5

    def __init__(self):
        self.symbol_matchers = {}

    def read_mc_orders(self, symbol: str):
        

        origin_time = round(datetime.strptime('2018-07-01 09:00:00', "%Y-%m-%d %H:%M:%S").timestamp() * 1000)

        simulator = OrderSimulator(symbol, self.depth, self.min_move, self.qty_min, self.qty_max)
        init_clob = simulator.get_init_clob(origin_time, self.init_mid_price, self.depth, self.init_spread)
        simulated_clob_bid_list, simulated_clob_ask_list = clob_to_limit_orders(init_clob)
        if not symbol in self.symbol_matchers:
            self.symbol_matchers[symbol] = DefaultMatcher(symbol)
        self.symbol_matchers[symbol].simulated_clob_bid_list = simulated_clob_bid_list
        self.symbol_matchers[symbol].simulated_clob_ask_list = simulated_clob_ask_list

        for _ in range(0, self.time_points):

            origin_time += self.hb_frequency * 1000
            current_time = origin_time

            

            simulated_clob_bid_list = self.symbol_matchers[symbol].simulated_clob_bid_list
            simulated_clob_ask_list = self.symbol_matchers[symbol].simulated_clob_ask_list
            bid_cancel_orders = simulator.get_bid_cancellation_orders(simulated_clob_bid_list,
                                                                      simulated_clob_ask_list,
                                                                      current_time, self.bid_cancel_param_a_up,
                                                                      self.bid_cancel_param_a_down,
                                                                      self.bid_cancel_param_k_up,
                                                                      self.bid_cancel_param_k_down)
            ask_cancel_orders = simulator.get_ask_cancellation_orders(simulated_clob_bid_list,
                                                                      simulated_clob_ask_list,
                                                                      current_time, self.ask_cancel_param_a_up,
                                                                      self.ask_cancel_param_a_down,
                                                                      self.ask_cancel_param_k_up,
                                                                      self.ask_cancel_param_k_down)

            bid_limit_orders = simulator.get_bid_limit_orders(simulated_clob_bid_list, simulated_clob_ask_list,
                                                              current_time, self.bid_limit_param_a_up,
                                                              self.bid_limit_param_a_down, self.bid_limit_param_k_up,
                                                              self.bid_limit_param_k_down)
            ask_limit_orders = simulator.get_ask_limit_orders(simulated_clob_bid_list, simulated_clob_ask_list,
                                                              current_time, self.ask_limit_param_a_up,
                                                              self.ask_limit_param_a_down, self.ask_limit_param_k_up,
                                                              self.ask_limit_param_k_down)

            buy_market_orders = simulator.get_buy_market_order(current_time, self.buy_mkt_order_rate_mean,
                                                               self.buy_mkt_order_rate_var)
            sell_market_orders = simulator.get_sell_market_order(current_time, self.sell_mkt_order_rate_mean,
                                                                 self.sell_mkt_order_rate_var)

            other_order_list = []
            other_order_list.extend(ask_cancel_orders)
            other_order_list.extend(bid_cancel_orders)
            other_order_list.extend(ask_limit_orders)
            other_order_list.extend(bid_limit_orders)
            other_order_list.extend(sell_market_orders)
            other_order_list.extend(buy_market_orders)

            leng = self.hb_frequency * 1000
            if leng % len(other_order_list) != 0:
                leng -= leng % len(other_order_list)

            interval = leng / len(other_order_list)

            for order in other_order_list:
                order.timestamp = int(current_time)
                current_time += interval
            yield other_order_list

    def generate_orders(self, symbol: str):
        print('BackTestPattern start generate orders')
        for orders in self.read_mc_orders(symbol):
            for order in orders:
                yield order
            while True:
                yield None
                if orders[-1].matched:
                    break

    def match(self, symbol: str, order):
        if not symbol in self.symbol_matchers:
            self.symbol_matchers[symbol] = DefaultMatcher(symbol)
        return self.symbol_matchers[symbol].match(order)

    def finalize(self):
        print('pattern finalize!')


def parse_settings(path):
    return {
        'START_TIME': 1530406805000,
        'END_TIME': 1530435604662,
        # 'END_TIME': 1530406835000,
        'HADOOP_MASTER_HOST': 'master.finonedev.quantinfotech.com',
        'HADOOP_WORKER_HOSTS': ['worker1.finonedev.quantinfotech.com'],
        'STRATEGY_FILE_HDFS_PATH': '/user/admin',
        'SPARK_KEY': 'spark_key',
        'PERFORMANCE': ['max_drawdown'],
        'SERVER_HOST': 'localhost',
        'RECORD_ID': '100',
        'USER_TOKEN': '00000000-0000-0000-0000-000000000000',
        'LOG_LEVEL': 'strategy',
        'ORDER_TABLE': {
            'USDCNY@CFETS': 'default.orders_usdcny_cfets_1s',
            'eurusd': 'default.orders_usdcny_cfets_1s',
        },
        'DATASOURCE': 'local',
        'LOCAL_DATA_PATH': {
            'USDCNY@CFETS': path,
            'eurusd': path,
        },
        'DEBUG': True,
        'STRATEGY_NAME': 'Top',
        'BACKTEST_NAME': 'LocalHs',
        'RESULT_ID': 0,
        'OUTPUT_REPORT': True,
        # 'PLAY_SPEED': 1
    }


def load_strategy(script):
    def load_module():
        import importlib.util
        spec = importlib.util.spec_from_file_location('__strategy__', script)
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        return m

    def get_strategy(m):
        import inspect
        all_clazz = inspect.getmembers(m, inspect.isclass)
        all_strategies = [cls for (_, cls) in all_clazz if cls.__module__ == '__strategy__']
        if len(all_strategies) == 0:
            raise Exception("Unable to find a strategy class")

        return all_strategies[0]

    return get_strategy(load_module())


def run(strategy, pattern_params, *args, **kwargs):
    path_count = 1
    for i in range(path_count):
        settings = parse_settings('hello')
        settings['MC_PATH_COUNTER'] = str(i)
        params = ExecutorParams(strategy_params={},
                                pattern_params=pattern_params)
        state.initialize(strategy,
                         BackTestPattern,
                         symbols=['USDCNY@CFETS'],
                         params=params,
                         settings=settings)

        start_backtest()
        from finonelib.methods import plt_position_report

        for symbol in state.symbols:
            plt_position_report(symbol)


if __name__ == '__main__':
    import sys

    clazz = None
    if len(sys.argv) > 1:
        clazz = load_strategy(sys.argv[1])

    # import cProfile
    # cProfile.run("run(clazz, {})")
    run(clazz, {})
    
