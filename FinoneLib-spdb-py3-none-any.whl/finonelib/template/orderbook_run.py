from finonelib import *
from finonelib import ta

import numpy as np


class Strategy(object):


    def on_receive_marketdata(self, marketdata: ClobData):
        pass

    def on_receive_transaction(self, trade: ExecutedTrade):
        # logger.warning('on_receive_transaction')
        pass

    def on_submit_accepted(self, execution: Execution):
        # logger.warning('on_receive_transaction')
        pass

    def on_submit_rejected(self, execution: Execution):
        # logger.warning('on_submit_rejected')
        pass

    def on_cancel_rejected(self, execution: Execution):
        # logger.warning('on_cancel_rejected')
        pass

    def on_order_partial_executed(self, execution: Execution):
        # logger.warning('on_order_partial_executed')
        pass

    def on_order_executed(self, execution: Execution):
        pass

    def on_order_cancelled(self, execution: Execution):
        pass

    def on_receive_status_update(self, repository: Repository):
        pass

    def on_receive_timestamp(self, timestamp: int):
        pass

    def custom_settings(self):
        return {
           'START_TIME': 1554307189821,
           'END_TIME': 1554393622697,
           'HADOOP_MASTER_HOST': '',
           'HADOOP_IMPALA_HOST': '',
           'HADOOP_WORKER_HOSTS': [],
           'DEBUG': False,
           'DATASOURCE': 'local',
           'OUTPUT_REPORT': False,
           'LOCAL_DATA_PATH': {
                symbol: path
           },
           'SEND_MATCH_INFO': False,
           'PRECISION': {},
           'MARKETDATA_INTERVAL': 5000, # in ms, 5seconds
           'ORDER_DELAY': 5, # in ms
           'SEND_HEARTBEAT': False,
           'HEARTBEAT_INTERVAL': 1000, # 1s
           'SPARK': False,
           'METADATA': [],
           'REPORTING_CURRENCY_MODE': 'low', # high or low  OC先不考虑
           'REPORTING_CURRENCY': '',
           'TABLES_FOR_REPORTING': {},
           'ECON_DATA_USED': [], 
        }

symbol = '180211.IB.1@CFETS'
path = './180211.IB_ODM_10.1.csv'

def run():
    from finonelib.template.orderbook_pattern_template import BackTestPattern
    from finonelib.main_backtest import start_backtest
    from finonelib.state import ExecutorParams

    params = ExecutorParams(strategy_params={}, pattern_params={})
    state.initialize(Strategy,
                     BackTestPattern, 
                     symbols=[symbol],
                     params=params,
                     settings={})
    start_backtest()
    # from finonelib.methods import (plt_position_report,
    #                               plt_total_pnl,
    #                               plt_best_price)
    # for symbol in state.symbols:
    #     plt_position_report(symbol)
    # for symbol in state.symbols:
    #     plt_best_price(symbol)
    # if len(state.symbols) > 1:
    #     plt_total_pnl()

if __name__ == '__main__':
    run()