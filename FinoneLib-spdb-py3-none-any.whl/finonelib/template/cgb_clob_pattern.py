# -*- coding: utf-8 -*-
"""
@author: QuantInfoTech
"""

from finonelib import *
from finonelib.state import state
import pandas as pd
import numpy as np
from datetime import datetime

class BackTestPattern(BaseBackTestPattern):
    min_move = 0.0001
    slippage = 3

    def __init__(self):
        self.symbol_df = {}
        self.symbol_last_clob = None

    def generate_orders(self, symbol: str):
        self.symbol_df[symbol] = pd.read_csv(state.settings.LOCAL_DATA_PATH[symbol], header=0, float_precision='round_trip')
        print('ClobPattern start generate orders')
        for i in range(len(self.symbol_df[symbol])):
            row = self.symbol_df[symbol].iloc[[i]]
            order = Order(timestamp=int(row.ts),
                          symbol=symbol,
                          price=1,
                          qty=1,
                          order_type=0,
                          side=0,
                          action=0,
                          ownership=OrderOwnership.OTHERS,
                          bundle_id=state.get_bundle_id())
            order.order_id = -1
            order.market_order_id = state.generate_market_order_id()
            order.index = i
            print(datetime.fromtimestamp(order.timestamp / 1000))
            yield order

    def match(self, symbol: str, order):
        if order.ownership == OrderOwnership.OTHERS:
            row = self.symbol_df[symbol].iloc[[order.index]]
            clob = ClobData(int(row.ts),
                            symbol,
                            q_bid_array = [int(row.vBID1),int(row.vBID2),int(row.vBID3),int(row.vBID4),int(row.vBID5)],
                            p_bid_array = [float(row.pBID1),float(row.pBID2),float(row.pBID3),float(row.pBID4),float(row.pBID5)],
                            q_ask_array = [int(row.vASK1),int(row.vASK2),int(row.vASK3),int(row.vASK4),int(row.vASK5)],
                            p_ask_array = [float(row.pASK1),float(row.pASK2),float(row.pASK3),float(row.pASK4),float(row.pASK5)]
                            )
            self.symbol_last_clob[symbol] = clob
            print(datetime.fromtimestamp(clob.timestamp / 1000))
            return clob, [], []
        else:
            last_clob = self.symbol_last_clob[symbol]
            if order.action == OrderAction.CANCEL:
                execution = create_execution_from_order(order, ExecutionStatus.CANCEL_REJECTED)
                return last_clob, [], [execution]
            else:
                if order.side == OrderSide.BID:
                    for index, price in enumerate(last_clob.p_ask_array):
                        if price + self.min_move * self.slippage <= order.price:
                            # deal
                            execution = create_execution_from_order(order, ExecutionStatus.FILLED_FULLY)
                            execution.price = round(price + self.min_move * self.slippage, 6)
                            trade = create_trade_from_execution(execution)
                            return last_clob, [trade], [execution]
                    # no deal
                    execution = create_execution_from_order(order, ExecutionStatus.REJECTED)
                    return last_clob, [], [execution]
                else:
                    for index, price in enumerate(last_clob.p_bid_array):
                        if price - self.min_move * self.slippage >= order.price:
                            execution = create_execution_from_order(order, ExecutionStatus.FILLED_FULLY)
                            execution.price = round(price - self.min_move * self.slippage, 6)
                            trade = create_trade_from_execution(execution)
                            return last_clob, [trade], [execution]
                    execution = create_execution_from_order(order, ExecutionStatus.REJECTED)
                    return last_clob, [], [execution]

    def finalize(self):
        print('pattern finalize!')


def parse_settings(path):
    return {
        'START_TIME': 1551745799000,
        'END_TIME': 1552000099000,
        'HADOOP_MASTER_HOST': '',
        'HADOOP_IMPALA_HOST': '',
        'HADOOP_WORKER_HOSTS': [''],
        'STRATEGY_FILE_HDFS_PATH': '',
        'SPARK_KEY': '',
        'PERFORMANCE': [],
        'SERVER_HOST': 'localhost',
        'RECORD_ID': '100',
        'USER_TOKEN': '00000000-0000-0000-0000-000000000000',
        'LOG_LEVEL': 'strategy',
        'ORDER_TABLE': {},
        'DATASOURCE': 'local',
        'LOCAL_DATA_PATH': {
            'USDJPY': './formated_cgb_orderbook.csv',
        },
        'SPARK': False,
        'STRATEGY_NAME': '',
        'BACKTEST_NAME': 'CGB_CLOB_PATTERN',
        'RESULT_ID': 0,
        'OUTPUT_REPORT': True,
        'MARKETDATA_INTERVAL': 3000,
        'SEND_MATCH_INFO': False,
        'SPARK_REDIS_HOST': "",
        'SPARK_REDIS_PORT': "",
        'SPARK_REDIS_DB': 4,
        'DEBUG': False
    }

def load_strategy(script):
    def load_module():
        import importlib.util
        spec = importlib.util.spec_from_file_location('__strategy__', script)
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        return m

    def get_strategy(m):
        import inspect
        all_clazz = inspect.getmembers(m, inspect.isclass)
        all_strategies = [cls for (_, cls) in all_clazz if cls.__module__ == '__strategy__']
        if len(all_strategies) == 0:
            raise Exception("Unable to find a strategy class")

        return all_strategies[0]

    return get_strategy(load_module())

def run(strategy, pattern_params, datapath, *args, **kwargs):
    from finonelib.state import ExecutorParams
    from finonelib.main_backtest import start_backtest
    params = ExecutorParams(strategy_params={}, 
                            pattern_params=pattern_params)
    state.initialize(strategy,
                     BackTestPattern,
                     symbols=['USDCNY'],
                     params=params,
                     settings=parse_settings(datapath))
    start_backtest()
    from finonelib.methods import plt_position_report, plt_total_pnl

    for symbol in state.symbols:
        plt_position_report(symbol)
    if len(state.symbols) > 1:
        plt_total_pnl()

if __name__ == '__main__':
    import sys
    run(load_strategy(sys.argv[1]), {}, None)
