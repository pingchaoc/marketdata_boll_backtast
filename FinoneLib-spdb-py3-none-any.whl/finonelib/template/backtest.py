# -*- coding: utf-8 -*-
"""
@author: QuantInfoTech
"""

from finonelib.async_backtest import start_backtest
from finonelib.interface.api import filter_cancel_rejected
from finonelib.interface.api import filter_order_cancelled
from finonelib.interface.api import filter_order_executed
from finonelib.interface.api import filter_order_partial_executed
from finonelib.interface.api import filter_receive_transaction
from finonelib.interface.api import filter_submit_accepted
from finonelib.interface.api import filter_submit_rejected
from finonelib.interface.api import submit_orders, create_order
from finonelib.interface.exchange import BaseBackTestPattern
from finonelib.interface.exchange import fetch_orders
from finonelib.interface.exchange import on_cancel_rejected
from finonelib.interface.exchange import on_order_cancelled
from finonelib.interface.exchange import on_order_executed
from finonelib.interface.exchange import on_order_partial_executed
from finonelib.interface.exchange import on_receive_marketdata
from finonelib.interface.exchange import on_receive_heartbeat
from finonelib.interface.exchange import on_receive_transaction
from finonelib.interface.exchange import on_submit_accepted
from finonelib.interface.exchange import on_submit_rejected
from finonelib.interface.exchange import create_execution_from_order
from finonelib.interface.exchange import read_symbol_orders
from finonelib.interface.exchange import current_timestamp
from finonelib.methods import limit_orders_to_clob
from finonelib.methods import clob_to_limit_orders
from finonelib.state import state, ExecutorParams
from finonelib.structs import ClobData
from finonelib.structs import ExecutedTrade
from finonelib.structs import Execution
from finonelib.structs import ExecutionStatus
from finonelib.structs import Order
from finonelib.structs import OrderAction
from finonelib.structs import OrderOwnership
from finonelib.structs import OrderSide
from finonelib.structs import OrderType
from finonelib.structs import Repository
from finonelib.match import DefaultMatcher
import time
import random


class BackTestPattern(BaseBackTestPattern):
    
    def __init__(self):
        self.symbol_matchers = {}

    def generate_orders(self, symbol: str):
        print('BackTestPattern start generate orders')
        for timestamp, order in read_symbol_orders(symbol):
            yield order

    def match(self, symbol: str, order):
        if not symbol in self.symbol_matchers:
            self.symbol_matchers[symbol] = DefaultMatcher(symbol)
        return self.symbol_matchers[symbol].match(order)

    def finalize(self):
        print('Data playback complete, calculating performance metrics.')



def parse_settings(path):
    return {
        'START_TIME': 1530406805000,
        'END_TIME': 1530464404830,
        # 'END_TIME': 1530406835000,
        'HADOOP_MASTER_HOST': 'master.finonedev.quantinfotech.com',
        'HADOOP_WORKER_HOSTS': ['worker1.finonedev.quantinfotech.com'],
        'STRATEGY_FILE_HDFS_PATH': '/user/admin',
        'SPARK_KEY': 'spark_key',
        'PERFORMANCE': ['max_drawdown'],
        'SERVER_HOST': 'localhost',
        'RECORD_ID': '100',
        'USER_TOKEN': '00000000-0000-0000-0000-000000000000',
        'LOG_LEVEL': 'strategy',
        'ORDER_TABLE': {
            'USDCNY@CFETS': 'default.orders_usdcny_cfets_1s',
            'eurusd': 'default.orders_usdcny_cfets_1s',
        },
        'DATASOURCE': 'local',
        'LOCAL_DATA_PATH': {
            'USDCNY@CFETS': path,
            'EURUSD@CFETS': path,
        },
        'DEBUG': True,
        'STRATEGY_NAME': 'Top',
        'BACKTEST_NAME': 'LocalHs',
        'RESULT_ID': 0,
        'OUTPUT_REPORT': False,
        # 'PLAY_SPEED': 1
    }

def load_strategy(script):
    def load_module():
        import importlib.util
        spec = importlib.util.spec_from_file_location('__strategy__', script)
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        return m

    def get_strategy(m):
        import inspect
        all_clazz = inspect.getmembers(m, inspect.isclass)
        all_strategies = [cls for (_, cls) in all_clazz if cls.__module__ == '__strategy__']
        if len(all_strategies) == 0:
            raise Exception("Unable to find a strategy class")

        return all_strategies[0]

    return get_strategy(load_module())

def run(strategy, pattern_params, datapath, *args, **kwargs):
    params = ExecutorParams(strategy_params={}, 
                            pattern_params=pattern_params)
    state.initialize(strategy,
                     BackTestPattern,
                     symbols=['USDCNY@CFETS'],
                     params=params,
                     settings=parse_settings(datapath))
    start_backtest()
    from finonelib.methods import plt_position_report

    for symbol in state.symbols:
        plt_position_report(symbol)

if __name__ == '__main__':
    import sys
    clazz = None
    data = None
    if len(sys.argv) > 2:
        clazz = load_strategy(sys.argv[1])
        data = sys.argv[2]

    run(clazz, {}, data)

    