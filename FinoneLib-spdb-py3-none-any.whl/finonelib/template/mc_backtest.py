# -*- coding: utf-8 -*-
"""
@author: QuantInfoTech
"""

from datetime import datetime
from finonelib.async_backtest import start_backtest
from finonelib.interface.exchange import BaseBackTestPattern
from finonelib.match import DefaultMatcher
from finonelib.methods import clob_to_limit_orders
from finonelib.methods import limit_orders_to_clob
from finonelib.methods import OrderSimulator
from finonelib.state import state, ExecutorParams
from finonelib.structs import ClobData
from finonelib.structs import ExecutedTrade
from finonelib.structs import Execution
from finonelib.structs import ExecutionStatus
from finonelib.structs import Order
from finonelib.structs import OrderAction
from finonelib.structs import OrderOwnership
from finonelib.structs import OrderSide
from finonelib.structs import OrderType
from finonelib.structs import Repository
import random
import time


class BackTestPattern(BaseBackTestPattern):
    hb_frequency = 5
    time_points = 2000
    depth = 20
    min_move = 1
    qty_min = 10
    qty_max = 100
    init_mid_price = 65000
    init_spread = 6

    bid_limit_param_k_up = 0.4
    bid_limit_param_k_down = 0.3
    ask_limit_param_k_up = 0.4
    ask_limit_param_k_down = 0.3
    bid_limit_param_a_up = 30
    bid_limit_param_a_down = 25
    ask_limit_param_a_up = 30
    ask_limit_param_a_down = 25

    buy_mkt_order_rate_mean = 13
    buy_mkt_order_rate_var = 5
    sell_mkt_order_rate_mean = 13
    sell_mkt_order_rate_var = 5
    bid_cancel_param_k_up = 0.4
    bid_cancel_param_k_down = 0.3
    ask_cancel_param_k_up = 0.4
    ask_cancel_param_k_down = 0.3
    bid_cancel_param_a_up = 7
    bid_cancel_param_a_down = 5
    ask_cancel_param_a_up = 7
    ask_cancel_param_a_down = 5

    def __init__(self):
        self.symbol_matchers = {}

    def read_mc_orders(self, symbol: str):
        origin_time = round(datetime.strptime('2018-07-01 09:00:00', "%Y-%m-%d %H:%M:%S").timestamp() * 1000)

        simulator = OrderSimulator(symbol, self.depth, self.min_move, self.qty_min, self.qty_max)
        init_clob = simulator.get_init_clob(origin_time, self.init_mid_price, self.depth, self.init_spread)
        simulated_clob_bid_list, simulated_clob_ask_list = clob_to_limit_orders(init_clob)
        if not symbol in self.symbol_matchers:
            self.symbol_matchers[symbol] = DefaultMatcher(symbol)
        self.symbol_matchers[symbol].simulated_clob_bid_list = simulated_clob_bid_list
        self.symbol_matchers[symbol].simulated_clob_ask_list = simulated_clob_ask_list

        for _ in range(0, self.time_points):

            origin_time += self.hb_frequency * 1000
            current_time = origin_time

            simulated_clob_bid_list = self.symbol_matchers[symbol].simulated_clob_bid_list
            simulated_clob_ask_list = self.symbol_matchers[symbol].simulated_clob_ask_list
            bid_cancel_orders = simulator.get_bid_cancellation_orders(simulated_clob_bid_list,
                                                                      simulated_clob_ask_list,
                                                                      current_time, self.bid_cancel_param_a_up,
                                                                      self.bid_cancel_param_a_down,
                                                                      self.bid_cancel_param_k_up,
                                                                      self.bid_cancel_param_k_down)
            ask_cancel_orders = simulator.get_ask_cancellation_orders(simulated_clob_bid_list,
                                                                      simulated_clob_ask_list,
                                                                      current_time, self.ask_cancel_param_a_up,
                                                                      self.ask_cancel_param_a_down,
                                                                      self.ask_cancel_param_k_up,
                                                                      self.ask_cancel_param_k_down)

            bid_limit_orders = simulator.get_bid_limit_orders(simulated_clob_bid_list, simulated_clob_ask_list,
                                                              current_time, self.bid_limit_param_a_up,
                                                              self.bid_limit_param_a_down, self.bid_limit_param_k_up,
                                                              self.bid_limit_param_k_down)
            ask_limit_orders = simulator.get_ask_limit_orders(simulated_clob_bid_list, simulated_clob_ask_list,
                                                              current_time, self.ask_limit_param_a_up,
                                                              self.ask_limit_param_a_down, self.ask_limit_param_k_up,
                                                              self.ask_limit_param_k_down)

            buy_market_orders = simulator.get_buy_market_order(current_time, self.buy_mkt_order_rate_mean,
                                                               self.buy_mkt_order_rate_var)
            sell_market_orders = simulator.get_sell_market_order(current_time, self.sell_mkt_order_rate_mean,
                                                                 self.sell_mkt_order_rate_var)

            other_order_list = []
            other_order_list.extend(ask_cancel_orders)
            other_order_list.extend(bid_cancel_orders)
            other_order_list.extend(ask_limit_orders)
            other_order_list.extend(bid_limit_orders)
            other_order_list.extend(sell_market_orders)
            other_order_list.extend(buy_market_orders)

            leng = self.hb_frequency * 1000
            if leng % len(other_order_list) != 0:
                leng -= leng % len(other_order_list)

            interval = leng / len(other_order_list)

            for order in other_order_list:
                order.timestamp = int(current_time)
                current_time += interval
            yield other_order_list

    def generate_orders(self, symbol: str):
        print('BackTestPattern start generate orders')
        for orders in self.read_mc_orders(symbol):
            for order in orders:
                yield order
            while True:
                yield None
                if orders[-1].matched:
                    break

    def match(self, symbol: str, order):
        if not symbol in self.symbol_matchers:
            self.symbol_matchers[symbol] = DefaultMatcher(symbol)
        return self.symbol_matchers[symbol].match(order)

    def finalize(self):
        print('pattern finalize!')


def parse_settings(path):
    return {
        'START_TIME': 1530406805000,
        'END_TIME': 1530435604662,
        # 'END_TIME': 1530406835000,
        'HADOOP_MASTER_HOST': 'master.finonedev.quantinfotech.com',
        'HADOOP_WORKER_HOSTS': ['worker1.finonedev.quantinfotech.com'],
        'STRATEGY_FILE_HDFS_PATH': '/user/admin',
        'SPARK_KEY': 'spark_key',
        'PERFORMANCE': ['max_drawdown'],
        'SERVER_HOST': 'localhost',
        'RECORD_ID': '100',
        'USER_TOKEN': '00000000-0000-0000-0000-000000000000',
        'LOG_LEVEL': 'strategy',
        'ORDER_TABLE': {
            'USDCNY@CFETS': 'default.orders_usdcny_cfets_1s',
            'eurusd': 'default.orders_usdcny_cfets_1s',
        },
        'DATASOURCE': 'local',
        'LOCAL_DATA_PATH': {
            'USDCNY@CFETS': path,
            'eurusd': path,
        },
        'DEBUG': False,
        'STRATEGY_NAME': 'Top',
        'BACKTEST_NAME': 'LocalMc',
        'RESULT_ID': 100,
        'OUTPUT_REPORT': True,
        # 'USE_MQ': True,
        # 'MQ_TYPE': 'aws',
        # 'MQ_HOST': '',
        # 'AWS_REGION': 'cn-northwest-1',
        # 'AWS_ENV': 'xup-test',
        # 'PLAY_SPEED': 1
        'PRECISION': {
            'USDCNY@CFETS': 6,
            'eurusd': 6,
        },
        'SPARK_REDIS_HOST':'192.168.2.180',
        'SPARK_REDIS_PORT': 6379,
        'SPARK_REDIS_DB': 4,
    }


def load_strategy(script):
    def load_module():
        import importlib.util
        spec = importlib.util.spec_from_file_location('__strategy__', script)
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        return m

    def get_strategy(m):
        import inspect
        all_clazz = inspect.getmembers(m, inspect.isclass)
        all_strategies = [cls for (_, cls) in all_clazz if cls.__module__ == '__strategy__']
        if len(all_strategies) == 0:
            raise Exception("Unable to find a strategy class")

        return all_strategies[0]

    return get_strategy(load_module())


def run(strategy, pattern_params, *args, **kwargs):
    path_count = 1
    for i in range(path_count):
        settings = parse_settings('hello')
        settings['MC_PATH_COUNTER'] = str(i)
        params = ExecutorParams(strategy_params={},
                                pattern_params=pattern_params)
        state.initialize(strategy,
                         BackTestPattern,
                         symbols=['USDCNY@CFETS'],
                         params=params,
                         settings=settings)

        start_backtest()
        from finonelib.methods import plt_position_report

        for symbol in state.symbols:
            plt_position_report(symbol)


if __name__ == '__main__':
    import sys

    clazz = None
    if len(sys.argv) > 1:
        clazz = load_strategy(sys.argv[1])

    # import cProfile
    # cProfile.run("run(clazz, {})")
    run(clazz, {})
