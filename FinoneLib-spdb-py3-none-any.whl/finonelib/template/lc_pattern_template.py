# -*- coding: utf-8 -*-
"""
@author: QuantInfoTech
"""

from finonelib.interface.api import filter_cancel_rejected
from finonelib.interface.api import filter_order_cancelled
from finonelib.interface.api import filter_order_executed
from finonelib.interface.api import filter_order_partial_executed
from finonelib.interface.api import filter_receive_transaction
from finonelib.interface.api import filter_submit_accepted
from finonelib.interface.api import filter_submit_rejected
from finonelib.interface.api import submit_orders, create_order
from finonelib.interface.exchange import BaseBackTestPattern
from finonelib.interface.exchange import fetch_orders
from finonelib.interface.exchange import on_cancel_rejected
from finonelib.interface.exchange import on_order_cancelled
from finonelib.interface.exchange import on_order_executed
from finonelib.interface.exchange import on_order_partial_executed
from finonelib.interface.exchange import on_receive_marketdata
from finonelib.interface.exchange import on_receive_heartbeat
from finonelib.interface.exchange import on_receive_transaction
from finonelib.interface.exchange import on_submit_accepted
from finonelib.interface.exchange import on_submit_rejected
from finonelib.interface.exchange import create_execution_from_order
from finonelib.interface.exchange import read_symbol_ohlc
from finonelib.interface.exchange import current_timestamp
from finonelib.methods import limit_orders_to_clob
from finonelib.methods import clob_to_limit_orders
from finonelib.structs import ClobData
from finonelib.structs import ExecutedTrade
from finonelib.structs import Execution
from finonelib.structs import ExecutionStatus
from finonelib.structs import Order
from finonelib.structs import OrderAction
from finonelib.structs import OrderOwnership
from finonelib.structs import OrderSide
from finonelib.structs import OrderType
from finonelib.structs import Repository
from finonelib.match import DefaultLCMatcher
import time
import random


class BackTestPattern(BaseBackTestPattern):
    SLIPPAGE = 5
    MIN_MOVE = 0.00001
    SPREAD = 0.005

    def __init__(self):
        self.symbol_matchers = {}
        self.last_clob = None

    def generate_orders(self, symbol: str):
        print('BackTestPattern start generate orders')
        for timestamp, order in read_symbol_ohlc(symbol):
            yield order

    def match(self, symbol: str, order):
        if not symbol in self.symbol_matchers:
            self.symbol_matchers[symbol] = DefaultLCMatcher(symbol, slippage=self.SLIPPAGE, min_move=self.MIN_MOVE, spread=self.SPREAD)
        return self.symbol_matchers[symbol].match(order)

    def finalize(self):
        print('Data playback complete, calculating performance metrics.')

