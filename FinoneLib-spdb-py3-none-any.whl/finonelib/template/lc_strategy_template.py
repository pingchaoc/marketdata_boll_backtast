from finonelib.interface.api import *
from finonelib.ta import *
from finonelib import *
del globals()['logger']
import numpy as np
import pandas as pd
import time

class Strategy(object):

    ohlc_list = list()
    period = 20
    lots = 1
    upper_band = 200
    lower_band = -1
    middle_band = 100
    std = 2

    def on_receive_marketdata(self, marketdata: ClobData):
        if marketdata.p_bid_array and marketdata.p_ask_array:
            best_bid = get_best_bid_price(marketdata.symbol)
            best_ask = get_best_ask_price(marketdata.symbol)
            current_inventory = get_inventory(marketdata.symbol)
            if len(self.ohlc_list) < self.period:
                return
            if best_bid > self.upper_band:
                # 开新仓
                if current_inventory == 0:
                    order = create_order(marketdata.symbol, OrderType.LIMIT, OrderSide.BID, best_ask, self.lots)
                    order.openclose = OrderOpenClose.OPEN
                    submit_orders(order)
                    print("开多")
                # 已有多头仓位
                elif current_inventory > 0:
                    print("已有多头仓位")
                # 平空
                elif current_inventory < 0:
                    order = create_order(marketdata.symbol, OrderType.LIMIT, OrderSide.BID, best_ask, self.lots)
                    order.openclose = OrderOpenClose.CLOSE
                    submit_orders(order)
                    print("平空")

            elif best_ask < self.lower_band:
                # 开新仓
                if current_inventory == 0:
                    order = create_order(marketdata.symbol, OrderType.LIMIT, OrderSide.ASK, best_bid, self.lots)
                    order.openclose = OrderOpenClose.OPEN
                    submit_orders(order)
                    print("开空")
                # 已有空头仓位
                elif current_inventory < 0:
                    print("已有空头仓位")
                # 平多
                elif current_inventory > 0:
                    order = create_order(marketdata.symbol, OrderType.LIMIT, OrderSide.ASK, best_bid, self.lots)
                    order.openclose = OrderOpenClose.CLOSE
                    submit_orders(order)
                    print("平多")
        pass

    def on_receive_ohlc(self, ohlc: OHLCData):
        self.ohlc_list.append(ohlc)
        length = len(self.ohlc_list)
        if length < (self.period + 1):
            print("Do Nothing")
            return
        close = [ohlc.close for ohlc in self.ohlc_list[(length-1-self.period):(length-1)]]
        upperbands, middlebands, lowerbands = BBANDS(np.array(close), timeperiod=self.period, nbdevup=self.std, nbdevdn=self.std, matype=0)
        self.upper_band = upperbands[-1]
        self.lower_band = lowerbands[-1]
        self.middle_band = middlebands[-1]
        pass

    def on_receive_transaction(self, trade: ExecutedTrade):
        pass

    def on_submit_accepted(self, execution: Execution):
        pass

    def on_submit_rejected(self, execution: Execution):
        pass

    def on_cancel_rejected(self, execution: Execution):
        pass

    def on_order_partial_executed(self, execution: Execution):
        pass

    def on_order_executed(self, execution: Execution):
        pass

    def on_order_cancelled(self, execution: Execution):
        pass

    def custom_settings(self):
        return {}

    def init_econ_data(self):
        return []