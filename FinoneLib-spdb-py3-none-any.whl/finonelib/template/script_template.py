from finonelib.ta import *
from finonelib import *


class Script(object):

    output = SeriesOutput()
    model_output = ModelOutput()

    def on_receive_marketdata(self, marketdata: ClobData):
        pass

    def on_receive_ohlc(self, ohlc: OHLCData):
        pass

    def on_receive_transaction(self, trade: ExecutedTrade):
        pass

    def custom_settings(self):
        return {}

    def init_econ_data(self):
        return []