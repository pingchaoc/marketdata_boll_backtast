# -*- coding: utf-8 -*-
"""
@author: QuantInfoTech
"""

import os

BASE_DIR =os.path.dirname(os.path.abspath(__file__))

BASE_BACKTEST_TEMPLATE = ''
LP_PATTERN_TEMPLATE = ''
LP_STRATEGY_TEMPLATE = ''
LC_PATTERN_TEMPLATE = ''
LC_STRATEGY_TEMPLATE = ''
APAMA_TEMPLATE = ''
ORDERBOOK_PATTERN_TEMPLATE = ''
TRANSACTION_PATTERN_TEMPLATE = ''
SCRIPT_TEMPLATE = ''

with open(os.path.join(BASE_DIR, 'spark.py'), encoding='utf-8') as f:
    BASE_BACKTEST_TEMPLATE = f.read()

with open(os.path.join(BASE_DIR, 'lp_pattern_template.py'), encoding='utf-8') as f:
    LP_PATTERN_TEMPLATE = f.read()

with open(os.path.join(BASE_DIR, 'lp_strategy_template.py'), encoding='utf-8') as f:
    LP_STRATEGY_TEMPLATE = f.read()
    
with open(os.path.join(BASE_DIR, 'lc_pattern_template.py'), encoding='utf-8') as f:
    LC_PATTERN_TEMPLATE = f.read()

with open(os.path.join(BASE_DIR, 'lc_strategy_template.py'), encoding='utf-8') as f:
    LC_STRATEGY_TEMPLATE = f.read()

with open(os.path.join(BASE_DIR, 'script_template.py'), encoding='utf-8') as f:
    SCRIPT_TEMPLATE = f.read()

with open(os.path.join(BASE_DIR, 'apama_deploy_template.py'), encoding='utf-8') as f:
    APAMA_TEMPLATE = f.read()

with open(os.path.join(BASE_DIR, 'orderbook_pattern_template.py'), encoding='utf-8') as f:
    ORDERBOOK_PATTERN_TEMPLATE = f.read()

with open(os.path.join(BASE_DIR, 'transaction_pattern_template.py'), encoding='utf-8') as f:
    TRANSACTION_PATTERN_TEMPLATE = f.read()