from finonelib.state import state

{{STRATEGY_CODE}}