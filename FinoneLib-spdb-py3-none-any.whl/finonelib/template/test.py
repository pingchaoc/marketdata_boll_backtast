from finonelib.interface.api import *
from finonelib import *
import numpy as np
import pandas as pd
import logging
logger = logging.getLogger(__name__)
import time

class Strategy(object):
    bid_qty = 1
    ask_qty = 1
    marketdata_counter = 0
    executed_bid_counter = 0
    executed_ask_counter = 0
    submited_bid_counter = 0
    submited_ask_counter = 0
    cancelled_counter = 0

    submited_in_cancel = 0
    submited_in_marketdata = 0

    inventory = 0
    cash = 0
    acc_inventory = []
    acc_cash = []
    acc_bid_volume = []
    acc_ask_volume = []
    others_inventory = []
    others_bid_volume = [0]
    others_ask_volume = [0]

    def on_receive_marketdata(self, marketdata: ClobData):
        # print(f'on receive marketdata {time.time()}, pendings {len(get_my_pending_orders(marketdata.symbol))}')
        self.marketdata_counter += 1
        print(f'marketdata: {self.marketdata_counter}')
        # logger.warning('on_receive_marketdata')
        pending_orders = get_my_pending_orders(marketdata.symbol)
        print(f'pending bid: {len([order for order in pending_orders if order.side == OrderSide.BID])}')
        print(f'pending ask: {len([order for order in pending_orders if order.side == OrderSide.ASK])}')
        if pending_orders:
            for order in pending_orders:
                if order.side == OrderSide.BID:
                    if order.price != get_best_bid_price(marketdata.symbol):
                        cancel_orders(order)
                elif order.side == OrderSide.ASK:
                    if order.price != get_best_ask_price(marketdata.symbol):
                        cancel_orders(order)
            # cancel_orders(pending_orders)
        else:
            if marketdata.p_bid_array:
                best_bid = marketdata.p_bid_array[0]
                bid_order = create_order(marketdata.symbol, OrderType.LIMIT,OrderSide.BID, best_bid, self.bid_qty)
                submit_orders(bid_order)
            if marketdata.p_ask_array:
                best_ask = marketdata.p_ask_array[0]
                ask_order = create_order(marketdata.symbol, OrderType.LIMIT, OrderSide.ASK, best_ask, self.ask_qty)
                submit_orders(ask_order)
            self.submited_in_marketdata += 1
            print(f'submited in marketdata: {self.submited_in_marketdata}')
        pass

    def on_receive_transaction(self, trade: ExecutedTrade):
        # logger.warning('on_receive_transaction')
        if trade.ownership == OrderOwnership.OTHERS:
            side = -1 if trade.side == OrderSide.ASK else 1
            inventory = trade.qty * side
            if self.others_inventory:
                self.others_inventory.append(self.others_inventory[-1] + inventory)
            else:
                self.others_inventory.append(inventory)
            if trade.side == OrderSide.BID:
                self.others_bid_volume.append(self.others_bid_volume[-1] + trade.qty)
            else:
                self.others_ask_volume.append(self.others_ask_volume[-1] + trade.qty)
        pass

    def on_submit_accepted(self, execution: Execution):
        # logger.warning('on_receive_transaction')
        # print(f'on submit accepted {time.time()}, pendings {len(get_my_pending_orders(execution.symbol))}')
        if execution.side == OrderSide.BID:
            self.submited_bid_counter += 1
            print(f'submited bid: {self.submited_bid_counter}')
        else:
            self.submited_ask_counter += 1
            print(f'submited ask: {self.submited_ask_counter}')
        pass

    def on_submit_rejected(self, execution: Execution):
        # logger.warning('on_submit_rejected')
        pass

    def on_cancel_rejected(self, execution: Execution):
        # logger.warning('on_cancel_rejected')
        pass

    def on_order_partial_executed(self, execution: Execution):
        # logger.warning('on_order_partial_executed')
        pass

    def on_order_executed(self, execution: Execution):
        if execution.side == OrderSide.ASK:
            self.cash += execution.price * execution.qty
            self.inventory -= execution.qty
        elif execution.side == OrderSide.BID:
            self.cash -= execution.price * execution.qty
            self.inventory += execution.qty
        self.acc_cash.append(self.cash)
        self.acc_inventory.append(self.inventory)

        if execution.side == OrderSide.BID:
            self.executed_bid_counter += 1
            if self.acc_bid_volume:
                self.acc_bid_volume.append(self.acc_bid_volume[-1] + execution.qty)
            else:
                self.acc_bid_volume.append(execution.qty)
            print(f'executed bid: {self.executed_bid_counter}')
        else:
            self.executed_ask_counter += 1
            if self.acc_ask_volume:
                self.acc_ask_volume.append(self.acc_ask_volume[-1] + execution.qty)
            else:
                self.acc_ask_volume.append(execution.qty)
            print(f'executed ask: {self.executed_ask_counter}')
        # logger.warning(f'on_order_executed: {execution.order_id}')
        pass

    def on_order_cancelled(self, execution: Execution):
        self.cancelled_counter += 1
        print(f'cancelled: {self.cancelled_counter}')
        # logger.warning(f'on_order_cancelled: {execution.order_id}')
        pending_orders = get_my_pending_orders(get_symbol('marketdata'))
        if not pending_orders:
            marketdata = get_marketdata(execution.symbol, 0)
            if marketdata.p_bid_array:
                best_bid = marketdata.p_bid_array[0]
                bid_order = create_order(marketdata.symbol, OrderType.LIMIT,OrderSide.BID, best_bid, self.bid_qty)
                submit_orders(bid_order)
            if marketdata.p_ask_array:
                best_ask = marketdata.p_ask_array[0]
                ask_order = create_order(marketdata.symbol, OrderType.LIMIT,OrderSide.ASK, best_ask, self.ask_qty)
                submit_orders(ask_order)
            self.submited_in_cancel += 1
            print(f'submited in cancel: {self.submited_in_cancel}')
        pass

    def on_receive_status_update(self, repository: Repository):
        pass

    def on_receive_heartbeat(self, timestamp: int):
        pass

    def finalize(self):
        import matplotlib.pyplot as plt
        from finonelib.state import state
        plt.figure(figsize=(20, 15))
        plt.subplot(4, 2, 1)
        plt.plot([i for i in range(len(self.acc_inventory))], self.acc_inventory)
        plt.xlabel("Time")
        plt.ylabel("Inventory")
        plt.title("Inventory")
        plt.subplot(4, 2, 2)
        plt.plot([i for i in range(len(self.acc_cash))], self.acc_cash)
        plt.xlabel("Time")
        plt.ylabel("Cash")
        plt.title("Cash")
        plt.subplot(4, 2, 3)
        plt.plot([i for i in range(len(self.acc_bid_volume))], self.acc_bid_volume)
        plt.xlabel("Time")
        plt.ylabel("Bid")
        plt.title("Bid")
        plt.subplot(4, 2, 4)
        plt.plot([i for i in range(len(self.acc_ask_volume))], self.acc_ask_volume)
        plt.xlabel("Time")
        plt.ylabel("Ask")
        plt.title("Ask")
        plt.subplot(4, 2, 5)
        plt.plot([i for i in range(len(self.others_inventory))], self.others_inventory)
        plt.xlabel("Time")
        plt.ylabel("Other Inventory")
        plt.title("Other Inventory")
        plt.subplot(4, 2, 6)
        plt.plot([i for i in range(len(self.others_bid_volume))], self.others_bid_volume)
        plt.xlabel("Time")
        plt.ylabel("Other Bid vol")
        plt.title("Other ")
        plt.subplot(4, 2, 7)
        plt.plot([i for i in range(len(self.others_ask_volume))], self.others_ask_volume)
        plt.xlabel("Time")
        plt.ylabel("Other Ask vol")
        plt.title("Other Ask vol")
        plt.subplot(4, 2, 8)
        plt.plot(state.time_axis, state.total_pnl)
        plt.xlabel("Time")
        plt.ylabel("Total pnl")
        plt.title("Total pnl")
        plt.show()
        print(f'others ask vol {self.others_ask_volume[-1]}')
        print(f'others bid vol {self.others_bid_volume[-1]}')


if __name__ == '__main__':
    from finonelib.utils import run_with_template
    mc_params = {
        'hb_frequency': 5,
        'time_points': 5000,
        'depth': 20,
        'min_move': 1,
        'qty_min': 10,
        'qty_max': 100,
        'init_mid_price': 65000,
        'init_spread': 6,
        'bid_limit_param_k_up': 0.4,
        'bid_limit_param_k_down': 0.3,
        'ask_limit_param_k_up': 0.4,
        'ask_limit_param_k_down': 0.3,
        'bid_limit_param_a_up': 30,
        'bid_limit_param_a_down': 25,
        'ask_limit_param_a_up': 30,
        'ask_limit_param_a_down': 25,
        'buy_mkt_order_rate_mean': 13,
        'buy_mkt_order_rate_var': 5,
        'sell_mkt_order_rate_mean': 13,
        'sell_mkt_order_rate_var': 5,
        'bid_cancel_param_k_up': 0.4,
        'bid_cancel_param_k_down': 0.3,
        'ask_cancel_param_k_up': 0.4,
        'ask_cancel_param_k_down': 0.3,
        'bid_cancel_param_a_up': 7,
        'bid_cancel_param_a_down': 5,
        'ask_cancel_param_a_up': 7,
        'ask_cancel_param_a_down': 5,
    }
    run_with_template('backtest', Strategy, {}, './orders_mc1.csv')