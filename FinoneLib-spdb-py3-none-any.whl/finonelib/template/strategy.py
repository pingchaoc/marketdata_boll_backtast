from finonelib.structs import ClobData, Execution, ExecutedTrade, Repository, OHLCData
from finonelib.interface.api import filter_receive_transaction
from finonelib.interface.api import filter_submit_accepted
from finonelib.interface.api import filter_submit_rejected
from finonelib.interface.api import filter_cancel_rejected
from finonelib.interface.api import filter_order_partial_executed
from finonelib.interface.api import filter_order_executed
from finonelib.interface.api import filter_order_cancelled
from finonelib.interface.exchange import on_submit_accepted


class Strategy(object):

    def on_receive_marketdata(self, md0: ClobData, md1: ClobData):
        pass

    def on_receive_transaction(self, trade: ExecutedTrade):
        pass

    def on_submit_accepted(self, execution: Execution):
        pass

    def on_submit_rejected(self, execution: Execution):
        pass

    def on_cancel_rejected(self, execution: Execution):
        pass

    def on_order_partial_executed(self, execution: Execution):
        pass

    def on_order_executed(self, execution: Execution):
        pass

    def on_order_cancelled(self, execution: Execution):
        pass

    def on_receive_heartbeat(self, timestamp: int):
        pass

    def on_receive_ohlc(self, ohlc: OHLCData):
        print(ohlc.to_json())
        pass

    def custom_settings(self):
        return {}


class StrategyTypeII(object):

    def on_receive_marketdata(self, md0: ClobData, md1: ClobData):
        pass

    @filter_receive_transaction('md0')
    def on_md0_transaction(self, trade: ExecutedTrade):
        pass

    @filter_receive_transaction('md1')
    def on_md1_transaction(self, trade: ExecutedTrade):
        pass

    @filter_submit_accepted('md0')
    @filter_submit_accepted('md1')
    def on_submit_accepted(self, execution: Execution):
        pass

    @filter_submit_rejected('md0')
    @filter_submit_rejected('md1')
    def on_submit_rejected(self, execution: Execution):
        pass

    @filter_cancel_rejected('md0')
    @filter_cancel_rejected('md1')
    def on_cancel_rejected(self, execution: Execution):
        pass

    @filter_order_partial_executed('md0')
    def on_md0_order_partial_executed(self, execution: Execution):
        pass

    @filter_order_partial_executed('md1')
    def on_md1_order_partial_executed(self, execution: Execution):
        pass

    @filter_order_executed('md0')
    def on_md0_executed(self, execution: Execution):
        pass

    @filter_order_executed('md1')
    def on_md1_executed(self, execution: Execution):
        pass

    @filter_order_cancelled('md0')
    @filter_order_cancelled('md1')
    def on_order_cancelled(self, execution: Execution):
        pass

    def on_receive_heartbeat(self, timestamp: int):
        pass
