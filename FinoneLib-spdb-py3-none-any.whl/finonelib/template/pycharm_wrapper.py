

def main():
    import sys
    import importlib
    def pairwise(xs):
        it = iter(xs)
        while True:
            try:
                a = next(it)
                b = next(it)
                yield (a, b)
            except StopIteration:
                break

    template = sys.argv[1] # lc or lp
    script = sys.argv[2] # script path
    data = dict(pairwise(sys.argv[3:])) # <symbol1> <data1> <symbol2> <data2> ...

    module = importlib.import_module("finonelib.template.pycharm_{}".format(template))
    module.run(script, data)


if __name__ == '__main__':
    main()