from datetime import datetime, timedelta
from finonelib.interface.api import get_latest_marketdata_by_seconds
from finonelib.methods import clob_to_ohlc
from finonelib.state import state, fetch_orders
from finonelib.structs import ClobData
from finonelib.structs import ExecutedTrade
from finonelib.structs import Execution
from finonelib.structs import ExecutionStatus
from finonelib.structs import Inv_Duration
from finonelib.structs import OHLCData
from finonelib.structs import OHLCOrderUpdater
from finonelib.structs import Order
from finonelib.structs import OrderAction
from finonelib.structs import OrderOwnership
from finonelib.structs import OrderSide
from finonelib.structs import OrderType
from finonelib.structs import Repository
from finonelib.structs import AbstractOrder
from finonelib.utils import pass_period
from finonelib.utils import whole_minute
from typeguard import typechecked
from typing import Tuple, List, Callable, Type, Any, Union
import json
import logging
import logging
import pandas as pd
import traceback
import time
logger = logging.getLogger(__name__)


def _update_status(symbol):
    repository = state.performance_calculator.latest_repository(symbol)
    on_receive_status_update(repository)


@typechecked
def on_receive_marketdata(marketdata: ClobData) -> List[Order]:
    info = state.get_info(marketdata.symbol)
    state.get_info(marketdata.symbol).clobs.append(marketdata)
    state.latest_clobs[marketdata.symbol] = marketdata
    logger.debug(f'sending {marketdata.symbol} marketdata: {marketdata}')
    if not state.is_apama:
        # 由marketdata变化导致的performance更新应该正好在策略收到marketdata之前
        state.performance_calculator.update_marketdata(marketdata)
        _update_status(marketdata.symbol)
    state.last_updated_clob = marketdata
    state.strategy.on_receive_marketdata(*state.latest_clobs.values()) # type: ignore
    if state.is_async:
        return []
    return fetch_orders()


@typechecked
def on_receive_ohlc(ohlc: OHLCData) -> List[Order]:
    ohlc_list = state.get_info(ohlc.symbol).ohlcs
    if state.is_apama and ohlc_list:
        ohlc_list[-1].close = ohlc.close
        ohlc.close = 0
    ohlc_list.append(ohlc)
    state.latest_ohlcs[ohlc.symbol] = ohlc
    state.last_updated_ohlc = ohlc
    if hasattr(state.strategy, 'on_receive_ohlc'):
        close = ohlc.close
        # 实盘中收到的最新ohlc中不应该带close
        ohlc.close = 0
        logger.debug(f'sending {ohlc.symbol} ohlc: {ohlc}')
        state.strategy.on_receive_ohlc(*state.latest_ohlcs.values())
        # 在策略使用完这一份ohlc后把close添加回来，使得历史查询可以查到
        ohlc.close = close
        if state.is_async:
            return []
        return fetch_orders()
    return []


@typechecked
def on_receive_transaction(transaction: ExecutedTrade) -> List[Order]:
    if state.is_apama:
        ohlc_list = state.get_info(transaction.symbol).ohlcs
        if ohlc_list:
            last_ohlc = ohlc_list[-1]
            last_ohlc.high = max((transaction.price, last_ohlc.high))
            last_ohlc.low = min((transaction.price, last_ohlc.low))
    state.get_info(transaction.symbol).trade_list.append(transaction)
    callback = state.strategy_callbacks[transaction.symbol]['on_receive_transaction']
    callback(state.strategy, transaction)
    if not state.is_apama and transaction.ownership == OrderOwnership.MARKET_MAKER:
        state.get_info(transaction.symbol).maker_trade_count += 1
    if state.is_async:
        return []
    return fetch_orders()


@typechecked
def on_submit_accepted(execution: Execution) -> List[Order]:
    """
    used to called on_order_accepted
    """
    logger.debug(f'order accepted {execution}')
    state.get_info(execution.symbol).executions.append(execution)
    if not state.is_apama:
        state.performance_calculator.update_execution(execution)
    try:
        order = state.get_info(execution.symbol).pending_orders[execution.order_id]
    except KeyError as e:
        raise Exception(f'Order id {execution.order_id} is not found in pending_orders.')
    order.accepted = True
    callback = state.strategy_callbacks[execution.symbol]['on_submit_accepted']
    callback(state.strategy, execution)
    if state.is_async:
        return []
    return fetch_orders()


@typechecked
def on_submit_rejected(execution: Execution) -> List[Order]:
    """
    used to called on_order_rejected
    """
    state.get_info(execution.symbol).executions.append(execution)
    if not state.is_apama:
        state.performance_calculator.update_execution(execution)
    pending_orders = state.get_info(execution.symbol).pending_orders
    try:
        order = pending_orders[execution.order_id]
        order.accepted = False
        del pending_orders[execution.order_id]
    except KeyError as e:
        raise Exception(f'Order id {execution.order_id} is not found in pending_orders.')
    callback = state.strategy_callbacks[execution.symbol]['on_submit_rejected']
    callback(state.strategy, execution)
    if state.is_async:
        return []
    return fetch_orders()


@typechecked
def on_cancel_rejected(execution: Execution) -> List[Order]:
    state.get_info(execution.symbol).executions.append(execution)
    if not state.is_apama:
        state.performance_calculator.update_execution(execution)
    callback = state.strategy_callbacks[execution.symbol]['on_cancel_rejected']
    callback(state.strategy, execution)
    if state.is_async:
        return []
    return fetch_orders()


@typechecked
def on_order_partial_executed(execution: Execution) -> List[Order]:
    logger.debug(f'order partial executed {execution}')
    state.get_info(execution.symbol).executions.append(execution)
    if not state.is_apama:
        state.performance_calculator.update_execution(execution)
        _update_status(execution.symbol)
    try:
        order = state.get_info(execution.symbol).pending_orders[execution.order_id]
    except KeyError as e:
        raise Exception(f'Order id {execution.order_id} is not found in pending_orders.')
    order.qty -= execution.qty
    if order.qty <= 0:
        logger.error(f'partial executed made order\'s qty to {order.qty}')
    callback = state.strategy_callbacks[execution.symbol]['on_order_partial_executed']
    callback(state.strategy, execution)
    if state.is_async:
        return []
    return fetch_orders()


@typechecked
def on_order_executed(execution: Execution) -> List[Order]:
    logger.debug(f'order executed {execution}')
    state.get_info(execution.symbol).executions.append(execution)
    if not state.is_apama:
        state.performance_calculator.update_execution(execution)
        _update_status(execution.symbol)
    pending_orders = state.get_info(execution.symbol).pending_orders
    try:
        del pending_orders[execution.order_id]
    except KeyError as e:
        raise Exception(f'Order id {execution.order_id} is not found in pending_orders.')
    callback = state.strategy_callbacks[execution.symbol]['on_order_executed']
    callback(state.strategy, execution)
    if state.is_async:
        return []
    return fetch_orders()


@typechecked
def on_order_cancelled(execution: Execution) -> List[Order]:
    logger.debug(f'order cancelled {execution}')
    state.get_info(execution.symbol).executions.append(execution)
    if not state.is_apama:
        state.performance_calculator.update_execution(execution)
        _update_status(execution.symbol)
    pending_orders = state.get_info(execution.symbol).pending_orders
    try:
        del pending_orders[execution.order_id]
    except KeyError as e:
        raise Exception(f'Order id {execution.order_id} is not found in pending_orders.')
    callback = state.strategy_callbacks[execution.symbol]['on_order_cancelled']
    callback(state.strategy, execution)
    if state.is_async:
        return []
    return fetch_orders()


@typechecked
def on_receive_status_update(repository: Repository) -> None:
    info = state.get_info(repository.symbol)
    if not hasattr(info, 'bid_prices'):
        info.bid_prices = []
    if not hasattr(info, 'ask_prices'):
        info.ask_prices = []
    try:
        if info.time_axis[-1] == repository.timestamp:
            info.acc_trade_volume[-1] += abs(repository.inventory - info.acc_inventory[-1])
            info.acc_inventory[-1] = repository.inventory
            info.acc_pnl[-1] = repository.pnl
            info.acc_cash[-1] = repository.cash
            info.acc_inventory_value[-1] = repository.pnl - repository.cash
            info.reporting_acc_pnl[-1] = repository.reporting_pnl
            info.reporting_acc_cash[-1] = repository.reporting_cash

            clobs = state.performance_calculator.infos[repository.symbol].clobs
            info.bid_prices[-1] = clobs[-1].p_bid_array[0] if clobs else None
            info.ask_prices[-1] = clobs[-1].p_ask_array[0] if clobs else None
        else:
            raise IndexError('last one is not the same')
    except IndexError as e:
        info.time_axis.append(repository.timestamp)
        last_inventory = info.acc_inventory[-1] if info.acc_inventory else 0
        last_trade_volume = info.acc_trade_volume[-1] if info.acc_trade_volume else 0
        info.acc_trade_volume.append(last_trade_volume + abs(repository.inventory - last_inventory))
        info.acc_inventory.append(repository.inventory)
        info.acc_pnl.append(repository.pnl)
        info.acc_cash.append(repository.cash)
        info.acc_inventory_value.append(repository.pnl - repository.cash)
        info.reporting_acc_pnl.append(repository.reporting_pnl)
        info.reporting_acc_cash.append(repository.reporting_cash)

        clobs = state.performance_calculator.infos[repository.symbol].clobs
        info.bid_prices.append(clobs[-1].p_bid_array[0] if clobs else None)
        info.ask_prices.append(clobs[-1].p_ask_array[0] if clobs else None)
    for symbol in state.symbols:
        if symbol != repository.symbol:
            # 同步所有symbol的time_axis
            info = state.get_info(symbol)
            if not hasattr(info, 'bid_prices'):
                info.bid_prices = []
            if not hasattr(info, 'ask_prices'):
                info.ask_prices = []
            if info.time_axis:
                if info.time_axis[-1] != repository.timestamp:
                    info.time_axis.append(repository.timestamp)
                    info.acc_trade_volume.append(info.acc_trade_volume[-1])
                    info.acc_inventory.append(info.acc_inventory[-1])
                    info.acc_pnl.append(info.acc_pnl[-1])
                    info.acc_cash.append(info.acc_cash[-1])
                    info.acc_inventory_value.append(info.acc_inventory_value[-1])
                    info.reporting_acc_pnl.append(info.reporting_acc_pnl[-1])
                    info.reporting_acc_cash.append(info.reporting_acc_cash[-1])

                    clobs = state.performance_calculator.infos[symbol].clobs
                    info.bid_prices.append(clobs[-1].p_bid_array[0] if clobs else None)
                    info.ask_prices.append(clobs[-1].p_ask_array[0] if clobs else None)
            else:
                info.time_axis.append(repository.timestamp)
                info.acc_trade_volume.append(0)
                info.acc_inventory.append(0)
                info.acc_pnl.append(0)
                info.acc_cash.append(0)
                info.acc_inventory_value.append(0)
                info.reporting_acc_pnl.append(0)
                info.reporting_acc_cash.append(0)

                info.bid_prices.append(None)
                info.ask_prices.append(None)

    total_pnl = 0
    if state.settings.REPORTING_CURRENCY:
        if state.symbols == state.symbols_reportable:  # 有可能有标的没有元数据
            total_pnl = sum([state.get_info(symbol).reporting_acc_pnl[-1] for symbol in state.symbols])
        else:
            logger.warn('部分symbol无法计算reporting, reporting相关结果错误!!!')
    else:
        if len(state.symbols) == 1:
            total_pnl = info.acc_pnl[-1]
        else:
            logger.warn('多腿情况下,无reporting_currency, reporting相关结果错误!!!')
            total_pnl = sum([state.get_info(symbol).acc_pnl[-1] for symbol in state.symbols])
    state.total_pnl[repository.timestamp] = total_pnl


@typechecked
def on_receive_heartbeat(timestamp: int) -> List[Order]:
    if hasattr(state.strategy, 'on_receive_heartbeat'):
        symbol_close = {}
        for symbol in state.symbols:
            ohlcs = state.get_info(symbol).ohlcs
            if ohlcs:
                ohlc = state.get_info(symbol).ohlcs[-1]
                if timestamp - ohlc.timestamp <= state.settings.HEARTBEAT_INTERVAL:
                    symbol_close[symbol] = ohlc.close
                    ohlc.close = 0
        state.strategy.on_receive_heartbeat(timestamp) # type: ignore
        for symbol, close in symbol_close.items():
            ohlcs = state.get_info(symbol).ohlcs
            if ohlcs:
                ohlcs[-1].close = close
    if state.is_async:
        return []
    return fetch_orders()


def get_df_order(client, start, end, symbol=''):
    if state.settings.DATASOURCE == 'hadoop':
        cursor = client.raw_sql(f"SELECT `ts`, `symbol`, `price`, `qty`, `type`, `side`, `action`, `ownership` FROM {state.settings.ORDER_TABLE[symbol]['orders']} WHERE ts>={start} AND ts<{end} ORDER BY ts;", results=True)
        ret = cursor.fetchall()
        cursor.release()
        return ret
    elif state.settings.DATASOURCE == 'local':
        df_order = pd.read_csv(state.settings.LOCAL_DATA_PATH[symbol], header=0)
        header = ['ts', 'symbol', 'price', 'qty', 'type', 'side', 'action', 'ownership']
        df_order = df_order[header]
        return df_order[df_order.ts>=start][df_order.ts<end].values


def read_symbol_orders(symbol: str):
    if state.settings.DATASOURCE == 'hadoop':
        import ibis
        ibis.options.sql.default_limit = None
        hdfs = ibis.hdfs_connect(host=state.settings.HADOOP_MASTER_HOST, port=50070, user='admin')
        client = ibis.impala.connect(host=state.settings.HADOOP_WORKER_HOSTS[0], hdfs_client=hdfs)
    elif state.settings.DATASOURCE == 'local':
        client = None
    start = state.settings.START_TIME
    time_offset = 3600000 * 6 # 6 hours
    while start < state.settings.END_TIME:
        st = time.time() * 1000
        df_order = get_df_order(client, start, min(start+time_offset, state.settings.END_TIME), symbol)
        print(f'[TEST] {symbol} get_df_order end_ts: {time.time() * 1000 - st}')
        print(f'[TEST] {symbol} df_order len: {len(df_order)}')
        last_ts = 0
        ts_counter = 0
        
        for order_info in df_order:
            if order_info[0] != last_ts:
                ts_counter = 0
                state.generate_bundle_id()
                last_ts = order_info[0]
            order = Order(timestamp=order_info[0] + ts_counter,
                          symbol=order_info[1],
                          price=round(float(order_info[2]), state.get_precision_by_symbol(symbol)),
                          qty=order_info[3],
                          order_type=order_info[4],
                          side=order_info[5],
                          action=order_info[6],
                          ownership=order_info[7],
                          bundle_id=state.get_bundle_id())
            if order.price < 0 or order.qty <= 0 or (order.price == 0 and order.order_type == OrderType.LIMIT):
                logger.error(f'got an invalid other order {order}')
                continue
            #this order is not from maker, set order_id to -1
            order.order_id = -1
            order.market_order_id = state.generate_market_order_id()
            ts_counter += 1
            # logger.debug(f'current order id {order.order_id}')
            yield last_ts, order
        start += time_offset

@typechecked
def create_execution_from_order(order: Order,
                                status: str,
                                qty: Union[int, float] = None) -> Execution:
    execution = Execution(timestamp=state.timestamp,
                          symbol=order.symbol,
                          price=order.price,
                          qty=qty or order.qty,
                          order_type=order.order_type,
                          side=order.side,
                          order_id=order.order_id,
                          market_order_id=order.market_order_id,
                          bundle_id=order.bundle_id,
                          status=status,
                          ownership=order.ownership)
    return execution


@typechecked
def create_trade_from_execution(execution: Execution) -> ExecutedTrade:
    trade = ExecutedTrade(execution.timestamp, execution.symbol, execution.price, execution.qty, execution.ownership)
    return trade


@typechecked
def current_timestamp() -> int:
    return state.timestamp


def fetch_metadata(symbol):
    return state.get_metadata_by_symbol(symbol)

def fetch_precision(symbol):
    return state.get_precision_by_symbol(symbol)

class BaseBackTestPattern(object):

    def __getattribute__(self, item):
        if item in ['generate_orders', 'match']:
            if not item in dir(self):
                def not_implemented_function(*args, **kwargs):
                    raise NotImplementedError(f'method {item} is not defined in your BackTestPattern Class!')
                return not_implemented_function
            else:
                return object.__getattribute__(self, item)
        else:
            return object.__getattribute__(self, item)


def get_df_ohlc(client, start, end, symbol=''):
    if state.settings.DATASOURCE == 'hadoop':
        cursor = client.raw_sql(f"SELECT `ts`, `symbol`, `open`, `high`, `low`, `close`, `volume` FROM {state.settings.ORDER_TABLE[symbol]['ohlc']} WHERE ts>={start} AND ts<{end} ORDER BY ts;", results=True)
        ret = cursor.fetchall()
        cursor.release()
        return ret
    elif state.settings.DATASOURCE == 'local':
        df_order = pd.read_csv(state.settings.LOCAL_DATA_PATH[symbol], header=0, float_precision='round_trip')
        header = ['ts', 'symbol', 'open', 'high', 'low', 'close', 'volume']
        df_order = df_order[header]
        return df_order[df_order.ts>=start][df_order.ts<end].values

def read_symbol_ohlc(symbol: str):
    if state.settings.DATASOURCE == 'hadoop':
        import ibis
        ibis.options.sql.default_limit = None
        hdfs = ibis.hdfs_connect(host=state.settings.HADOOP_MASTER_HOST, port=50070, user='admin')
        client = ibis.impala.connect(host=state.settings.HADOOP_WORKER_HOSTS[0], hdfs_client=hdfs)
    elif state.settings.DATASOURCE == 'local':
        client = None
    start = state.settings.START_TIME
    time_offset = 3600000 * 24 * 60 # 30days, ohlc usually have less data within same amount of time as tickdata
    empty_data = True
    while start <= state.settings.END_TIME:
        st = time.time() * 1000
        df_ohlc = get_df_ohlc(client, start, min(start+time_offset, state.settings.END_TIME), symbol)
        print(f'[TEST] {symbol} get_df_ohlc end_ts: {time.time() * 1000 - st}')
        print(f'[TEST] {symbol} df_ohlc len: {len(df_ohlc)}')
        last_ts = 0
        ts_counter = 0
        precision = state.get_precision_by_symbol(symbol)
        for order_info in df_ohlc:
            if order_info[0] != last_ts:
                ts_counter = 0
                state.generate_bundle_id()
                last_ts = order_info[0]
            order = OHLCOrderUpdater(timestamp=order_info[0] + ts_counter,
                                     symbol=order_info[1],
                                     open=round(float(order_info[2]), precision),
                                     high=round(float(order_info[3]), precision),
                                     low=round(float(order_info[4]), precision),
                                     close=round(float(order_info[5]), precision),
                                     bundle_id=state.get_bundle_id())
            #this order is not from maker, set order_id to -1
            order.order_id = -1
            order.market_order_id = state.generate_market_order_id()
            ts_counter += 1
            empty_data = False
            yield last_ts, order
        start += time_offset
    if empty_data:
        raise Exception(f"{symbol} 所选时间段不包含任何数据，回测将退出...")


def get_df_orderbook(client, start, end, symbol=''):
    if state.settings.DATASOURCE == 'hadoop':
        db = client.database(state.settings.ORDER_TABLE[symbol]['orderbook'].split('.')[0])
        table_order = db.table(state.settings.ORDER_TABLE[symbol]['orderbook'].split('.')[1])
        condition = [table_order.ts>=start, table_order.ts<end]
        df_order = table_order.filter(condition).sort_by(['ts']).execute()
        return df_order.drop_duplicates('ts')
    elif state.settings.DATASOURCE == 'local':
        df_order = pd.read_csv(state.settings.LOCAL_DATA_PATH[symbol], header=0, float_precision='round_trip')
        return df_order[df_order.ts>=start][df_order.ts<end]

def read_symbol_orderbook(symbol: str):
    if state.settings.DATASOURCE == 'hadoop':
        import ibis
        ibis.options.sql.default_limit = None
        hdfs = ibis.hdfs_connect(host=state.settings.HADOOP_MASTER_HOST, port=50070, user='admin')
        client = ibis.impala.connect(host=state.settings.HADOOP_WORKER_HOSTS[0], hdfs_client=hdfs)
    elif state.settings.DATASOURCE == 'local':
        client = None
    start = state.settings.START_TIME
    time_offset = 3600000 * 24 * 1 # 1days
    empty_data = True
    while start <= state.settings.END_TIME:
        df_orderbook = get_df_orderbook(client, start, min(start+time_offset, state.settings.END_TIME), symbol)
        last_ts = 0
        ts_counter = 0
        precision = state.get_precision_by_symbol(symbol)
        for row in df_orderbook.iterrows():
            order_info = row[1]
            if order_info['ts'] != last_ts:
                ts_counter = 0
                state.generate_bundle_id()
                last_ts = order_info['ts']
            order = AbstractOrder()
            order.timestamp = order_info['ts'] + ts_counter
            order.symbol = order_info['symbol']
            del order_info['ts']
            del order_info['symbol']
            for key, value in order_info.items():
                try:
                    order_info[key] = round(float(value), precision)
                except Exception as e:
                    order_info[key] = value
            order.__rawdata__ = order_info
            order.ownership = OrderOwnership.OTHERS
            order.bundle_id = state.get_bundle_id()
            ts_counter += 1
            empty_data = False
            yield last_ts, order
        start += time_offset
    if empty_data:
        raise Exception(f"{symbol} 所选时间段不包含任何数据，回测将退出...")


def get_df_transaction(client, start, end, symbol=''):
    if state.settings.DATASOURCE == 'hadoop':
        db = client.database(state.settings.ORDER_TABLE[symbol]['transaction'].split('.')[0])
        table_order = db.table(state.settings.ORDER_TABLE[symbol]['transaction'].split('.')[1])
        condition = [table_order.ts>=start, table_order.ts<end]
        df_order = table_order.filter(condition).sort_by(['ts']).execute()
        return df_order.drop_duplicates('ts')
    elif state.settings.DATASOURCE == 'local':
        df_order = pd.read_csv(state.settings.LOCAL_DATA_PATH[symbol], header=0, float_precision='round_trip')
        return df_order[df_order.ts>=start][df_order.ts<end]

def read_symbol_transaction(symbol: str):
    if state.settings.DATASOURCE == 'hadoop':
        import ibis
        ibis.options.sql.default_limit = None
        hdfs = ibis.hdfs_connect(host=state.settings.HADOOP_MASTER_HOST, port=50070, user='admin')
        client = ibis.impala.connect(host=state.settings.HADOOP_WORKER_HOSTS[0], hdfs_client=hdfs)
    elif state.settings.DATASOURCE == 'local':
        client = None
    start = state.settings.START_TIME
    time_offset = 3600000 * 24 * 1 # 1days
    empty_data = True
    while start <= state.settings.END_TIME:
        df_transaction = get_df_transaction(client, start, min(start+time_offset, state.settings.END_TIME), symbol)
        last_ts = 0
        ts_counter = 0
        precision = state.get_precision_by_symbol(symbol)
        for row in df_transaction.iterrows():
            order_info = row[1]
            if order_info['ts'] != last_ts:
                ts_counter = 0
                state.generate_bundle_id()
                last_ts = order_info['ts']
            order = AbstractOrder()
            order.timestamp = order_info['ts'] + ts_counter
            order.symbol = order_info['symbol']
            del order_info['ts']
            del order_info['symbol']
            for key, value in order_info.items():
                if key == "side":
                    continue
                try:
                    order_info[key] = round(float(value), precision)
                except Exception as e:
                    order_info[key] = value
            order.__rawdata__ = order_info
            order.ownership = OrderOwnership.OTHERS
            order.bundle_id = state.get_bundle_id()
            ts_counter += 1
            empty_data = False
            yield last_ts, order
        start += time_offset
    if empty_data:
        raise Exception(f"{symbol} 所选时间段不包含任何数据，回测将退出...")
