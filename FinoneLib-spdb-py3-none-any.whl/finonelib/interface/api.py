from finonelib.state import state
from finonelib.structs import ClobData
from finonelib.structs import OHLCData
from finonelib.structs import ExecutedTrade
from finonelib.structs import Execution
from finonelib.structs import ExecutionStatus
from finonelib.structs import Order
from finonelib.structs import OrderAction
from finonelib.structs import OrderOwnership
from finonelib.structs import OrderSide
from finonelib.structs import OrderType
from finonelib.structs import EconData
from finonelib.structs import StopPNL
from typeguard import typechecked
from typing import Tuple, List, Union, Callable
from copy import deepcopy
import logging
import bisect
import datetime
import pytz

logger = logging.getLogger(__name__)


@typechecked
def submit_orders(orders: Union[Order, List[Order]], stop: StopPNL=None) -> None:
    if not isinstance(orders, list):
        orders = [orders]
    elif len(orders) > 1 and stop is not None:
        raise ValueError(f'You can not set a stop order when submitting multiple orders')
    for order in orders:
        if order.qty <= 0:
            raise ValueError(f'You can not submit an order with qty: {order.qty} \norder: {order}')
        if order.price < 0:
            raise ValueError(f'You can not submit an order with price: {order.price} \norder: {order}')
        if order.order_type not in [OrderType.LIMIT, OrderType.MARKET]:
            raise ValueError(f'You can not submit an order with order_type: {order.order_type} \norder: {order}')
        if order.side not in [OrderSide.BID, OrderSide.ASK]:
            raise ValueError(f'You can not submit an order with side: {order.side} \norder: {order}')
        if order.order_type == OrderType.LIMIT and order.price == 0:
            raise ValueError(f'You can not submit an LIMIT order with 0 price')
    for order in orders:
        order.order_id = state.generate_order_id()
        order.price = round(float(order.price), state.get_precision_by_symbol(order.symbol))
        order = deepcopy(order)
        info = state.get_info(order.symbol)
        info.orders.append(order)
        info.pending_orders[order.order_id] = order
        state.trade_adapter.submit_single_order(order)
        if stop:
            stop.order = order
            state.stop_profit_loss_triggers[order.order_id] = deepcopy(stop)



@typechecked
def create_order(symbol: str,
                 order_type: int,
                 side: int,
                 price: Union[int, float],
                 qty: Union[int, float],
                 tag: str = '') -> Order:
    if qty <= 0:
        raise ValueError(f'You can not create an order with qty: {qty}')
    if price < 0:
        raise ValueError(f'You can not create an order with price: {price}')
    if order_type not in [OrderType.LIMIT, OrderType.MARKET]:
        raise ValueError(f'You can not create an order with order_type: {order_type}')
    if side not in [OrderSide.BID, OrderSide.ASK]:
        raise ValueError(f'You can not create an order with side: {side}')
    if order_type == OrderType.LIMIT and price == 0:
        raise ValueError(f'You can not create an LIMIT order with 0 price')
    if type(tag) != str:
        raise ValueError(f'the tag must be string!!!')
    timestamp = state.timestamp
    order = Order(timestamp, symbol,
                  price, qty, order_type, side,
                  OrderAction.PLACE, OrderOwnership.MARKET_MAKER,
                  bundle_id=state.get_bundle_id(), tag=tag)
    return order


@typechecked
def get_symbol(argname: str) -> str:
    return state.symbol_by_argname[argname]


@typechecked
def get_marketdata(symbol: str, count: int = 0) -> Union[ClobData, None]:
    if count < 0:
        raise ValueError('get_marketdata count can not < 0')
    count += 1
    clobs = state.get_info(symbol).clobs
    if len(clobs) < count:
        return None
    else:
        return clobs[-count]


@typechecked
def get_total_marketdata(symbol: str) -> List[ClobData]:
    return state.get_info(symbol).clobs


@typechecked
def get_ohlc(symbol: str, count: int = 0) -> Union[OHLCData, None]:
    if count < 0:
        raise ValueError('get_ohlc count can not < 0')
    count += 1
    ohlcs = state.get_info(symbol).ohlcs
    if len(ohlcs) < count:
        return None
    else:
        return ohlcs[-count]


@typechecked
def get_total_ohlc(symbol: str, limit: int=1000) -> List[OHLCData]:
    return state.get_info(symbol).ohlcs[-limit:]


@typechecked
def extract_from_ohlc(ohlcs: List[OHLCData], attribute: str="close") -> List[float]:
    if not attribute in ('open', 'high', 'low', 'close'):
        raise ValueError('attribute must be one of ("open", "high", "low", "close")')
    return [getattr(ohlc, attribute) for ohlc in ohlcs]


@typechecked
def get_marketdata_length(symbol: str) -> int:
    info = state.get_info(symbol)
    return len(info.clobs)


@typechecked
def get_ohlc_length(symbol: str) -> int:
    info = state.get_info(symbol)
    return len(info.ohlcs)


@typechecked
def get_my_pending_orders(symbol: str, include_unaccepted=True) -> List[Order]:
    if include_unaccepted:
        order_list = [order for order in state.get_info(symbol).pending_orders.values()]
    else:
        order_list = [order for order in state.get_info(symbol).pending_orders.values() if order.accepted==True]
    order_list.sort(key=lambda x: x.timestamp)
    return deepcopy(order_list)

@typechecked
def get_pending_bid_qty(symbol: str, include_unaccepted=True) -> int:
    if include_unaccepted:
        order_list = [order for order in state.get_info(symbol).pending_orders.values()]
    else:
        order_list = [order for order in state.get_info(symbol).pending_orders.values() if order.accepted==True]
    return sum([order.qty for order in order_list if order.side == OrderSide.BID] + [0])


@typechecked
def get_pending_ask_qty(symbol: str, include_unaccepted=True) -> int:
    if include_unaccepted:
        order_list = [order for order in state.get_info(symbol).pending_orders.values()]
    else:
        order_list = [order for order in state.get_info(symbol).pending_orders.values() if order.accepted==True]
    return sum([order.qty for order in order_list if order.side == OrderSide.ASK] + [0])


@typechecked
def cancel_orders(orders: Union[Order, List[Order]]) -> None:
    if not isinstance(orders, list):
        orders = [orders]
    # cancel单和place单是独立的order,但是order_id相同
    orders = deepcopy(orders)
    for order in orders:
        order.timestamp = state.timestamp
        order.action = OrderAction.CANCEL
        info = state.get_info(order.symbol)
        info.orders.append(order)
    state.trade_adapter.submit_orders(orders)


@typechecked
def get_market_trades(symbol: str) -> List[ExecutedTrade]:
    trade_list = state.get_info(symbol).trade_list
    return list(filter(lambda x: x.ownership == OrderOwnership.OTHERS, trade_list))


@typechecked
def get_my_trades(symbol) -> List[ExecutedTrade]:
    trade_list = state.get_info(symbol).trade_list
    return list(filter(lambda x: x.ownership == OrderOwnership.MARKET_MAKER, trade_list))


@typechecked
def get_latest_market_trade(symbol: str, count: int = 0) -> Union[ExecutedTrade, None]:
    if count < 0:
        raise ValueError('get_latest_market_trade count can not < 0')
    trade_list = get_market_trades(symbol)
    count += 1
    if len(trade_list) < count:
        return None
    else:
        return trade_list[-count]


@typechecked
def get_my_latest_trade(symbol: str, count: int = 0) -> Union[ExecutedTrade, None]:
    if count < 0:
        raise ValueError('get_my_latest_trade count can not < 0')
    trade_list = get_my_trades(symbol)
    count += 1
    if trade_list:
        return trade_list[-count]
    return None


@typechecked
def get_best_bid_price(symbol: str) -> Union[int, float, None]:
    clobs = state.get_info(symbol).clobs
    ohlcs = state.get_info(symbol).ohlcs
    last_clob = clobs[-1] if clobs else None
    last_ohlc = ohlcs[-1] if ohlcs else None
    if not last_clob and not last_ohlc:
        return None
    elif not last_clob:
        return last_ohlc.open
    if not state.is_apama and last_ohlc and last_ohlc.timestamp > last_clob.timestamp:
        return last_ohlc.open
    else:
        if last_clob.p_bid_array:
            return last_clob.p_bid_array[0]
        else:
            return None


@typechecked
def get_best_bid_qty(symbol: str) -> Union[int, float, None]:
    clobs = state.get_info(symbol).clobs
    if clobs:
        q_bid_array = clobs[-1].q_bid_array
        if q_bid_array:
            return q_bid_array[0]
        return None
    return None


@typechecked
def get_best_ask_price(symbol: str) -> Union[int, float, None]:
    clobs = state.get_info(symbol).clobs
    ohlcs = state.get_info(symbol).ohlcs
    last_clob = clobs[-1] if clobs else None
    last_ohlc = ohlcs[-1] if ohlcs else None
    if not last_clob and not last_ohlc:
        return None
    elif not last_clob:
        if hasattr(state.pattern, 'SPREAD'):
            return round(last_ohlc.open + state.pattern.SPREAD, 6)
        return round(last_ohlc.open, 6)
    if not state.is_apama and last_ohlc and last_ohlc.timestamp > last_clob.timestamp:
        if hasattr(state.pattern, 'SPREAD'):
            return round(last_ohlc.open + state.pattern.SPREAD, 6)
        return round(last_ohlc.open, 6)
    else:
        if last_clob.p_ask_array:
            return last_clob.p_ask_array[0]
        else:
            return None


@typechecked
def get_best_ask_qty(symbol: str) -> Union[int, float, None]:
    clobs = state.get_info(symbol).clobs
    if clobs:
        q_ask_array = clobs[-1].q_ask_array
        if q_ask_array:
            return q_ask_array[0]
        return None
    return None


@typechecked
def get_pnl(count: int = 0) -> Union[int, float]:
    if count < 0:
        raise ValueError('get_pnl count can not < 0')
    # 获取最近count+1位置的pnl数据
    count += 1
    if len(state.total_pnl) < count:
        return 0
    else:
        ts = state.get_info(state.symbols[0]).time_axis[-count]
        return state.total_pnl[ts]


@typechecked
def get_inventory(symbol: str, count: int = 0) -> Union[int, float]:
    if count < 0:
        raise ValueError('get_inventory count can not < 0')
    acc_inventory = state.get_info(symbol).acc_inventory
    count += 1
    if len(acc_inventory) < count:
        return 0
    else:
        return acc_inventory[-count]


@typechecked
def get_cash_balance(symbol: str, count: int = 0) -> Union[int, float]:
    if count < 0:
        raise ValueError('get_cash_balance count can not < 0')
    acc_cash = state.get_info(symbol).acc_cash
    count += 1
    if len(acc_cash) < count:
        return 0
    else:
        return acc_cash[-count]


def timestamp2datetime(ts):
    tz = state.settings.TIME_ZONE
    return datetime.datetime.fromtimestamp(ts/1000, tz=pytz.timezone(tz))

@typechecked
def get_latest_marketdata_by_seconds(symbol: str, seconds: int) -> List[ClobData]:
    clobs = state.get_info(symbol).clobs
    index = len(clobs) - 1
    while index >= 0:
        if state.timestamp - clobs[index].timestamp > seconds * 1000:
            return clobs[index+1:]
        index -= 1
    return clobs[:]


def get_last_updated_marketdata() -> ClobData:
    return state.last_updated_clob


def get_last_updated_ohlc() -> OHLCData:
    return state.last_updated_ohlc

def export(*args, **kwargs):
    """
    用于脚本输出数据结果
    """
    pass

@typechecked
def get_econ_data(name_country: str, start_ts: int, end_ts:int) -> List[EconData]:
    econdata = state.econdata[name_country] if name_country in state.econdata else None
    if not econdata:
        return []
    ts_list = econdata[0]
    obj_list = econdata[1]
    if ts_list:
        start_index = bisect.bisect_left(ts_list, start_ts)
        end_index = bisect.bisect_right(ts_list, end_ts) - 1
        return obj_list[start_index: end_index+1]
    else:
        return []


# decorators
def filter_callback(callback_name: str, marketdata_name: str) -> Callable:
    """
    Args:
        callback_name: the function name of callback in AVAILABLE_CALLBACK_NAMES
        marketdata_name: indicates the name of a specific marketdata
    """
    def filter_decorator(func):
        logger.debug(f'bind {marketdata_name} {callback_name} with {func}')
        if not marketdata_name in state.strategy_callbacks:
            state.strategy_callbacks[marketdata_name] = {}
        if state.strategy_callbacks[marketdata_name].get(callback_name, None):
            raise ValueError(f'duplicated {callback_name} callback for {marketdata_name}')
        else:
            state.strategy_callbacks[marketdata_name][callback_name] = func

        def filter_wrapper(*args, **kwargs):
            return func(*args, **kwargs)
        return filter_wrapper
    return filter_decorator


@typechecked
def filter_receive_transaction(marketdata_name: str) -> Callable:
    return filter_callback('on_receive_transaction', marketdata_name)


@typechecked
def filter_submit_accepted(marketdata_name: str) -> Callable:
    return filter_callback('on_submit_accepted', marketdata_name)


@typechecked
def filter_submit_rejected(marketdata_name: str) -> Callable:
    return filter_callback('on_submit_rejected', marketdata_name)


@typechecked
def filter_cancel_rejected(marketdata_name: str) -> Callable:
    return filter_callback('on_cancel_rejected', marketdata_name)


@typechecked
def filter_order_partial_executed(marketdata_name: str) -> Callable:
    return filter_callback('on_order_partial_executed', marketdata_name)


@typechecked
def filter_order_executed(marketdata_name: str) -> Callable:
    return filter_callback('on_order_executed', marketdata_name)


@typechecked
def filter_order_cancelled(marketdata_name: str) -> Callable:
    return filter_callback('on_order_cancelled', marketdata_name)


@typechecked
def use_script(script_name: str):
    def script_decorator(func):
        logger.debug(f'bind {script_name} to {func}')
        if script_name in state.script_callbacks:
            raise ValueError(f'duplicated callback {func} for script {script_name}')
        state.script_callbacks[script_name] = func

        def callback_wrapper(*args, **kwargs):
            return func(*args, **kwargs)
        return callback_wrapper
    return script_decorator
