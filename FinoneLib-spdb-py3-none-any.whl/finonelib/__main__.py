# -*- coding: utf-8 -*-
"""
@author: QuantInfoTech
"""

def save_server_url(*args):
    import finonelib
    path = f'{finonelib.__path__[0]}/.server'
    if args[2] == 'clear':
        import os
        if os.path.exists(path):
            os.remove(path)
    else:
        url = args[2]
        assert url
        with open(path, 'w') as f:
            f.write(url)
    
def cache_metadata(*args):
    import finonelib
    path = f'{finonelib.__path__[0]}/.metadata'
    if args[2] == 'clear':
        import os
        if os.path.exists(path):
            os.remove(path)
    elif args[2] == 'fetch':
        from finonelib.state import state
        state.request_metadata()

if __name__ == '__main__':
    import os
    import sys
    import finonelib
    cmd_functions = {
        'server': save_server_url,
        'metadata': cache_metadata,
    }
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        if cmd_functions.get(cmd):
            cmd_functions[cmd](*sys.argv)
