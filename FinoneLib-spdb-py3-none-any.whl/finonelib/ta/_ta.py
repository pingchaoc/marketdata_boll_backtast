# -*- coding: utf-8 -*-
"""
@author: QuantInfoTech
"""

from finonelib.utils import MetaReadOnly
import functools
import numpy as _np
import pandas as _pd
import talib


class MAType(object, metaclass=MetaReadOnly):
    DEMA = talib.MA_Type.DEMA
    EMA = talib.MA_Type.EMA
    KAMA = talib.MA_Type.KAMA
    MAMA = talib.MA_Type.MAMA
    SMA = talib.MA_Type.SMA
    T3 = talib.MA_Type.T3
    TEMA = talib.MA_Type.TEMA
    TRIMA = talib.MA_Type.TRIMA
    WMA = talib.MA_Type.WMA


def parse_args(*args):
    returns = []
    for arg in args:
        if not isinstance(arg, _np.ndarray) or not isinstance(arg, _pd.Series):
            returns.append(_np.array(arg))
        else:
            returns.append(arg)
    return returns


def latest_point(*args, **kwargs):
    return (arg[-1] for arg in args[0])


def _ta_single_point(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        result = func(*args, **kwargs)
        if kwargs.get('single_point', False):
            result = [r[-1] for r in result]
        return tuple(result)
    return wrapper


# Overlap Studies
@_ta_single_point
def BBANDS(close, timeperiod=5, nbdevup=2, nbdevdn=2, matype=0, single_point=False):
    close, = parse_args(close)
    return talib.BBANDS(close, timeperiod, nbdevup, nbdevdn, matype)


@_ta_single_point
def DEMA(close, timeperiod=30, single_point=False):
    close, = parse_args(close)
    return talib.DEMA(close, timeperiod)


@_ta_single_point
def EMA(close, timeperiod=30, single_point=False):
    close, = parse_args(close)
    return talib.EMA(close, timeperiod)


@_ta_single_point
def HT_TRENDLINE(close, single_point=False):
    close, = parse_args(close)
    return talib.HT_TRENDLINE(close)


@_ta_single_point
def KAMA(close, timeperiod=30, single_point=False):
    close, = parse_args(close)
    return talib.KAMA(close, timeperiod)


@_ta_single_point
def MA(close, timeperiod=30, matype=0, single_point=False):
    close, = parse_args(close)
    return talib.MA(close, timeperiod, matype)


@_ta_single_point
def MAMA(close, fastlimit=-4e37, slowlimit=-4e37, single_point=False):
    # the default param value is not quite same as their doc says
    close, = parse_args(close)
    return talib.MAMA(close, fastlimit, slowlimit)


@_ta_single_point
def MAVP(close, periods, minperiod=2, maxperiod=30, matype=0, single_point=False):
    close, periods = parse_args(close, periods)
    return talib.MAVP(close, periods, minperiod, maxperiod, matype)


@_ta_single_point
def MIDPOINT(close, timeperiod=14, single_point=False):
    close, = parse_args(close)
    return talib.MIDPOINT(close, timeperiod)


@_ta_single_point
def MIDPRICE(high, low, timeperiod=14, single_point=False):
    high, low = parse_args(high, low)
    return talib.MIDPRICE(high, low, timeperiod)


@_ta_single_point
def SAR(high, low, acceleration=0.02, maximum=0.2, single_point=False):
    high, low = parse_args(high, low)
    return talib.SAR(high, low, acceleration, maximum)


@_ta_single_point
def SAREXT(high, low, startvalue=-4e37, offsetonreverse=-4e37, accelerationinitlong=-4e37, accelerationlong=-4e37, accelerationmaxlong=-4e37, accelerationinitshort=-4e37, accelerationshort=-4e37, accelerationmaxshort=-4e37, single_point=False):
    high, low, = parse_args(high, low)
    return talib.SAREXT(high, low, startvalue, offsetonreverse, accelerationinitlong, accelerationlong, accelerationmaxlong, accelerationinitshort, accelerationshort, accelerationmaxshort)


@_ta_single_point
def SMA(close, timeperiod=30, single_point=False):
    close, = parse_args(close)
    return talib.SMA(close, timeperiod)


@_ta_single_point
def T3(close, timeperiod=-2**31, vfactor=-4e37, single_point=False):
    close, = parse_args(close)
    return talib.T3(close, timeperiod, vfactor)


@_ta_single_point
def TEMA(close, timeperiod=30, single_point=False):
    close, = parse_args(close)
    return talib.TEMA(close, timeperiod)


@_ta_single_point
def TRIMA(close, timeperiod=30, single_point=False):
    close, = parse_args(close)
    return talib.TRIMA(close, timeperiod)


@_ta_single_point
def WMA(close, timeperiod=30, single_point=False):
    close, = parse_args(close)
    return talib.WMA(close, timeperiod)


# Momentum Indicator
@_ta_single_point
def ADX(high, low, close, timeperiod=14, single_point=False):
    high, low, close, = parse_args(high, low, close)
    return talib.ADX(high, low, close, timeperiod)


@_ta_single_point
def ADXR(high, low, close, timeperiod=14, single_point=False):
    high, low, close, = parse_args(high, low, close)
    return talib.ADXR(high, low, close, timeperiod)


@_ta_single_point
def APO(close, fastperiod=12, slowperiod=26, matype=0, single_point=False):
    close, = parse_args(close)
    return talib.APO(close, fastperiod, slowperiod, matype)


@_ta_single_point
def AROON(high, low, timeperiod=14, single_point=False):
    high, low, = parse_args(high, low)
    return talib.AROON(high, low, timeperiod)


@_ta_single_point
def AROONOSC(high, low, timeperiod=14, single_point=False):
    high, low, = parse_args(high, low)
    return talib.AROONOSC(high, low, timeperiod)


@_ta_single_point
def BOP(open, high, low, close, single_point=False):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.BOP(open, high, low, close)


@_ta_single_point
def CCI(high, low, close, timeperiod=14, single_point=False):
    high, low, close, = parse_args(high, low, close)
    return talib.CCI(high, low, close, timeperiod)


@_ta_single_point
def CMO(close, timeperiod=14, single_point=False):
    close, = parse_args(close)
    return talib.CMO(close, timeperiod)


@_ta_single_point
def DX(high, low, close, timeperiod=14, single_point=False):
    high, low, close, = parse_args(high, low, close)
    return talib.DX(high, low, close, timeperiod)


@_ta_single_point
def MACD(close, fastperiod=12, slowperiod=26, signalperiod=9, single_point=False):
    close, = parse_args(close)
    return talib.MACD(close, fastperiod, slowperiod, signalperiod)


@_ta_single_point
def MACDEXT(close, fastperiod=12, fastmatype=0, slowperiod=26, slowmatype=0, signalperiod=9, signalmatype=0, single_point=False):
    close, = parse_args(close)
    return talib.MACDEXT(close, fastperiod, fastmatype, slowperiod, slowmatype, signalperiod, signalmatype)


@_ta_single_point
def MACDFIX(close, signalperiod=9, single_point=False):
    close, = parse_args(close)
    return talib.MACDFIX(close, signalperiod)


@_ta_single_point
def MFI(high, low, close, volume, timeperiod=14, single_point=False):
    high, low, close, volume, = parse_args(high, low, close, volume)
    return talib.MFI(high, low, close, volume, timeperiod)


@_ta_single_point
def MINUS_DI(high, low, close, timeperiod=14, single_point=False):
    high, low, close, = parse_args(high, low, close)
    return talib.MINUS_DI(high, low, close, timeperiod)


@_ta_single_point
def MINUS_DM(high, low, timeperiod=14, single_point=False):
    high, low, = parse_args(high, low)
    return talib.MINUS_DM(high, low, timeperiod)


@_ta_single_point
def MOM(close, timeperiod=10, single_point=False):
    close, = parse_args(close)
    return talib.MOM(close, timeperiod)


@_ta_single_point
def PLUS_DI(high, low, close, timeperiod=14, single_point=False):
    high, low, close, = parse_args(high, low, close)
    return talib.PLUS_DI(high, low, close, timeperiod)


@_ta_single_point
def PLUS_DM(high, low, timeperiod=14, single_point=False):
    high, low, = parse_args(high, low)
    return talib.PLUS_DM(high, low, timeperiod)


@_ta_single_point
def PPO(close, fastperiod=12, slowperiod=26, matype=0, single_point=False):
    close, = parse_args(close)
    return talib.PPO(close, fastperiod, slowperiod, matype)


@_ta_single_point
def ROC(close, timeperiod=10, single_point=False):
    close, = parse_args(close)
    return talib.ROC(close, timeperiod)


@_ta_single_point
def ROCP(close, timeperiod=10, single_point=False):
    close, = parse_args(close)
    return talib.ROCP(close, timeperiod)


@_ta_single_point
def ROCR(close, timeperiod=10, single_point=False):
    close, = parse_args(close)
    return talib.ROCR(close, timeperiod)


@_ta_single_point
def ROCR100(close, timeperiod=10, single_point=False):
    close, = parse_args(close)
    return talib.ROCR100(close, timeperiod)


@_ta_single_point
def RSI(close, timeperiod=14, single_point=False):
    close, = parse_args(close)
    return talib.RSI(close, timeperiod)


@_ta_single_point
def STOCH(high, low, close, fastk_period=5, slowk_period=3, slowk_matype=0, slowd_period=3, slowd_matype=0, single_point=False):
    high, low, close, = parse_args(high, low, close)
    return talib.STOCH(high, low, close, fastk_period, slowk_period, slowk_matype, slowd_period, slowd_matype)


@_ta_single_point
def STOCHF(high, low, close, fastk_period=5, fastd_period=3, fastd_matype=0, single_point=False):
    high, low, close, = parse_args(high, low, close)
    return talib.STOCHF(high, low, close, fastk_period, fastd_period, fastd_matype)


@_ta_single_point
def STOCHRSI(close, timeperiod=14, fastk_period=5, fastd_period=3, fastd_matype=0, single_point=False):
    close, = parse_args(close)
    return talib.STOCHRSI(close, timeperiod, fastk_period, fastd_period, fastd_matype)


@_ta_single_point
def TRIX(close, timeperiod=30, single_point=False):
    close, = parse_args(close)
    return talib.TRIX(close, timeperiod)


@_ta_single_point
def ULTOSC(high, low, close, timeperiod1=7, timeperiod2=14, timeperiod3=28, single_point=False):
    high, low, close, = parse_args(high, low, close)
    return talib.ULTOSC(high, low, close, timeperiod1, timeperiod2, timeperiod3)


@_ta_single_point
def WILLR(high, low, close, timeperiod=14, single_point=False):
    high, low, close, = parse_args(high, low, close)
    return talib.WILLR(high, low, close, timeperiod)


# Volume Indicator
@_ta_single_point
def AD(high, low, close, volume, single_point=False):
    high, low, close, volume, = parse_args(high, low, close, volume)
    return talib.AD(high, low, close, volume)


@_ta_single_point
def ADOSC(high, low, close, volume, fastperiod=3, slowperiod=10, single_point=False):
    high, low, close, volume, = parse_args(high, low, close, volume)
    return talib.ADOSC(high, low, close, volume, fastperiod, slowperiod)


@_ta_single_point
def OBV(close, volume, single_point=False):
    close, volume, = parse_args(close, volume)
    return talib.OBV(close, volume)

# Cycle Indicator


@_ta_single_point
def HT_DCPERIOD(close, single_point=False):
    close, = parse_args(close)
    return talib.HT_DCPERIOD(close)


@_ta_single_point
def HT_DCPHASE(close, single_point=False):
    close, = parse_args(close)
    return talib.HT_DCPHASE(close)


@_ta_single_point
def HT_PHASOR(close, single_point=False):
    close, = parse_args(close)
    return talib.HT_PHASOR(close)


@_ta_single_point
def HT_SINE(close, single_point=False):
    close, = parse_args(close)
    return talib.HT_SINE(close)


@_ta_single_point
def HT_TRENDMODE(close, single_point=False):
    close, = parse_args(close)
    return talib.HT_TRENDMODE(close)


# Price Transform
@_ta_single_point
def AVGPRICE(open, high, low, close, single_point=False):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.AVGPRICE(open, high, low, close)


@_ta_single_point
def MEDPRICE(high, low, single_point=False):
    high, low, = parse_args(high, low)
    return talib.MEDPRICE(high, low)


@_ta_single_point
def TYPPRICE(high, low, close, single_point=False):
    high, low, close, = parse_args(high, low, close)
    return talib.TYPPRICE(high, low, close)


@_ta_single_point
def WCLPRICE(high, low, close, single_point=False):
    high, low, close, = parse_args(high, low, close)
    return talib.WCLPRICE(high, low, close)


# Volatility
@_ta_single_point
def ATR(high, low, close, timeperiod=14, single_point=False):
    high, low, close, = parse_args(high, low, close)
    return talib.ATR(high, low, close, timeperiod)


@_ta_single_point
def NATR(high, low, close, timeperiod=14, single_point=False):
    high, low, close, = parse_args(high, low, close)
    return talib.NATR(high, low, close, timeperiod)


@_ta_single_point
def TRANGE(high, low, close, single_point=False):
    high, low, close, = parse_args(high, low, close)
    return talib.TRANGE(high, low, close)


# Statistic
@_ta_single_point
def BETA(high, low, timeperiod=5, single_point=False):
    high, low, = parse_args(high, low)
    return talib.BETA(high, low, timeperiod)


@_ta_single_point
def CORREL(high, low, timeperiod=30, single_point=False):
    high, low, = parse_args(high, low)
    return talib.CORREL(high, low, timeperiod)


@_ta_single_point
def LINEARREG(close, timeperiod=14, single_point=False):
    close, = parse_args(close)
    return talib.LINEARREG(close, timeperiod)


@_ta_single_point
def LINEARREG_ANGLE(close, timeperiod=14, single_point=False):
    close, = parse_args(close)
    return talib.LINEARREG_ANGLE(close, timeperiod)


@_ta_single_point
def LINEARREG_INTERCEPT(close, timeperiod=14, single_point=False):
    close, = parse_args(close)
    return talib.LINEARREG_INTERCEPT(close, timeperiod)


@_ta_single_point
def LINEARREG_SLOPE(close, timeperiod=14, single_point=False):
    close, = parse_args(close)
    return talib.LINEARREG_SLOPE(close, timeperiod)


@_ta_single_point
def STDDEV(close, timeperiod=5, nbdev=1, single_point=False):
    close, = parse_args(close)
    return talib.STDDEV(close, timeperiod, nbdev)


@_ta_single_point
def TSF(close, timeperiod=14, single_point=False):
    close, = parse_args(close)
    return talib.TSF(close, timeperiod)


@_ta_single_point
def VAR(close, timeperiod=5, nbdev=1, single_point=False):
    close, = parse_args(close)
    return talib.VAR(close, timeperiod, nbdev)


@_ta_single_point
def ACOS(close, single_point=False):
    close, = parse_args(close)
    return talib.ACOS(close)


@_ta_single_point
def ASIN(close, single_point=False):
    close, = parse_args(close)
    return talib.ASIN(close)


@_ta_single_point
def ATAN(close, single_point=False):
    close, = parse_args(close)
    return talib.ATAN(close)


@_ta_single_point
def CEIL(close, single_point=False):
    close, = parse_args(close)
    return talib.CEIL(close)


@_ta_single_point
def COS(close, single_point=False):
    close, = parse_args(close)
    return talib.COS(close)


@_ta_single_point
def COSH(close, single_point=False):
    close, = parse_args(close)
    return talib.COSH(close)


@_ta_single_point
def EXP(close, single_point=False):
    close, = parse_args(close)
    return talib.EXP(close)


@_ta_single_point
def FLOOR(close, single_point=False):
    close, = parse_args(close)
    return talib.FLOOR(close)


@_ta_single_point
def LN(close, single_point=False):
    close, = parse_args(close)
    return talib.LN(close)


@_ta_single_point
def LOG10(close, single_point=False):
    close, = parse_args(close)
    return talib.LOG10(close)


@_ta_single_point
def SIN(close, single_point=False):
    close, = parse_args(close)
    return talib.SIN(close)


@_ta_single_point
def SINH(close, single_point=False):
    close, = parse_args(close)
    return talib.SINH(close)


@_ta_single_point
def SQRT(close, single_point=False):
    close, = parse_args(close)
    return talib.SQRT(close)


@_ta_single_point
def TAN(close, single_point=False):
    close, = parse_args(close)
    return talib.TAN(close)


@_ta_single_point
def TANH(close, single_point=False):
    close, = parse_args(close)
    return talib.TANH(close)

# Pattern Recognition
def CDL2CROWS(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDL2CROWS(open, high, low, close)

def CDL3BLACKCROWS(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDL3BLACKCROWS(open, high, low, close)

def CDL3INSIDE(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDL3INSIDE(open, high, low, close)

def CDL3LINESTRIKE(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDL3LINESTRIKE(open, high, low, close)

def CDL3OUTSIDE(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDL3OUTSIDE(open, high, low, close)

def CDL3STARSINSOUTH(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDL3STARSINSOUTH(open, high, low, close)

def CDL3WHITESOLDIERS(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDL3WHITESOLDIERS(open, high, low, close)

def CDLABANDONEDBABY(open, high, low, close, penetration=0.3):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLABANDONEDBABY(open, high, low, close, penetration)

def CDLADVANCEBLOCK(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLADVANCEBLOCK(open, high, low, close)

def CDLBELTHOLD(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLBELTHOLD(open, high, low, close)

def CDLBREAKAWAY(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLBREAKAWAY(open, high, low, close)

def CDLCLOSINGMARUBOZU(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLCLOSINGMARUBOZU(open, high, low, close)

def CDLCONCEALBABYSWALL(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLCONCEALBABYSWALL(open, high, low, close)

def CDLCOUNTERATTACK(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLCOUNTERATTACK(open, high, low, close)

def CDLDARKCLOUDCOVER(open, high, low, close, penetration=0.5):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLDARKCLOUDCOVER(open, high, low, close, penetration)

def CDLDOJI(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLDOJI(open, high, low, close)

def CDLDOJISTAR(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLDOJISTAR(open, high, low, close)

def CDLDRAGONFLYDOJI(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLDRAGONFLYDOJI(open, high, low, close)

def CDLENGULFING(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLENGULFING(open, high, low, close)

def CDLEVENINGDOJISTAR(open, high, low, close, penetration=0.3):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLEVENINGDOJISTAR(open, high, low, close, penetration)

def CDLEVENINGSTAR(open, high, low, close, penetration=0.3):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLEVENINGSTAR(open, high, low, close, penetration)

def CDLGAPSIDESIDEWHITE(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLGAPSIDESIDEWHITE(open, high, low, close)

def CDLGRAVESTONEDOJI(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLGRAVESTONEDOJI(open, high, low, close)

def CDLHAMMER(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLHAMMER(open, high, low, close)

def CDLHANGINGMAN(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLHANGINGMAN(open, high, low, close)

def CDLHARAMI(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLHARAMI(open, high, low, close)

def CDLHARAMICROSS(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLHARAMICROSS(open, high, low, close)

def CDLHIGHWAVE(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLHIGHWAVE(open, high, low, close)

def CDLHIKKAKE(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLHIKKAKE(open, high, low, close)

def CDLHIKKAKEMOD(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLHIKKAKEMOD(open, high, low, close)

def CDLHOMINGPIGEON(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLHOMINGPIGEON(open, high, low, close)

def CDLIDENTICAL3CROWS(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLIDENTICAL3CROWS(open, high, low, close)

def CDLINNECK(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLINNECK(open, high, low, close)

def CDLINVERTEDHAMMER(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLINVERTEDHAMMER(open, high, low, close)

def CDLKICKING(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLKICKING(open, high, low, close)

def CDLKICKINGBYLENGTH(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLKICKINGBYLENGTH(open, high, low, close)

def CDLLADDERBOTTOM(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLLADDERBOTTOM(open, high, low, close)

def CDLLONGLEGGEDDOJI(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLLONGLEGGEDDOJI(open, high, low, close)

def CDLLONGLINE(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLLONGLINE(open, high, low, close)

def CDLMARUBOZU(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLMARUBOZU(open, high, low, close)

def CDLMATCHINGLOW(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLMATCHINGLOW(open, high, low, close)

def CDLMATHOLD(open, high, low, close, penetration=0.3):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLMATHOLD(open, high, low, close, penetration)

def CDLMORNINGDOJISTAR(open, high, low, close, penetration=0.3):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLMORNINGDOJISTAR(open, high, low, close, penetration)

def CDLMORNINGSTAR(open, high, low, close, penetration=0.3):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLMORNINGSTAR(open, high, low, close, penetration)

def CDLONNECK(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLONNECK(open, high, low, close)

def CDLPIERCING(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLPIERCING(open, high, low, close)

def CDLRICKSHAWMAN(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLRICKSHAWMAN(open, high, low, close)


def CDLRISEFALL3METHODS(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLRISEFALL3METHODS(open, high, low, close)

def CDLSEPARATINGLINES(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLSEPARATINGLINES(open, high, low, close)

def CDLSHOOTINGSTAR(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLSHOOTINGSTAR(open, high, low, close)

def CDLSHORTLINE(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLSHORTLINE(open, high, low, close)

def CDLSPINNINGTOP(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLSPINNINGTOP(open, high, low, close)

def CDLSTALLEDPATTERN(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLSTALLEDPATTERN(open, high, low, close)

def CDLSTICKSANDWICH(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLSTICKSANDWICH(open, high, low, close)

def CDLTAKURI(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLTAKURI(open, high, low, close)

def CDLTASUKIGAP(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLTASUKIGAP(open, high, low, close)

def CDLTHRUSTING(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLTHRUSTING(open, high, low, close)

def CDLTRISTAR(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLTRISTAR(open, high, low, close)

def CDLUNIQUE3RIVER(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLUNIQUE3RIVER(open, high, low, close)

def CDLUPSIDEGAP2CROWS(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLUPSIDEGAP2CROWS(open, high, low, close)

def CDLXSIDEGAP3METHODS(open, high, low, close):
    open, high, low, close, = parse_args(open, high, low, close)
    return talib.CDLXSIDEGAP3METHODS(open, high, low, close)




__all__ = [name for name in locals().keys() if not name.startswith('_')]
__all__.remove('talib')
__all__.remove('functools')
__all__.remove('parse_args')
__all__.remove('MetaReadOnly')
