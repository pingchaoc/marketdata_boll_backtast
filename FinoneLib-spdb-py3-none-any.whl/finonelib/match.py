# -*- coding: utf-8 -*-
"""
@author: QuantInfoTech
"""

from finonelib.interface.exchange import create_execution_from_order
from finonelib.interface.exchange import create_trade_from_execution
from finonelib.interface.exchange import current_timestamp
from finonelib.interface.exchange import fetch_metadata
from finonelib.interface.exchange import fetch_precision
from finonelib.methods import clob_to_limit_orders
from finonelib.methods import insert_order
from finonelib.methods import limit_orders_to_clob
from finonelib.state import state
from finonelib.structs import ClobData
from finonelib.structs import ExecutedTrade
from finonelib.structs import Execution
from finonelib.structs import ExecutionStatus
from finonelib.structs import Order
from finonelib.structs import OHLCOrderUpdater
from finonelib.structs import OrderAction
from finonelib.structs import OrderOwnership
from finonelib.structs import OrderSide
from finonelib.structs import OrderType
from finonelib.structs import OrderOpenClose
from finonelib.structs import MatchType
from finonelib.structs import AbstractOrder
from typing import Tuple, List, Union, Callable
import numpy
import json
import logging
import traceback
import zlib
import copy
import pickle
import time

logger = logging.getLogger(__name__)


class DefaultMatcher(object):
    symbol = ''

    def __init__(self, symbol: str,
                 init_clob: Union[ClobData, None] = None) -> None:
        self.simulated_clob_bid_list = []
        self.simulated_clob_ask_list = []
        state.match_type = MatchType.LP
        self.symbol = symbol
        if init_clob:
            self.simulated_clob_bid_list, self.simulated_clob_ask_list = clob_to_limit_orders(init_clob)

    def match(self, order: Order) -> Tuple[Union[ClobData, None], List[ExecutedTrade], List[Execution]]:
        if order.price < 0 or order.qty <= 0:
            execution = create_execution_from_order(order, ExecutionStatus.CANCEL_REJECTED)
            trades = []
            executions = [execution]
        elif order.action == OrderAction.CANCEL:
            trades, executions = self.match_cancel_order(order)
        elif order.order_type == OrderType.MARKET:
            trades, executions = self.match_market_order(order)
        else:
            trades, executions = self.match_limit_order(order)
        if self.simulated_clob_bid_list and self.simulated_clob_ask_list:
            clob = limit_orders_to_clob(self.simulated_clob_bid_list, self.simulated_clob_ask_list, current_timestamp(), self.symbol)
        else:
            clob = None
        # 不同交易所对trade可能有不同的行为
        # 这里只发最后一个
        return clob, trades[-1:], executions

    def match_cancel_order(self, cancel_order: Order) -> Tuple[List[ExecutedTrade], List[Execution]]:
        executions = []
        executed_trades = []
        if cancel_order.side == OrderSide.BID:
            if not self.simulated_clob_bid_list:
                execution = create_execution_from_order(cancel_order, ExecutionStatus.CANCEL_REJECTED)
                executions.append(execution)
                return [], executions
            del_list = list()
            for limit_order in self.simulated_clob_bid_list:
                # 只能撤回自己的单子
                if limit_order.cancelled:
                    continue
                if cancel_order.ownership == limit_order.ownership and cancel_order.price == limit_order.price:
                    if cancel_order.ownership == OrderOwnership.OTHERS:
                        if cancel_order.qty > limit_order.qty:
                            cancel_order.qty -= limit_order.qty
                            limit_order.cancelled = True
                            del_list.append(limit_order)
                        elif cancel_order.qty == limit_order.qty:
                            limit_order.cancelled = True
                            del_list.append(limit_order)
                            break
                        else:
                            limit_order.qty -= cancel_order.qty
                            break
                    else:
                        if cancel_order.order_id == limit_order.order_id:
                            if cancel_order.qty > limit_order.qty:
                                execution = create_execution_from_order(cancel_order, ExecutionStatus.CANCEL_REJECTED)
                                executions.append(execution)
                                break
                            if cancel_order.qty == limit_order.qty:
                                limit_order.cancelled = True
                                execution = create_execution_from_order(cancel_order, ExecutionStatus.CANCELLED)
                                executions.append(execution)
                                del_list.append(limit_order)
                                break
                            else:
                                limit_order.qty -= cancel_order.qty
                                execution = create_execution_from_order(cancel_order, ExecutionStatus.CANCELLED)
                                executions.append(execution)
                                del_list.append(limit_order)
                                break
            else:
                if cancel_order.ownership == OrderOwnership.STRATEGY:
                    # 没有找到需要撤的单
                    execution = create_execution_from_order(cancel_order, ExecutionStatus.CANCEL_REJECTED)
                    executions.append(execution)
                    return [], executions
            self.simulated_clob_bid_list = [x for x in self.simulated_clob_bid_list if x not in del_list]
            return [], executions
        else:
            if not self.simulated_clob_ask_list:
                execution = create_execution_from_order(cancel_order, ExecutionStatus.CANCEL_REJECTED)
                executions.append(execution)
                return [], executions
            del_list = list()
            for limit_order in self.simulated_clob_ask_list:
                if limit_order.cancelled:
                    continue
                if cancel_order.ownership == limit_order.ownership and cancel_order.price == limit_order.price:
                    if cancel_order.ownership == OrderOwnership.OTHERS:
                        if cancel_order.qty > limit_order.qty:
                            cancel_order.qty -= limit_order.qty
                            limit_order.cancelled = True
                            del_list.append(limit_order)
                        elif cancel_order.qty == limit_order.qty:
                            limit_order.cancelled = True
                            del_list.append(limit_order)
                            break
                        else:
                            limit_order.qty -= cancel_order.qty
                            break
                    else:
                        if cancel_order.order_id == limit_order.order_id:
                            if cancel_order.qty > limit_order.qty:
                                execution = create_execution_from_order(cancel_order, ExecutionStatus.CANCEL_REJECTED)
                                executions.append(execution)
                                break
                            if cancel_order.qty == limit_order.qty:
                                limit_order.cancelled = True
                                execution = create_execution_from_order(cancel_order, ExecutionStatus.CANCELLED)
                                executions.append(execution)
                                del_list.append(limit_order)
                                break
                            else:
                                limit_order.qty -= cancel_order.qty
                                execution = create_execution_from_order(cancel_order, ExecutionStatus.CANCELLED)
                                executions.append(execution)
                                del_list.append(limit_order)
                                break
            else:
                if cancel_order.ownership == OrderOwnership.STRATEGY:
                    # 没有找到需要撤的单
                    execution = create_execution_from_order(cancel_order, ExecutionStatus.CANCEL_REJECTED)
                    executions.append(execution)
                    return [], executions
            self.simulated_clob_ask_list = [x for x in self.simulated_clob_ask_list if x not in del_list]

            return [], executions

    def match_limit_order(self, limit_order: Order) -> Tuple[List[ExecutedTrade], List[Execution]]:
        timestamp = current_timestamp()
        match_flag = False
        executions = []
        executed_trades = list()
        if limit_order.side == OrderSide.BID:
            insert_order(self.simulated_clob_bid_list, limit_order, key=lambda x: (-x.price, x.timestamp))
            if self.simulated_clob_ask_list:
                if limit_order.price >= self.simulated_clob_ask_list[0].price:
                    match_flag = True
        elif limit_order.side == OrderSide.ASK:
            insert_order(self.simulated_clob_ask_list, limit_order, key=lambda x: (x.price, x.timestamp))
            if self.simulated_clob_bid_list:
                if limit_order.price <= self.simulated_clob_bid_list[0].price:
                    match_flag = True

        if match_flag:
            del_list = list()

            best_ask_price = self.simulated_clob_ask_list[0].price
            for index, bid_order in enumerate(self.simulated_clob_bid_list):
                if bid_order.matched:
                    continue
                if bid_order.price < best_ask_price:
                    break
                for ask_order in self.simulated_clob_ask_list:
                    if ask_order.matched:
                        continue
                    if bid_order.price >= ask_order.price:
                        if bid_order.timestamp > ask_order.timestamp:
                            price = ask_order.price
                        else:
                            price = bid_order.price

                        if bid_order.qty > ask_order.qty:
                            bid_trade = ExecutedTrade(timestamp, self.symbol, price, ask_order.qty, bid_order.ownership)
                            ask_trade = ExecutedTrade(timestamp, self.symbol, price, ask_order.qty, ask_order.ownership)
                            executed_trades.append(bid_trade)
                            executed_trades.append(ask_trade)
                            bid_order.qty -= ask_order.qty
                            ask_order.matched = True
                            if (index + 1) < len(self.simulated_clob_ask_list):
                                best_ask_price = self.simulated_clob_ask_list[index + 1].price
                            elif index < len(self.simulated_clob_ask_list):
                                best_ask_price = self.simulated_clob_ask_list[index].price
                            execution = create_execution_from_order(ask_order, ExecutionStatus.FILLED_FULLY)
                            execution.price = price
                            executions.append(execution)
                            execution = create_execution_from_order(bid_order, ExecutionStatus.FILLED_PARTIALLY, ask_order.qty)
                            execution.price = price
                            executions.append(execution)
                            del_list.append(ask_order)
                        elif bid_order.qty == ask_order.qty:
                            bid_trade = ExecutedTrade(timestamp, self.symbol, price, ask_order.qty, bid_order.ownership)
                            ask_trade = ExecutedTrade(timestamp, self.symbol, price, ask_order.qty, ask_order.ownership)
                            executed_trades.append(bid_trade)
                            executed_trades.append(ask_trade)
                            ask_order.matched = True
                            if (index + 1) < len(self.simulated_clob_ask_list):
                                best_ask_price = self.simulated_clob_ask_list[index + 1].price
                            # 原版else
                            elif index < len(self.simulated_clob_ask_list):
                                best_ask_price = self.simulated_clob_ask_list[index].price
                            bid_order.matched = True
                            execution = create_execution_from_order(ask_order, ExecutionStatus.FILLED_FULLY)
                            execution.price = price
                            executions.append(execution)
                            execution = create_execution_from_order(bid_order, ExecutionStatus.FILLED_FULLY)
                            execution.price = price
                            executions.append(execution)
                            del_list.append(ask_order)
                            del_list.append(bid_order)
                            break
                        elif bid_order.qty < ask_order.qty:
                            bid_trade = ExecutedTrade(timestamp, self.symbol, price, bid_order.qty, bid_order.ownership)
                            ask_trade = ExecutedTrade(timestamp, self.symbol, price, bid_order.qty, ask_order.ownership)
                            executed_trades.append(bid_trade)
                            executed_trades.append(ask_trade)
                            ask_order.qty -= bid_order.qty
                            bid_order.matched = True
                            execution = create_execution_from_order(ask_order, ExecutionStatus.FILLED_PARTIALLY, bid_order.qty)
                            execution.price = price
                            executions.append(execution)
                            execution = create_execution_from_order(bid_order, ExecutionStatus.FILLED_FULLY)
                            execution.price = price
                            executions.append(execution)
                            del_list.append(bid_order)
                            break
                    else:
                        break
            self.simulated_clob_ask_list = [x for x in self.simulated_clob_ask_list if x not in del_list]
            self.simulated_clob_bid_list = [x for x in self.simulated_clob_bid_list if x not in del_list]

            maker_bid_list = [x for x in self.simulated_clob_bid_list if
                              x.ownership == OrderOwnership.MARKET_MAKER]
            maker_ask_list = [x for x in self.simulated_clob_ask_list if
                              x.ownership == OrderOwnership.MARKET_MAKER]

            other_bid_list = [x for x in self.simulated_clob_bid_list if
                              x.ownership == OrderOwnership.OTHERS]
            other_ask_list = [x for x in self.simulated_clob_ask_list if
                              x.ownership == OrderOwnership.OTHERS]

            unique_ask_prices = list(set([ask_order.price for ask_order in other_ask_list]))
            unique_bid_prices = list(set([bid_order.price for bid_order in other_bid_list]))

            unique_bid_prices.sort(reverse=True)
            unique_ask_prices.sort(reverse=False)

            if len(unique_bid_prices) >= 10:
                unique_bid_prices = unique_bid_prices[:10]
            if len(unique_ask_prices) >= 10:
                unique_ask_prices = unique_ask_prices[:10]

            new_clob_limit_bid_order_list = list(
                filter(lambda x: x.price in unique_bid_prices, other_bid_list))

            new_clob_limit_ask_order_list = list(
                filter(lambda x: x.price in unique_ask_prices, other_ask_list))

            new_clob_limit_bid_order_list.extend(maker_bid_list)
            new_clob_limit_ask_order_list.extend(maker_ask_list)
            new_clob_limit_bid_order_list.sort(key=lambda x: (-x.price, x.timestamp))
            new_clob_limit_ask_order_list.sort(key=lambda x: (x.price, x.timestamp))

            self.simulated_clob_bid_list = new_clob_limit_bid_order_list
            self.simulated_clob_ask_list = new_clob_limit_ask_order_list
            return executed_trades, executions
        else:
            return executed_trades, executions

    def match_market_order(self, market_order: Order) -> Tuple[List[ExecutedTrade], List[Execution]]:
        executions = []
        executed_trades = list()

        if market_order.side == OrderSide.BID:

            del_list = list()
            if self.simulated_clob_ask_list:
                self.simulated_clob_ask_list.sort(key=lambda x: (x.price, x.timestamp))
                temp_qty = market_order.qty

                for limit_ask_order in self.simulated_clob_ask_list:
                    if limit_ask_order.matched:
                        continue
                    if temp_qty < limit_ask_order.qty:
                        trade = ExecutedTrade(current_timestamp(), self.symbol, limit_ask_order.price,
                                              temp_qty, limit_ask_order.ownership)
                        trade.isMarketOrder = True
                        executed_trades.append(trade)
                        trade = ExecutedTrade(current_timestamp(), self.symbol, limit_ask_order.price,
                                              temp_qty, market_order.ownership)
                        trade.isMarketOrder = True
                        executed_trades.append(trade)
                        limit_ask_order.qty -= temp_qty
                        execution = create_execution_from_order(market_order, ExecutionStatus.FILLED_FULLY, temp_qty)
                        execution.price = limit_ask_order.price
                        executions.append(execution)
                        execution = create_execution_from_order(limit_ask_order, ExecutionStatus.FILLED_PARTIALLY, temp_qty)
                        executions.append(execution)
                        break
                    elif temp_qty == limit_ask_order.qty:
                        trade = ExecutedTrade(current_timestamp(), self.symbol, limit_ask_order.price,
                                              temp_qty, limit_ask_order.ownership)
                        trade.isMarketOrder = True
                        executed_trades.append(trade)
                        trade = ExecutedTrade(current_timestamp(), self.symbol, limit_ask_order.price,
                                              temp_qty, market_order.ownership)
                        trade.isMarketOrder = True
                        executed_trades.append(trade)
                        limit_ask_order.matched = True
                        execution = create_execution_from_order(market_order, ExecutionStatus.FILLED_FULLY, limit_ask_order.qty)
                        execution.price = limit_ask_order.price
                        executions.append(execution)
                        execution = create_execution_from_order(limit_ask_order, ExecutionStatus.FILLED_FULLY)
                        executions.append(execution)
                        del_list.append(limit_ask_order)
                        break
                    else:
                        trade = ExecutedTrade(current_timestamp(), self.symbol, limit_ask_order.price,
                                              limit_ask_order.qty, limit_ask_order.ownership)
                        trade.isMarketOrder = True
                        executed_trades.append(trade)
                        trade = ExecutedTrade(current_timestamp(), self.symbol, limit_ask_order.price,
                                              limit_ask_order.qty, market_order.ownership)
                        trade.isMarketOrder = True
                        executed_trades.append(trade)
                        temp_qty -= limit_ask_order.qty
                        limit_ask_order.matched = True
                        execution = create_execution_from_order(market_order, ExecutionStatus.FILLED_PARTIALLY, limit_ask_order.qty)
                        execution.price = limit_ask_order.price
                        executions.append(execution)
                        execution = create_execution_from_order(limit_ask_order, ExecutionStatus.FILLED_FULLY)
                        executions.append(execution)
                        del_list.append(limit_ask_order)
                self.simulated_clob_ask_list = [x for x in self.simulated_clob_ask_list if x not in del_list]
                self.simulated_clob_ask_list.sort(key=lambda x: (x.price, x.timestamp))
            return executed_trades, executions

        elif market_order.side == OrderSide.ASK:
            del_list = list()
            if self.simulated_clob_bid_list:
                self.simulated_clob_bid_list.sort(key=lambda x: (-x.price, x.timestamp))
                temp_qty = market_order.qty

                for limit_bid_order in self.simulated_clob_bid_list:
                    if limit_bid_order.matched:
                        continue
                    if temp_qty < limit_bid_order.qty:
                        trade = ExecutedTrade(current_timestamp(), self.symbol, limit_bid_order.price,
                                              temp_qty, limit_bid_order.ownership)
                        trade.isMarketOrder = True
                        executed_trades.append(trade)
                        trade = ExecutedTrade(current_timestamp(), self.symbol, limit_bid_order.price,
                                              temp_qty, market_order.ownership)
                        executed_trades.append(trade)
                        limit_bid_order.qty -= temp_qty
                        execution = create_execution_from_order(market_order, ExecutionStatus.FILLED_FULLY, temp_qty)
                        execution.price = limit_bid_order.price
                        executions.append(execution)
                        execution = create_execution_from_order(limit_bid_order, ExecutionStatus.FILLED_PARTIALLY, temp_qty)
                        executions.append(execution)
                        break
                    elif temp_qty == limit_bid_order.qty:
                        trade = ExecutedTrade(current_timestamp(), self.symbol, limit_bid_order.price,
                                              temp_qty, limit_bid_order.ownership)
                        trade.isMarketOrder = True
                        executed_trades.append(trade)
                        trade = ExecutedTrade(current_timestamp(), self.symbol, limit_bid_order.price,
                                              temp_qty, market_order.ownership)
                        executed_trades.append(trade)
                        limit_bid_order.matched = True
                        execution = create_execution_from_order(market_order, ExecutionStatus.FILLED_FULLY, limit_bid_order.qty)
                        execution.price = limit_bid_order.price
                        executions.append(execution)
                        execution = create_execution_from_order(limit_bid_order, ExecutionStatus.FILLED_FULLY)
                        executions.append(execution)
                        del_list.append(limit_bid_order)
                        break
                    else:
                        trade = ExecutedTrade(current_timestamp(), self.symbol, limit_bid_order.price,
                                              limit_bid_order.qty, limit_bid_order.ownership)
                        trade.isMarketOrder = True
                        executed_trades.append(trade)
                        trade = ExecutedTrade(current_timestamp(), self.symbol, limit_bid_order.price,
                                              limit_bid_order.qty, market_order.ownership)
                        executed_trades.append(trade)
                        temp_qty -= limit_bid_order.qty
                        limit_bid_order.matched = True
                        execution = create_execution_from_order(market_order, ExecutionStatus.FILLED_PARTIALLY, limit_bid_order.qty)
                        execution.price = limit_bid_order.price
                        executions.append(execution)
                        execution = create_execution_from_order(limit_bid_order, ExecutionStatus.FILLED_FULLY)
                        executions.append(execution)
                        del_list.append(limit_bid_order)
                self.simulated_clob_bid_list = [x for x in self.simulated_clob_bid_list if x not in del_list]
                self.simulated_clob_bid_list.sort(key=lambda x: (-x.price, x.timestamp))
            return executed_trades, executions


class DefaultOpenCloseMatcher(object):
    symbol = ''
    current_open_side = None
    last_clob = None
    total_lots = 0 # 总持仓
    slippage = 0
    min_move = 0.0001
    bid_list = [] # 只有策略挂单
    ask_list = [] # 只有策略挂单
    SPREAD = 0.005
    open_info = []

    def __init__(self, symbol, slippage, min_move):
        self.bid_list = []
        self.ask_list = []
        self.open_info = []
        state.match_type = MatchType.OC
        self.symbol = symbol
        self.slippage = slippage
        self.min_move = min_move

    def create_split_execution_for_close(self, order, executions, slip_side):
        # 拆分executions
        origin_qty = order.qty  # 记录原始
        diff_qty = order.qty  # order中剩余的qty
        open_info_delete_index = []
        for index, open_obj in enumerate(self.open_info):
            open_obj_qty = open_obj.get('qty', 0)
            # 这一次的开仓的被吃光
            if open_obj_qty <= diff_qty:
                diff_qty -= open_obj_qty  #  这一次之后原先order 还剩的量
                order.qty = open_obj_qty  # 这里赋值是为了方便创建execution 直接调用下面一行的的方法
                execution = create_execution_from_order(order, ExecutionStatus.FILLED_FULLY)
                execution.price = order.price + (self.slippage * self.min_move) * slip_side
                executions.append(execution)
                open_info_delete_index.append(index)
            else:
                # order的qty平完
                order.qty = diff_qty
                open_obj['qty'] = open_obj_qty - diff_qty
                diff_qty = 0
                execution = create_execution_from_order(order, ExecutionStatus.FILLED_FULLY)
                execution.price = order.price + (self.slippage * self.min_move) * slip_side
                executions.append(execution)
            if diff_qty == 0:
                    break
        #  删除open_info中已经被吃掉的内容
        for index in open_info_delete_index:
            self.open_info.pop(index)
        order.qty = origin_qty # 将order qty的信息恢复原样

    def match(self, order):
        trades = []
        executions = []
        if isinstance(order, OHLCOrderUpdater):
            clob = ClobData(order.timestamp, order.symbol,
                            [1], [order.open],
                            [1], [round(order.open + self.SPREAD, state.get_precision_by_symbol(order.symbol))])
            self.last_clob = clob
            # 检查策略挂单
            total_list = self.bid_list + self.ask_list
            total_list.sort(key=lambda x: x.timestamp)
            del_list = []
            for order in total_list:
                if order.side == OrderSide.BID:
                    if order.price + self.slippage * self.min_move >= self.last_clob.p_ask_array[0]:
                        if order.openclose == OrderOpenClose.OPEN:
                            # 方向为开仓
                            if self.current_open_side is None or self.current_open_side == order.side:
                                # 当前未开仓或追仓
                                self.total_lots += order.qty # 买开，持仓增加
                                execution = create_execution_from_order(order, ExecutionStatus.FILLED_FULLY)
                                execution.price = order.price + self.slippage * self.min_move
                                open_info.append({'timestamp': execution.timestamp, 'price': execution.price, 'qty': execution.qty})
                                executions.append(execution)
                                trade = ExecutedTrade(state.timestamp, order.symbol, execution.price, execution.qty, execution.ownership)
                                trades.append(trade)
                                self.current_open_side = order.side
                                del_list.append(order)
                        elif not self.current_open_side is None and self.current_open_side != order.side:
                            # 订单为平仓且当前已开仓，且订单方向与开仓方向相反
                            if -self.total_lots > order.qty:
                                # 有足够持仓来平
                                self.total_lots += order.qty
                                execution = create_execution_from_order(order, ExecutionStatus.FILLED_FULLY)
                                execution.price = order.price + self.slippage * self.min_move
                                executions.append(execution)
                                trade = ExecutedTrade(state.timestamp, order.symbol, execution.price, execution.qty, execution.ownership)
                                trades.append(trade)

                                # 拆分executions
                                self.create_split_execution_for_close(order, executions, 1)
                                del_list.append(order)
                                if self.total_lots == 0:
                                    # 持仓被全平
                                    self.current_open_side = None
                            else:
                                logger.warning(f'没有足够持仓给挂单来平')
                        else:
                            # 平仓挂单与当前开仓方向一致，什么都不做。
                            logger.warning(f'平仓挂单与开仓方向一致')
                    # 价格不到，什么都不做
                else:
                    if order.price - self.slippage * self.min_move <= self.last_clob.p_bid_array[0]:
                        if order.openclose == OrderOpenClose.OPEN:
                            if self.current_open_side is None or self.current_open_side == order.side:
                                self.total_lots -= order.qty # 卖开，持仓减少
                                execution = create_execution_from_order(order, ExecutionStatus.FILLED_FULLY)
                                execution.price = order.price - self.slippage * self.min_move
                                open_info.append({'timestamp': execution.timestamp, 'price': execution.price, 'qty': execution.qty})
                                executions.append(execution)
                                trade = ExecutedTrade(state.timestamp, order.symbol, execution.price, execution.qty, execution.ownership)
                                trades.append(trade)
                                self.current_open_side = order.side
                                del_list.append(order)
                        elif not self.current_open_side is None and self.current_open_side != order.side:
                            if self.total_lots > order.qty:
                                self.total_lots -= order.qty
                                # 拆分executions
                                self.create_split_execution_for_close(order, executions, -1)

                                del_list.append(order)
                                if self.total_lots == 0:
                                    self.current_open_side = None
                            else:
                                logger.warning(f'没有足够持仓给挂单来平')
                        else:
                            # 平仓挂单与当前开仓方向一致，什么都不做。
                            logger.warning(f'平仓挂单与开仓方向一致')
            for order in del_list:
                if order.side == OrderSide.BID:
                    del self.bid_list[self.bid_list.index(order)]
                elif order.side == OrderSide.ASK:
                    del self.ask_list[self.ask_list.index(order)]
            return clob, trades, executions
        else:
            if order.openclose == OrderOpenClose.OPEN:
                # 开仓，检查方向
                if self.current_open_side is None:
                    # 无已有开仓
                    self.current_open_side = order.side
                elif order.side != self.current_open_side:
                    # 已有开仓，仅可追仓，方向不一致需要拒绝
                    logger.error(f'当前订单与已开仓方向不一致，拒绝下单')
                    execution = create_execution_from_order(order, ExecutionStatus.REJECTED)
                    return self.last_clob, [], [execution]
                # 其他情况为追仓，与无开仓同样处理
                if order.side == OrderSide.BID:
                    # 买开，判断是否成交，是则total_lots增加
                    if order.price + self.slippage * self.min_move >= self.last_clob.p_ask_array[0]:
                        self.total_lots += order.qty
                        execution = create_execution_from_order(order, ExecutionStatus.FILLED_FULLY)
                        execution.price = order.price + self.slippage * self.min_move
                        open_info.append({'timestamp': execution.timestamp, 'price': execution.price, 'qty': execution.qty})
                        executions.append(execution)
                        trade = ExecutedTrade(state.timestamp, order.symbol, execution.price, execution.qty, execution.ownership)
                        trades.append(trade)
                    else:
                        # 未成交，挂单
                        self.bid_list.append(order)
                else:
                    # 卖开，成交的话total_lots减少
                    if order.price - self.slippage * self.min_move <= self.last_clob.p_bid_array[0]:
                        self.total_lots -= order.qty
                        execution = create_execution_from_order(order, ExecutionStatus.FILLED_FULLY)
                        execution.price = order.price - self.slippage * self.min_move
                        open_info.append({'timestamp': execution.timestamp, 'price': execution.price, 'qty': execution.qty})
                        executions.append(execution)
                    else:
                        # 未成交，挂单
                        self.ask_list.append(order)
                if self.total_lots == 0:
                    # 开仓后持仓为0理论上是不可能的
                    logger.warning(f'开仓后持仓为0')
            elif order.openclose == OrderOpenClose.CLOSE:
                # 平仓，检查方向，检查持仓
                if self.current_open_side is None:
                    # 未曾开仓，拒绝
                    execution = create_execution_from_order(order, ExecutionStatus.REJECTED)
                    return self.last_clob, [], [execution]
                elif order.side != self.current_open_side:
                    # 已开仓，平仓方向不一致，拒绝
                    execution = create_execution_from_order(order, ExecutionStatus.REJECTED)
                    return self.last_clob, [], [execution]
                else:
                    if order.side == OrderSide.BID:
                        # 买平，检查价格，检查持仓是否足够
                        if order.price + self.slippage * self.min_move >= self.last_clob.p_ask_array[0]:
                            # 价格合适，检查持仓
                            if -self.total_lots >= order.qty:
                                # 买平持仓增加
                                self.total_lots += order.qty
                                # 拆分executions
                                self.create_split_execution_for_close(order, executions, 1)
                            else:
                                logger.error(f'当前持仓量:{self.total_lots} 不足以支持当前BID平仓单:{order.qty}，拒绝下单')
                                execution = create_execution_from_order(order, ExecutionStatus.REJECTED)
                                executions.append(execution)
                        else:
                            # 未成交，挂单
                            self.bid_list.append(order)
                    else:
                        # 卖平，检查价格，检查持仓是否足够
                        if order.price - self.slippage * self.min_move <= self.last_clob.p_bid_array[0]:
                            # 价格合适，检查持仓
                            if self.total_lots >= order.qty:
                                # 卖平持仓减少
                                self.total_lots -= order.qty
                                # 拆分executions
                                self.create_split_execution_for_close(order, executions, -1)
                            else:
                                logger.error(f'当前持仓量:{self.total_lots} 不足以支持当前ASK平仓单:{order.qty}，拒绝下单')
                                execution = create_execution_from_order(order, ExecutionStatus.REJECTED)
                                executions.append(execution)
                        else:
                            # 未成交，挂单
                            self.ask_list.append(order)
                    if self.total_lots == 0:
                        # 持仓被平，设回未开仓
                        self.current_open_side = None
            return self.last_clob, trades[-1:], executions


class DefaultLCMatcher(object):
    spread = 0.005
    bid_list = [] # 只有策略挂单
    ask_list = [] # 只有策略挂单

    def __init__(self, symbol, slippage, min_move, spread):
        self.bid_list = []
        self.ask_list = []
        state.match_type = MatchType.LC
        self.symbol = symbol
        self.metadata = fetch_metadata(symbol)
        if self.metadata:
            self.min_move = self.metadata.price_change_unit
            self.slippage = self.metadata.slippage
            self.SPREAD = round(self.min_move * self.metadata.spread, fetch_precision(symbol))
        else:
            self.slippage = slippage
            self.min_move = min_move
            self.SPREAD = spread
        self.last_clob = None

    def match_strategy_order(self, order):
        trade = None
        execution = None
        if order.side == OrderSide.BID:
            # 买单
            if order.order_type == OrderType.MARKET:
                # 市价单，一定成交
                execution = create_execution_from_order(order, ExecutionStatus.FILLED_FULLY)
                execution.price = self.last_clob.p_ask_array[0] + self.slippage * self.min_move
                trade = create_trade_from_execution(execution)
            elif order.price + self.slippage * self.min_move >= self.last_clob.p_ask_array[0]:
                # 能成交，以订单计算滑点后价格成交
                execution = create_execution_from_order(order, ExecutionStatus.FILLED_FULLY)
                execution.price = order.price + self.slippage * self.min_move
                trade = create_trade_from_execution(execution)
            # else
            # 挂单
            # 但是什么都不用做，靠trade和execution为空在外部判断是否append list

        else:
            # 卖单
            if order.order_type == OrderType.MARKET:
                # 市价单，一定成交
                execution = create_execution_from_order(order, ExecutionStatus.FILLED_FULLY)
                execution.price = self.last_clob.p_bid_array[0] - self.slippage * self.min_move
                trade = create_trade_from_execution(execution)
            elif order.price - self.slippage * self.min_move <= self.last_clob.p_bid_array[0]:
                # 能成交，以订单计算滑点后价格成交
                execution = create_execution_from_order(order, ExecutionStatus.FILLED_FULLY)
                execution.price = order.price - self.slippage * self.min_move
                trade = create_trade_from_execution(execution)
            # else
            # 挂单
            # 但是什么都不用做，靠trade和execution为空在外部判断是否append list
        return trade, execution

    def match(self, order):
        if isinstance(order, OHLCOrderUpdater):
            clob = ClobData(order.timestamp, order.symbol,
                            [1], [order.open],
                            [1], [round(order.open + self.SPREAD, state.get_precision_by_symbol(order.symbol))])
            self.last_clob = clob
            total_list = self.bid_list + self.ask_list
            total_list.sort(key=lambda x: x.timestamp)
            trades = []
            executions = []
            del_list = []
            for order in total_list:
                t, e = self.match_strategy_order(order)
                if e:
                    trades.append(t)
                    executions.append(e)
                    del_list.append(order)
            for order in del_list:
                if order.side == OrderSide.BID:
                    del self.bid_list[self.bid_list.index(order)]
                elif order.side == OrderSide.ASK:
                    del self.ask_list[self.ask_list.index(order)]
            return clob, trades[-1:], executions
        else:
            if order.action == OrderAction.CANCEL:
                executions = []
                if order.side == OrderSide.BID:
                    for pending_order in self.bid_list:
                        if pending_order.order_id == order.order_id:
                            if pending_order.qty == order.qty:
                                execution = create_execution_from_order(pending_order, ExecutionStatus.CANCELLED)
                                executions.append(execution)
                                del self.bid_list[self.bid_list.index(pending_order)]
                                # del之后立刻break是不会产生异常行为的
                                break
                            else:
                                # 撤单量不同，不允许撤单
                                execution = create_execution_from_order(order, ExecutionStatus.CANCEL_REJECTED)
                                executions.append(execution)
                                break
                elif order.side == OrderSide.ASK:
                    for pending_order in self.ask_list:
                        if pending_order.order_id == order.order_id:
                            if pending_order.qty == order.qty:
                                execution = create_execution_from_order(pending_order, ExecutionStatus.CANCELLED)
                                executions.append(execution)
                                del self.ask_list[self.ask_list.index(pending_order)]
                                break # del之后立刻break
                            else:
                                # 撤单量不同，不允许撤单
                                execution = create_execution_from_order(order, ExecutionStatus.CANCEL_REJECTED)
                                executions.append(execution)
                                break
                return self.last_clob, [], executions
            else:             
                trade, execution = self.match_strategy_order(order)
                if not all((trade, execution)):
                    if order.side == OrderSide.BID:
                        self.bid_list.append(order)
                    else:
                        self.ask_list.append(order)
                    return self.last_clob, [], []
                return self.last_clob, [trade], [execution]


class OrderbookMatcher(object):
    spread = 0.005
    bid_list = [] # 只有策略挂单
    ask_list = [] # 只有策略挂单

    def __init__(self, symbol, slippage, min_move, spread):
        self.bid_list = []
        self.ask_list = []
        state.match_type = MatchType.LC
        self.symbol = symbol
        self.metadata = fetch_metadata(symbol)
        if self.metadata:
            self.min_move = self.metadata.price_change_unit
            self.slippage = self.metadata.slippage
            self.SPREAD = round(self.min_move * self.metadata.spread, fetch_precision(symbol))
        else:
            self.slippage = slippage
            self.min_move = min_move
            self.SPREAD = spread
        self.last_clob = None

    def match_strategy_order(self, order):
        trade = None
        execution = None
        if order.side == OrderSide.BID:
            # 买单
            if order.order_type == OrderType.MARKET:
                # 市价单，一定成交
                execution = create_execution_from_order(order, ExecutionStatus.FILLED_FULLY)
                execution.price = self.last_clob.p_ask_array[0] + self.slippage * self.min_move
                trade = create_trade_from_execution(execution)
            elif order.price + self.slippage * self.min_move >= self.last_clob.p_ask_array[0]:
                # 能成交，以订单计算滑点后价格成交
                execution = create_execution_from_order(order, ExecutionStatus.FILLED_FULLY)
                execution.price = order.price + self.slippage * self.min_move
                trade = create_trade_from_execution(execution)
            # else
            # 挂单
            # 但是什么都不用做，靠trade和execution为空在外部判断是否append list

        else:
            # 卖单
            if order.order_type == OrderType.MARKET:
                # 市价单，一定成交
                execution = create_execution_from_order(order, ExecutionStatus.FILLED_FULLY)
                execution.price = self.last_clob.p_bid_array[0] - self.slippage * self.min_move
                trade = create_trade_from_execution(execution)
            elif order.price - self.slippage * self.min_move <= self.last_clob.p_bid_array[0]:
                # 能成交，以订单计算滑点后价格成交
                execution = create_execution_from_order(order, ExecutionStatus.FILLED_FULLY)
                execution.price = order.price - self.slippage * self.min_move
                trade = create_trade_from_execution(execution)
            # else
            # 挂单
            # 但是什么都不用做，靠trade和execution为空在外部判断是否append list
        return trade, execution

    def match(self, order):
        if order.ownership == OrderOwnership.OTHERS:
            pbid = [] 
            pask = []
            bid_qty = []
            ask_qty = []
            ybid = []
            yask = []
            for i in range(1,11):
                if order.__rawdata__.get(f"pbid{i}", 0):
                    pbid.append(order.__rawdata__[f"pbid{i}"])
                    bid_qty.append(order.__rawdata__.get(f"vbid{i}", 1))
                if order.__rawdata__.get(f"pask{i}", 0):
                    pask.append(order.__rawdata__[f"pask{i}"])
                    ask_qty.append(order.__rawdata__.get(f"vask{i}", 1))
                if order.__rawdata__.get(f"ybid{i}", 0):
                    ybid.append(order.__rawdata__[f"ybid{i}"])
                if order.__rawdata__.get(f"yask{i}", 0):
                    yask.append(order.__rawdata__[f"yask{i}"])
            clob = ClobData(order.timestamp, order.symbol, bid_qty, pbid, ask_qty, pask, ybid, yask)
            self.last_clob = clob
            trades = []
            executions = []
            del_bid_count = 0
            del_ask_count = 0
            for order in self.bid_list:
                t, e = self.match_strategy_order(order)
                if e:
                    trades.append(t)
                    executions.append(e)
                    del_bid_count += 1
                else:
                    break
            for order in self.ask_list:
                t, e = self.match_strategy_order(order)
                if e:
                    trades.append(t)
                    executions.append(e)
                    del_ask_count += 1
                else:
                    break
            del self.bid_list[:del_bid_count]
            del self.ask_list[:del_ask_count]
            return clob, trades[-1:], executions
        else:
            if order.action == OrderAction.CANCEL:
                executions = []
                if order.side == OrderSide.BID:
                    for pending_order in self.bid_list:
                        if pending_order.order_id == order.order_id:
                            if pending_order.qty == order.qty:
                                execution = create_execution_from_order(pending_order, ExecutionStatus.CANCELLED)
                                executions.append(execution)
                                del self.bid_list[self.bid_list.index(pending_order)]
                                # del之后立刻break是不会产生异常行为的
                                break
                            else:
                                # 撤单量不同，不允许撤单
                                execution = create_execution_from_order(order, ExecutionStatus.CANCEL_REJECTED)
                                executions.append(execution)
                                break
                elif order.side == OrderSide.ASK:
                    for pending_order in self.ask_list:
                        if pending_order.order_id == order.order_id:
                            if pending_order.qty == order.qty:
                                execution = create_execution_from_order(pending_order, ExecutionStatus.CANCELLED)
                                executions.append(execution)
                                del self.ask_list[self.ask_list.index(pending_order)]
                                break # del之后立刻break
                            else:
                                # 撤单量不同，不允许撤单
                                execution = create_execution_from_order(order, ExecutionStatus.CANCEL_REJECTED)
                                executions.append(execution)
                                break
                return self.last_clob, [], executions
            else:             
                trade, execution = self.match_strategy_order(order)
                if not all((trade, execution)):
                    if order.side == OrderSide.BID:
                        insert_order(self.bid_list, order, lambda x: (-x.price, x.timestamp))
                    else:
                        insert_order(self.ask_list, order, lambda x: (x.price, x.timestamp))
                    return self.last_clob, [], []
                return self.last_clob, [trade], [execution]


class TransactionMatcher(object):
    spread = 0.005
    bid_list = [] # 只有策略挂单
    ask_list = [] # 只有策略挂单

    def __init__(self, symbol, slippage, min_move, spread):
        self.bid_list = []
        self.ask_list = []
        state.match_type = MatchType.LC
        self.symbol = symbol
        self.metadata = fetch_metadata(symbol)
        if self.metadata:
            self.min_move = self.metadata.price_change_unit
            self.slippage = self.metadata.slippage
            self.SPREAD = round(self.min_move * self.metadata.spread, fetch_precision(symbol))
        else:
            self.slippage = slippage
            self.min_move = min_move
            self.SPREAD = spread
        self.last_clob = None

    def match_strategy_order(self, order):
        trade = None
        execution = None
        if order.side == OrderSide.BID:
            # 买单
            if order.order_type == OrderType.MARKET:
                # 市价单，一定成交
                execution = create_execution_from_order(order, ExecutionStatus.FILLED_FULLY)
                execution.price = self.last_clob.p_ask_array[0] + self.slippage * self.min_move
                trade = create_trade_from_execution(execution)
            elif order.price + self.slippage * self.min_move >= self.last_clob.p_ask_array[0]:
                # 能成交，以订单计算滑点后价格成交
                execution = create_execution_from_order(order, ExecutionStatus.FILLED_FULLY)
                execution.price = order.price + self.slippage * self.min_move
                trade = create_trade_from_execution(execution)
            # else
            # 挂单
            # 但是什么都不用做，靠trade和execution为空在外部判断是否append list

        else:
            # 卖单
            if order.order_type == OrderType.MARKET:
                # 市价单，一定成交
                execution = create_execution_from_order(order, ExecutionStatus.FILLED_FULLY)
                execution.price = self.last_clob.p_bid_array[0] - self.slippage * self.min_move
                trade = create_trade_from_execution(execution)
            elif order.price - self.slippage * self.min_move <= self.last_clob.p_bid_array[0]:
                # 能成交，以订单计算滑点后价格成交
                execution = create_execution_from_order(order, ExecutionStatus.FILLED_FULLY)
                execution.price = order.price - self.slippage * self.min_move
                trade = create_trade_from_execution(execution)
            # else
            # 挂单
            # 但是什么都不用做，靠trade和execution为空在外部判断是否append list
        return trade, execution

    def match(self, order):
        if order.ownership == OrderOwnership.OTHERS:
            clob = ClobData(order.timestamp, order.symbol, 
                            [1], [order.__rawdata__["price"] - 0.5*self.SPREAD], 
                            [1], [order.__rawdata__["price"] + 0.5*self.SPREAD])
            self.last_clob = clob
            trades = []
            executions = []
            del_bid_count = 0
            del_ask_count = 0
            for order in self.bid_list:
                t, e = self.match_strategy_order(order)
                if e:
                    trades.append(t)
                    executions.append(e)
                    del_bid_count += 1
                else:
                    break
            for order in self.ask_list:
                t, e = self.match_strategy_order(order)
                if e:
                    trades.append(t)
                    executions.append(e)
                    del_ask_count += 1
                else:
                    break
            del self.bid_list[:del_bid_count]
            del self.ask_list[:del_ask_count]
            return clob, trades[-1:], executions
        else:
            if order.action == OrderAction.CANCEL:
                executions = []
                if order.side == OrderSide.BID:
                    for pending_order in self.bid_list:
                        if pending_order.order_id == order.order_id:
                            if pending_order.qty == order.qty:
                                execution = create_execution_from_order(pending_order, ExecutionStatus.CANCELLED)
                                executions.append(execution)
                                del self.bid_list[self.bid_list.index(pending_order)]
                                # del之后立刻break是不会产生异常行为的
                                break
                            else:
                                # 撤单量不同，不允许撤单
                                execution = create_execution_from_order(order, ExecutionStatus.CANCEL_REJECTED)
                                executions.append(execution)
                                break
                elif order.side == OrderSide.ASK:
                    for pending_order in self.ask_list:
                        if pending_order.order_id == order.order_id:
                            if pending_order.qty == order.qty:
                                execution = create_execution_from_order(pending_order, ExecutionStatus.CANCELLED)
                                executions.append(execution)
                                del self.ask_list[self.ask_list.index(pending_order)]
                                break # del之后立刻break
                            else:
                                # 撤单量不同，不允许撤单
                                execution = create_execution_from_order(order, ExecutionStatus.CANCEL_REJECTED)
                                executions.append(execution)
                                break
                return self.last_clob, [], executions
            else:             
                trade, execution = self.match_strategy_order(order)
                if not all((trade, execution)):
                    if order.side == OrderSide.BID:
                        insert_order(self.bid_list, order, lambda x: (-x.price, x.timestamp))
                    else:
                        insert_order(self.ask_list, order, lambda x: (x.price, x.timestamp))
                    return self.last_clob, [], []
                return self.last_clob, [trade], [execution]
