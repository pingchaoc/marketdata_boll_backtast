# -*- coding: utf-8 -*-
"""
@author: QuantInfoTech
"""
import logging

logger = logging.getLogger(__name__)

def start_backtest() -> None:
    logger.warning("async_backtest.start_backtest will be deprecated in the future, please use main_backtest.start_backtest")
    from finonelib.main_backtest import start_backtest as main_start_backtest
    return main_start_backtest()
