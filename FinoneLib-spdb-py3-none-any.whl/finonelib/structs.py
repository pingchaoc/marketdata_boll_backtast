from datetime import timedelta, datetime
from typing import Union, List, Dict, Any
from typeguard import typechecked
from finonelib.utils import MetaReadOnly
from finonelib.utils import format_trading_time_to_dt
from copy import deepcopy, copy


class OrderAction(object, metaclass=MetaReadOnly):
    PLACE = 0
    CANCEL = 1


class OrderType(object, metaclass=MetaReadOnly):
    LIMIT = 0
    MARKET = 1


class OrderSide(object, metaclass=MetaReadOnly):
    BUY = 0
    SELL = 1
    BID = 0
    ASK = 1


class OrderOwnership(object, metaclass=MetaReadOnly):
    OTHERS = 0
    MARKET_MAKER = 1
    STRATEGY = 1


class OrderOpenClose(object, metaclass=MetaReadOnly):
    """
    OrderOpenClose是为了将来在保证金交易时标记该笔已完成的交易是否已交割，已交割为open，未交割为close
    非保证金交易则为NORMAL
    """
    NORMAL = 0
    OPEN = 1
    CLOSE = 2


class ExecutionStatus(object, metaclass=MetaReadOnly):
    ACCEPTED = 'ACCEPTED'
    REJECTED = 'REJECTED'
    FILLED_PARTIALLY = 'FILLED_PARTIALLY'
    FILLED_FULLY = 'FILLED_FULLY'
    CANCEL_ACCEPTED = 'CANCEL_ACCEPTED'
    CANCEL_REJECTED = 'CANCEL_REJECTED'
    CANCELLED = 'CANCEL_ACCEPTED'
    CANCELLED_BY_MARKET = 'CANCEL_BY_MARKET'
    NONE = 'None'


class ClobData:
    timestamp: int = 0
    symbol: str = ''
    q_bid_array: List[Union[int, float]] = []
    p_bid_array: List[Union[int, float]] = []
    q_ask_array: List[Union[int, float]] = []
    p_ask_array: List[Union[int, float]] = []

    y_bid_array: List[Union[int, float]] = [] # bid到期收益率 本币用
    y_ask_array: List[Union[int, float]] = [] # ask到期收益率 本币用


    @typechecked
    def __init__(self, 
                 timestamp: int,
                 symbol: str, 
                 q_bid_array: List[Union[int, float]], 
                 p_bid_array: List[Union[int, float]], 
                 q_ask_array: List[Union[int, float]], 
                 p_ask_array: List[Union[int, float]],
                 y_bid_array: List[Union[int, float]] = [],
                 y_ask_array: List[Union[int, float]] = []) -> None:
        self.timestamp = timestamp
        self.symbol = symbol
        self.q_bid_array = q_bid_array
        self.p_bid_array = p_bid_array
        self.q_ask_array = q_ask_array
        self.p_ask_array = p_ask_array
        self.y_bid_array = y_bid_array
        self.y_ask_array = y_ask_array

    def __deepcopy__(self, *args):
        clob_data = object.__new__(ClobData)
        clob_data.timestamp = self.timestamp
        clob_data.symbol = self.symbol
        clob_data.q_bid_array = copy(self.q_bid_array)
        clob_data.p_bid_array = copy(self.p_bid_array)
        clob_data.q_ask_array = copy(self.q_ask_array)
        clob_data.p_ask_array = copy(self.p_ask_array)
        clob_data.y_bid_array = copy(self.y_bid_array)
        clob_data.y_ask_array = copy(self.y_ask_array)
        return clob_data

    def __str__(self):
        return f"""timestamp: {self.timestamp}
    datetime: {datetime.fromtimestamp(self.timestamp/1000)}
    symbol: {self.symbol}
    q_bid_array: {self.q_bid_array}
    p_bid_array: {self.p_bid_array}
    y_bid_array: {self.y_bid_array}
    q_ask_array: {self.q_ask_array}
    p_ask_array: {self.p_ask_array}
    y_ask_array: {self.y_ask_array}"""

    def to_json(self):
        return {
            'timestamp': self.timestamp,
            'symbol': self.symbol,
            'q_bid_array': self.q_bid_array,
            'q_ask_array': self.q_ask_array,
            'p_bid_array': self.p_bid_array,
            'p_ask_array': self.p_ask_array,
            'y_bid_array': self.y_bid_array,
            'y_ask_array': self.y_ask_array,
        }

    @property
    def datetime(self):
        return datetime.fromtimestamp(self.timestamp / 1000)

class OHLCData:
    timestamp: int = 0
    symbol: str = ''
    open: Union[int, float] = 0
    high: Union[int, float] = 0
    low: Union[int, float] = 0
    close: Union[int, float] = 0
    volume: Union[int, float] = 0


    @typechecked
    def __init__(self,
                 timestamp: int,
                 symbol: str,
                 open: Union[int, float],
                 high: Union[int, float],
                 low: Union[int, float],
                 close: Union[int, float],
                 volume: Union[int, float] = 0) -> None:
        self.timestamp = timestamp
        self.symbol = symbol
        self.open = open
        self.high = high
        self.low = low
        self.close = close
        self.volume = volume

    def __deepcopy__(self, *args):
        ohlc_data = object.__new__(OHLCData)
        ohlc_data.timestamp = self.timestamp
        ohlc_data.symbol = self.symbol
        ohlc_data.open = self.open
        ohlc_data.high = self.high
        ohlc_data.low = self.low
        ohlc_data.close = self.close
        ohlc_data.volume = self.volume
        return ohlc_data

    def __str__(self):
        return f"""timestamp: {self.timestamp}
    datetime: {datetime.fromtimestamp(self.timestamp/1000)}
    symbol: {self.symbol}
    open: {self.open}
    high: {self.high}
    low: {self.low}
    close: {self.close}
    volume: {self.volume}"""

    def to_json(self):
        return {
            'timestamp': self.timestamp,
            'symbol': self.symbol,
            'open': self.open,
            'high': self.high,
            'low': self.low,
            'close': self.close,
            'volume': self.volume
        }

    @property
    def datetime(self):
        return datetime.fromtimestamp(self.timestamp / 1000)


class AbstractOrder:
    __rawdata__ = None
    symbol: str = ''
    timestamp: int = 0
    ownership: int = -999
    bundle_id: Union[int, str] = 0


class Order(AbstractOrder):
    order_id: Union[int, str] = '00000000000000'
    market_order_id: Union[int, str] = '0'
    bundle_id: Union[int, str] = 0
    timestamp: int = 0
    symbol: str = ''
    side: int = -999
    qty: Union[int, float] = 0
    price: Union[int, float] = 0
    ownership: int = -999
    action: int = -999
    matched: bool = False
    # openclose属性是为了将来在保证金交易时标记该笔已完成的交易是否已交割，已交割为close，未交割为open
    # 非保证金交易则该属性为0
    # 同时也用作标记开平仓属性
    openclose: int = OrderOpenClose.NORMAL

    tag: str = ''

    @typechecked
    def __init__(self,
                 timestamp: int,
                 symbol: str,
                 price: Union[int, float],
                 qty: Union[int, float],
                 order_type: int,
                 side: int,
                 action: int,
                 ownership: int,
                 bundle_id: int,
                 openclose: int = OrderOpenClose.NORMAL,
                 tag: str = '') -> None:
        self.order_id = '00000000000000' # 系统内部id
        self.market_order_id = '0' # 交易所id
        self.bundle_id = bundle_id
        self.timestamp = timestamp
        self.symbol = symbol
        self.order_type = order_type
        self.side = side
        self.qty = qty
        self.price = price
        self.ownership = ownership
        self.action = action
        self.openclose = openclose
        self.tag = tag
        self.matched = False
        self.accepted = False
        self.cancelled = False
        self.delayed = False

    def __str__(self):
        return f"""timestamp: {self.timestamp}
    datetime: {datetime.fromtimestamp(self.timestamp/1000)}
    price: {self.price}
    qty: {self.qty}
    side: {'BID' if self.side == OrderSide.BID else 'ASK'}
    order_type: {'LIMIT' if self.order_type == OrderType.LIMIT else 'MARKET'}
    action: {'PLACE' if self.action == OrderAction.PLACE else 'CANCEL'}
    ownership: {'STRATEGY' if self.ownership == OrderOwnership.STRATEGY else 'OTHERS'}
    symbol: {self.symbol}
    order_id: {self.order_id}
    market_order_id: {self.market_order_id}
    bundle_id: {self.bundle_id}
    matched: {self.matched}
    accepted: {self.accepted}
    cancelled: {self.cancelled}
    openclose: {self.openclose}
    tag: {self.tag}"""

    def to_json(self):
        return {
            'timestamp': self.timestamp,
            'symbol': self.symbol,
            'price': self.price,
            'qty': self.qty,
            'order_type': 'LIMIT' if self.order_type == OrderType.LIMIT else 'MARKET',
            'side': 'BID' if self.side == OrderSide.BID else 'ASK',
            'action': 'PLACE' if self.action == OrderAction.PLACE else 'CANCEL',
            'ownership': 'STRATEGY' if self.ownership == OrderOwnership.STRATEGY else 'OTHERS',
            'bundle_id': self.bundle_id,
            'order_id': self.order_id,
            'market_order_id': self.market_order_id,
            'openclose': self.openclose,
            'tag': self.tag,
        }

    def __deepcopy__(self, *args):
        order = object.__new__(Order)
        order.order_id = self.order_id
        order.market_order_id = self.market_order_id
        order.bundle_id = self.bundle_id
        order.timestamp = self.timestamp
        order.symbol = self.symbol
        order.order_type = self.order_type
        order.side = self.side
        order.qty = self.qty
        order.price = self.price
        order.ownership = self.ownership
        order.action = self.action
        order.openclose = self.openclose
        order.tag = self.tag
        order.matched = self.matched
        order.accepted = self.accepted
        order.cancelled = self.cancelled
        order.delayed = self.delayed
        return order

    @property
    def datetime(self):
        return datetime.fromtimestamp(self.timestamp / 1000)


class OHLCOrderUpdater(Order):
    open: Union[int, float] = 0
    high: Union[int, float] = 0
    low: Union[int, float] = 0
    close: Union[int, float] = 0

    @typechecked
    def __init__(self, 
                 timestamp: int,
                 symbol: str,
                 open: Union[int, float],
                 high: Union[int, float],
                 low: Union[int, float],
                 close: Union[int, float],
                 bundle_id: int) -> None:
        self.timestamp = timestamp
        self.symbol = symbol
        self.open = open
        self.high = high
        self.low = low
        self.close = close
        self.order_type = OrderType.LIMIT
        self.ownership = OrderOwnership.OTHERS
        self.action = OrderAction.PLACE
        self.qty = 1
        self.bundle_id = bundle_id

    def __str__(self):
        return f"""timestamp: {self.timestamp}
    datetime: {datetime.fromtimestamp(self.timestamp/1000)}
    open: {self.open}
    high: {self.high}
    low: {self.low}
    close: {self.close}
    order_type: {'LIMIT' if self.order_type == OrderType.LIMIT else 'MARKET'}
    action: {'PLACE' if self.action == OrderAction.PLACE else 'CANCEL'}
    ownership: {'STRATEGY' if self.ownership == OrderOwnership.STRATEGY else 'OTHERS'}
    symbol: {self.symbol}
    order_id: {self.order_id}
    market_order_id: {self.market_order_id}
    bundle_id: {self.bundle_id}
    openclose: {self.openclose}"""

    def __deepcopy__(self, *args):
        ohlc_order = object.__new__(OHLCOrderUpdater)
        ohlc_order.timestamp = self.timestamp
        ohlc_order.symbol = self.symbol
        ohlc_order.open = self.open
        ohlc_order.high = self.high
        ohlc_order.low = self.low
        ohlc_order.close = self.close
        ohlc_order.order_type = self.order_type
        ohlc_order.ownership = self.ownership
        ohlc_order.action = self.action
        ohlc_order.qty = self.qty
        ohlc_order.bundle_id = self.bundle_id
        return ohlc_order

    def to_json(self):
        return {
            'timestamp': self.timestamp,
            'symbol': self.symbol,
            'open': self.open,
            'high': self.high,
            'low': self.low,
            'close': self.close,
            'order_type': 'LIMIT' if self.order_type == OrderType.LIMIT else 'MARKET',
            'action': 'PLACE' if self.action == OrderAction.PLACE else 'CANCEL',
            'ownership': 'STRATEGY' if self.ownership == OrderOwnership.STRATEGY else 'OTHERS',
            'bundle_id': self.bundle_id,
            'order_id': self.order_id,
            'market_order_id': self.market_order_id,
            'openclose': self.openclose,
        }


class StopPNLAction(object, metaclass=MetaReadOnly):
    STOP_PROFIT = 0
    STOP_LOSS = 1

class StopPNLMode(object, metaclass=MetaReadOnly):
    PERCENTAGE = '%'
    ABS = 'abs'

STOP_PNL_ACTIONS2TAKE = {
    ('%', OrderSide.BID, StopPNLAction.STOP_PROFIT): lambda x, v: x*(1+v),
    ('%', OrderSide.BID, StopPNLAction.STOP_LOSS): lambda x, v: x*(1-v),
    ('%', OrderSide.ASK, StopPNLAction.STOP_PROFIT): lambda x, v: x*(1+v),
    ('%', OrderSide.ASK, StopPNLAction.STOP_LOSS): lambda x, v: x*(1-v),
    ('abs', OrderSide.BID, StopPNLAction.STOP_PROFIT): lambda x, v: x+v,
    ('abs', OrderSide.BID, StopPNLAction.STOP_LOSS): lambda x, v: x-v,
    ('abs', OrderSide.ASK, StopPNLAction.STOP_PROFIT): lambda x, v: x+v,
    ('abs', OrderSide.ASK, StopPNLAction.STOP_LOSS): lambda x, v: x-v,
}

class StopPNL(object):
    action: int = -999
    side: int = -999
    mode: str = -999
    value: Union[int, float] = ''
    qty: int = 0
    remaining_qty: int = 0
    order_type: int = -999
    symbol: str = ''
    order: Order = None

    @typechecked
    def __init__(self, 
                 mode: str, 
                 symbol: str,
                 value: Union[int, float], 
                 qty: int, 
                 order_type: int, 
                 side: int, 
                 action: int):
        self.mode = mode
        self.symbol = symbol
        self.value = value
        self.qty = qty
        self.remaining_qty = qty
        self.order_type = order_type
        self.side = side
        self.action = action

    def __deepcopy__(self, *args):
        spl = object.__new__(StopPNL)
        spl.mode = self.mode
        spl.symbol = self.symbol
        spl.value = self.value
        spl.qty = self.qty
        spl.order_type = self.order_type
        spl.side = self.side
        spl.action = self.action
        spl.order = deepcopy(self.order)
        return spl

    def calc_order_price(self, trade_price):
        if not self.order:
            return 0
        function = STOP_PNL_ACTIONS2TAKE.get((self.mode, self.side, self.action), None)
        if function:
            from finonelib.state import state
            precision = state.get_precision_by_symbol(self.symbol)
            metadata = state.get_metadata_by_symbol(self.symbol)
            unit = 0.0001
            if metadata:
                unit = metadata.price_change_unit
            if self.mode == '%':
                price = function(trade_price, self.value / 100)
            else:
                price = function(trade_price, self.value * unit)
            return round(price, precision)
        else:
            raise ValueError('StopPNL has invalid value')



class Execution:
    timestamp: int = 0
    symbol: str = ''
    price: Union[int, float] = 0
    qty: Union[int, float] = 0
    side: int = -999
    status: str = ExecutionStatus.NONE
    order_id: Union[int, str] = '00000000000000'
    market_order_id: Union[int, str] = '0'
    bundle_id: Union[int, str] = 0
    ownership: int = OrderOwnership.STRATEGY
    # 这里的openclose表达的意思和Order中同名属性一致
    openclose: int = OrderOpenClose.NORMAL

    @typechecked
    def __init__(self,
                 timestamp: int, 
                 symbol: str,
                 price: Union[int, float], 
                 qty: Union[int, float], 
                 order_type: int,
                 side: int, 
                 order_id: Union[int, str],
                 market_order_id: Union[int, str],
                 bundle_id: Union[int, str],
                 status: str,
                 ownership: int,
                 openclose: int = OrderOpenClose.NORMAL) -> None:
        self.timestamp = timestamp
        self.order_id = order_id # 系统内部id
        self.market_order_id = market_order_id # 交易所id
        self.bundle_id = bundle_id
        self.symbol = symbol
        self.price = price
        self.qty = qty
        self.order_type = order_type
        self.side = side
        self.status = status
        self.ownership = ownership
        self.openclose = openclose

    def __deepcopy__(self, *args):
        execution = object.__new__(Execution)
        execution.timestamp = self.timestamp
        execution.order_id = self.order_id
        execution.market_order_id = self.market_order_id
        execution.bundle_id = self.bundle_id
        execution.symbol = self.symbol
        execution.price = self.price
        execution.qty = self.qty
        execution.order_type = self.order_type
        execution.side = self.side
        execution.status = self.status
        execution.ownership = self.ownership
        execution.openclose = self.openclose
        return execution

    def __str__(self):
        return f"""timestamp: {self.timestamp}
    datetime: {datetime.fromtimestamp(self.timestamp/1000)}
    price: {self.price}
    qty: {self.qty}
    order_type: {'LIMIT' if self.order_type == OrderType.LIMIT else 'MARKET'}
    side: {'BID' if self.side == OrderSide.BID else 'ASK'}
    ownership: {'STRATEGY' if self.ownership == OrderOwnership.STRATEGY else 'OTHERS'}
    symbol: {self.symbol}
    order_id: {self.order_id}
    market_order_id: {self.market_order_id}
    bundle_id: {self.bundle_id}
    openclose: {self.openclose}"""

    def to_json(self):
        return {
            'timestamp': self.timestamp,
            'symbol': self.symbol,
            'price': self.price,
            'qty': self.qty,
            'order_type': 'LIMIT' if self.order_type == OrderType.LIMIT else 'MARKET',
            'side': 'BID' if self.side == OrderSide.BID else 'ASK',
            'order_id': self.order_id,
            'market_order_id': self.market_order_id,
            'bundle_id': self.bundle_id,
            'status': self.status,
            'ownership': 'STRATEGY' if self.ownership == OrderOwnership.STRATEGY else 'OTHERS',
            'openclose': self.openclose
        }

    @property
    def datetime(self):
        return datetime.fromtimestamp(self.timestamp / 1000)


class ExecutedTrade:
    timestamp: int = 0
    symbol: str = ''
    price: Union[int, float] = 0
    qty: Union[int, float] = 0
    side: int = -999
    ownership: int = -999
    # for backtest usage
    market_order_id: Union[int, str] = '-1'

    @typechecked
    def __init__(self, 
                 timestamp: int, 
                 symbol: str, 
                 price: Union[int, float], 
                 qty: Union[int, float], 
                 ownership: int) -> None:
        self.timestamp = timestamp
        self.symbol = symbol
        self.price = price
        self.qty = qty
        self.ownership = ownership

    def __str__(self):
        return f"""timestamp: {self.timestamp}
    datetime: {datetime.fromtimestamp(self.timestamp/1000)}
    price: {self.price}
    qty: {self.qty}
    ownership: {'STRATEGY' if self.ownership == OrderOwnership.STRATEGY else 'OTHERS'}
    symbol: {self.symbol}"""

    def to_json(self):
        return {
            'timestamp': self.timestamp,
            'symbol': self.symbol,
            'price': self.price,
            'qty': self.qty,
            'ownership': 'STRATEGY' if self.ownership == OrderOwnership.STRATEGY else 'OTHERS',
            'market_order_id': self.market_order_id
        }

    def __deepcopy__(self, *args):
        executedtrade = object.__new__(ExecutedTrade)
        executedtrade.timestamp = self.timestamp
        executedtrade.symbol = self.symbol
        executedtrade.price = self.price
        executedtrade.qty = self.qty
        executedtrade.side = self.side
        executedtrade.ownership = self.ownership
        executedtrade.market_order_id = self.market_order_id
        return executedtrade

    @property
    def datetime(self):
        return datetime.fromtimestamp(self.timestamp / 1000)

class Repository:

    @typechecked
    def __init__(self, 
                 timestamp: int,
                 symbol: str,
                 pnl: Union[int, float],
                 inventory: Union[int, float],
                 cash: Union[int, float],
                 reporting_cash: Union[int, float],
                 reporting_pnl: Union[int, float]) -> None:
        self.timestamp = timestamp
        self.symbol = symbol
        self.pnl = round(pnl, 6)
        self.inventory = inventory
        self.cash = round(cash, 6)
        self.reporting_cash = round(reporting_cash, 6)
        self.reporting_pnl = round(reporting_pnl, 6)

    def __str__(self):
        return f"""timestamp: {self.timestamp}
        datetime: {datetime.fromtimestamp(self.timestamp/1000)}
        symbol: {self.symbol}
        pnl: {self.pnl}
        inventory: {self.inventory}
        cash: {self.cash}
        reporting_pnl: {self.reporting_pnl}"""

class Inv_Duration:
    def __init__(self, order_qty, duration, status):
        self.order_qty = order_qty
        # self.duration = timedelta(seconds=duration / 1000)
        self.duration = duration
        self.status = status


class StrategyInfo(object):
    def __init__(self, symbol):
        self._symbol = symbol
        # LC only
        self.ohlcs = []
        # clob列表。
        self.clobs = []
        self.executions = []
        # 生成的自身订单，元素为订单集。
        self.orders = []
        # 还未成交的自身订单
        self.pending_orders = {} # key为order_id,value为Order
        # 成交订单，包含自身和市场的。
        self.trade_list = []
        # 实时损益
        self.acc_pnl = []
        # 实时现金
        self.acc_cash = []
        # 实时存量
        self.acc_inventory = []
        self.acc_inventory_value = []
        # 实时交易量
        self.acc_trade_volume = []
        self.quoted_spread = []
        # 做市商自身id
        self.order_confirmations = []
        self.max_draw_down = 0
        self.max_draw_down_duration = 0
        # 最大持仓量
        self.max_holding = 0
        self.max_holding_list = []
        # 平均持仓量
        self.avg_holding = 0
        self.inv_duration_list = []
        # 回撤收益
        self.pnl_draw_down_ratio = 0
        # 报价成功率
        self.success_ratio = 0
        # 最优报价比率
        self.best_quote_ratio = 0
        # 平均持仓实际
        self.avg_holding_duration = 0
        # 做市商报价成就次数
        self.maker_trade_count = 0
        # 最优报价次数
        self.best_bid_count = 0
        # 成交量与报价量比
        self.trade_vol_over_quote_vol = 0
        # 累计收益率
        self.max_capital_usage = 0
        self.max_capital_usage_list = []

        self.time_axis = []
        self.reporting_acc_pnl = []
        self.reporting_acc_cash = []

    @property
    def symbol(self):
        return self._symbol


class MatchType(object, metaclass=MetaReadOnly):
    LP = 'LP'
    LC = 'LC'
    OC = 'OpenClose'

class MetaData(object):

    display_name :str = ''
    explain_name :str = ''
    code :str = ''
    asset_class :str = ''
    exchange_code :str = ''
    unit :str = ''
    pricing_currency :str = ''
    price_change_unit :float = 0.000001
    order_quantity_min :int = 1
    order_quantity_max :int = 5000000
    lot_quantity :int = 1
    variety_type :str = ''
    trading_type :str = ''
    margin_rate :str = ''
    margin_price :str = ''
    commission_rate :float = 0
    commission_rate_intraday :float = 0
    commission_price_intraday :float = 0
    commission_price :float = 0
    holiday_region :str = ''
    trading_adapter :str = ''
    trading_param_json :str = ''
    market_data_adapter :str = ''
    market_data_param_json :str = ''
    slippage :int = 0
    vol :float = 0
    spread :int = 0
    active_contract_month :str = ''
    trading_session :dict = {}
    surge_limit :str = ''
    decline_limit :str = ''
    created_by :str = ''
    created_time :str = ''
    updated_by :str = ''
    updated_time :str = ''

    def __init__(self, mdata={}):
        annotations = self.__annotations__
        for key, value in mdata.items():
            if hasattr(self, key):
                if key == 'trading_session':
                    continue
                setattr(self, key, value if value is None else annotations[key](value))
        self.trading_session = format_trading_time_to_dt(mdata.get('trading_session', {}))


class EconData(object):

    name: str = ''
    country: str = ''
    unit: str = ''
    release_ts: int = 0
    pre: str = ''
    forecast: str = ''
    actual: str = ''
    precision: int = 0

    def __init__(self, mdata={}):
        annotations = self.__annotations__
        for key, value in mdata.items():
            if hasattr(self, key):
                setattr(self, key, value if value is None else annotations[key](value))


class ScriptOutput(object):
    _output_name = ''
    output_type = 'none'


class SeriesOutput(ScriptOutput):
    output_type = 'series'

    def __init__(self):
        self.stored_data = []
        self.id = 1
        self.recognized_type = None
        self.max_clob_bid_depth = 0
        self.max_clob_ask_depth = 0
        self.f = None
        self.header = []

    @property
    def output_name(self):
        return self._output_name + '.csv'

    @typechecked
    def append_rawline(self, line: Dict['str', Any]):
        self.stored_data.append(line)
        if not self.header:
            self.header = list(line.keys())
        self.recognized_type = None
        self.store()

    def append(self, value):
        # check if value is 
        if isinstance(value, ClobData):
            if self.recognized_type is None or self.recognized_type is ClobData:
                # self.max_clob_ask_depth = max(self.max_clob_ask_depth, len(value.p_ask_array))
                # self.max_clob_bid_depth = max(self.max_clob_bid_depth, len(value.p_bid_array))
                self.stored_data.append(value)
                self.recognized_type = ClobData
                if not self.header:
                    self.header = ['id', 'ts', 'symbol']
                    for i in range(10):
                        self.header.append(f'pbid{i+1}')
                        self.header.append(f'vbid{i+1}')
                        self.header.append(f'pask{i+1}')
                        self.header.append(f'vask{i+1}')
            else:
                raise TypeError('You can not mix ClobData with other types in SeriesOutput')
        elif isinstance(value, OHLCData):
            if self.recognized_type is None or self.recognized_type is OHLCData:
                self.stored_data.append(value)
                self.recognized_type = OHLCData
                if not self.header:
                    self.header = ['id', 'ts', 'symbol', 'open', 'high', 'low', 'close', 'volume']
            else:
                raise TypeError('You can not mix OHLCData with other types in SeriesOutput')
        else:
            self.append_rawline(value)
        self.store()


    def store(self, force=False):
        if len(self.stored_data) >= 10000 or force:
            import pandas as pd
            if self.recognized_type == ClobData:
                df_data = []
                for index, clob in enumerate(self.stored_data):
                    d = [str(self.id+index), str(clob.timestamp), str(clob.symbol)]
                    for i in range(10):
                        d.append(str(clob.p_bid_array[i] if i < len(clob.p_bid_array) else 0))
                        d.append(str(clob.q_bid_array[i] if i < len(clob.q_bid_array) else 0))
                        d.append(str(clob.p_ask_array[i] if i < len(clob.p_ask_array) else 0))
                        d.append(str(clob.q_ask_array[i] if i < len(clob.q_ask_array) else 0))
                    df_data.append(','.join(d) + '\r\n')
                self.id += len(self.stored_data)
                if not self.f:
                    self.f = open(self.output_name, 'w', encoding='utf-8')
                    self.f.write(','.join(self.header) + '\r\n')
                self.f.writelines(df_data)
            elif self.recognized_type == OHLCData:
                df_data = []
                for index, ohlc in enumerate(self.stored_data):
                    d = [str(self.id + index),
                         str(ohlc.timestamp), 
                         str(ohlc.symbol),
                         str(ohlc.open),
                         str(ohlc.high),
                         str(ohlc.low),
                         str(ohlc.close),
                         str(ohlc.volume)]
                    df_data.append(','.join(d) + '\r\n')
                self.id += len(self.stored_data)
                if not self.f:
                    self.f = open(self.output_name, 'w', encoding='utf-8')
                    self.f.write(','.join(self.header) + '\r\n')
                self.f.writelines(df_data)
            self.stored_data.clear()
        if force:
            self.f.flush()


class ModelOutput(ScriptOutput):
    output_type = 'model'

    def __init__(self):
        pass

    @property
    def output_name(self):
        return self._output_name

    def set(self, model: Any):
        pass

    def store(self):
        pass
