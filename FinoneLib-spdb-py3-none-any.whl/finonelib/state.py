# -*- coding: utf-8 -*-
"""
@author: QuantInfoTech
"""

from collections import OrderedDict
from copy import deepcopy
from datetime import timedelta
from finonelib.performance import PerformanceCalculator
from finonelib.structs import Order, ClobData, StrategyInfo, OHLCData, MetaData, MatchType, EconData
from finonelib.structs import SeriesOutput, ModelOutput
from finonelib.utils import Singleton, DictWrapper, type_list, transform_to_four
from typeguard import typechecked
from typing import Dict, Any, List, Union, Callable
import inspect
import json
import logging
import math
import random
import requests
import string
import time
import itertools

logger = logging.getLogger(__name__)


class ExecutorParams(object):

    @typechecked
    def __init__(self,
                 strategy_params: Dict[str, Any] = {},
                 pattern_params: Dict[str, Any] = {}) -> None:
        self.strategy_params = strategy_params
        self.pattern_params = pattern_params

# @Singleton
class TradeAdapter(object):
    def __init__(self):
        self.order_list = list()

    @typechecked
    def fetch_orders(self) -> List[Order]:
        orders = self.order_list[:]
        self.order_list.clear()
        return orders

    @typechecked
    def submit_orders(self, orders: List[Order]) -> None:
        self.order_list.extend(orders)

    @typechecked
    def submit_single_order(self, order: Order) -> None:
        self.order_list.append(order)

AVAILABLE_CALLBACK_NAMES = [
    'on_receive_transaction',
    'on_submit_accepted',
    'on_submit_rejected',
    'on_cancel_rejected',
    'on_order_partial_executed',
    'on_order_executed',
    'on_order_cancelled',
]

@Singleton
class RuntimeState(object):
    """An object that stores all runtime states
    The state object should be a singleton in a single process.
    But the runtime model of spark is not always a single process one,
    so the state object will not be the same through all spark executors.
    And the "params" attribute should ONLY store params that used in current executor.
    """
    symbols: List[str] = [] # stores all the symbols
    latest_clobs: Dict[str, Union[ClobData, None]] = OrderedDict()
    last_updated_clob = None

    symbols_reportable: List[str] = []
        
    info_by_symbol: Dict[str, StrategyInfo] = {}
    # symbol_by_argname stores the relationship between
    # on_receive_marketdata and symbols
    # for example, we have
    # def on_receive_marketdata(self, marketdata1, marketdata2): pass;
    # and symbols like ['usdcny', 'eurusd']
    # then symbol_by_argname will be like:
    # {'marketdata1': 'usdcny', 'marketdata2': 'eurusd'}
    # PLEASE NOTE: the sequence of those two will and must be the same
    symbol_by_argname: Dict[str, str] = {} 

    trade_adapter = TradeAdapter()
    # stores all kinds of settings
    settings: Union['RuntimeSettings', None] = None
    params: ExecutorParams = ExecutorParams({}, {})
    # stores variales used in backtest or deployment
    # total_pnl: List[float] = []
    # time_axis: List[int] = []
    total_pnl: Dict[int, Union[int, float]] = {} # timestamp:pnl
    # the key in global_orders is market_order_id
    global_orders: Dict[Union[int, str], Order] = {}
    strategy_class = None
    pattern_class = None
    strategy = None
    strategy_callbacks: Dict[str, Dict[str, Callable]] = {}
    script_callbacks: Dict[str, Callable] = {}
    pattern = None
    order_id_counter = 0
    bundle_id_counter = 0
    market_order_id_counter = 0
    _timestamp = 0  # indicates current time
    _last_timestamp = 0
    initialized = False
    is_apama = False
    is_async = True
    redis_cli = None
    bids_last = []  # 用以记录上一次撮合的simulate_list
    asks_last = []  # 用以记录上一次撮合的simulate_list
    # match_type会由BackTestpattern修改
    match_type = ''  # 记录这一次match的类型  LP/LC/OpenClose
    performance_calculator = None  # 计算相关实例

    # followings are LC only
    latest_ohlcs: Dict[str, Union[OHLCData, None]] = OrderedDict()
    last_updated_ohlc = None

    # metadata, stores data of all symbols
    metadata = {}
    econdata = {}
    fx_pairs = {}
    all_pairs_price = {}
    # sometimes out of data problem, not enough info is given to
    # transfer pnl into reporting currency
    can_transfer_to_reporting = False
    # stop profit order and stop loss order
    stop_profit_loss_triggers = {} # order_id: StopPNL
    stop_profit_loss_marketprice_triggers = {} # lambda : StopPNL

    @typechecked
    def initialize(self,
                   strategy_class: Any,
                   pattern_class: Any,
                   symbols: List[str],
                   params: ExecutorParams,
                   settings: Dict[str, Any]) -> None:
        """initialize method
        This method initialize the instances used in backtest.
        Should only be called once.
        """
        self.settings = RuntimeSettings(settings=deepcopy(settings))
        self.params = deepcopy(params)
        self.total_pnl = {}
        self.asks_last = []          # 上一次撮合后的ask挂单, 用来和这一次做diff 节省发送的内容大小
        self.bids_last = []          # 上一次撮合后的bid挂单, 用来和这一次做diff 节省发送的内容大小
        self.global_orders = {}
        self.order_id_counter = 0
        self.bundle_id_counter = 0
        self.market_order_id_counter = 0
        self._timestamp = 1000000000000
        self._last_timestamp = 1000000000000

        self.econdata = {}

        if not symbols:
            raise ValueError('symbols can\'t be null list')
        self.symbols = symbols
        self.latest_clobs = OrderedDict()
        self.latest_ohlcs = OrderedDict()
        self.last_updated_clob = None
        self.last_updated_ohlc = None
        for symbol in symbols:
            self.latest_clobs[symbol] = None
            self.info_by_symbol[symbol] = StrategyInfo(symbol)
            self.latest_ohlcs[symbol] = None
        self.strategy_class = strategy_class
        self.pattern_class = pattern_class
        self.trade_adapter = TradeAdapter()

        self.is_apama = False
        self.is_async = not self.is_apama

        self.init_callbacks()
        self.strategy = self.strategy_class()
        self.pattern = self.pattern_class()
        for key, val in self.params.strategy_params.items():
            setattr(self.strategy, key, self.guess_val(val))
        for key, val in self.params.pattern_params.items():
            setattr(self.pattern, key, self.guess_val(val))

        # update custom settings defined in strategy
        if hasattr(self.strategy, 'custom_settings'):
            try:
                custom_settings = self.strategy.custom_settings()
                self.settings.update_custom_settings(custom_settings)
            except Exception as e:
                logger.warning('Invalid custom settings in strategy. Please check')

        if hasattr(self.strategy, 'init_econ_data'):
            try:
                self.settings.ECON_DATA_USED = self.strategy.init_econ_data()
            except Exception as e:
                logger.warning('Invalid set econ data in strategy. Please check')

        self.request_metadata()
        self.request_econdata()
        self.fill_tables_for_reporting()
        self.performance_calculator = PerformanceCalculator(strategy_indicator=False)  # 计算pnl cash inventory market_price的工具类实例
        self.performance_calculator.init_infos(symbols)
        self.performance_calculator.init_convertors(self.symbols_reportable)
        
        self.settings.REPORTING_CURRENCY_MODE = 'low' if self.match_type == MatchType.LC else 'high'
        if self.settings.SEND_MATCH_INFO:
            import redis
            self.redis_cli = redis.Redis(host=self.settings.SPARK_REDIS_HOST,
                                         port=self.settings.SPARK_REDIS_PORT,
                                         db=self.settings.SPARK_REDIS_DB)
        self.stop_profit_loss_triggers = {}
        self.stop_profit_loss_marketprice_triggers = {symbol: {} for symbol in self.symbols}
        self.init_script_export_params()
        self.initialized = True


    @typechecked
    def apama_initialize(self,
                         strategy_class: Any,
                         symbols: List[str],
                         params: Dict[str, Any]) -> None:
        # FIXME: to make apama can initialize more than once
        # if self.initialized:
        #     raise Exception('state can\'t be initialized more than once!')
        self.settings = RuntimeSettings(settings={})
        self.params = ExecutorParams(strategy_params=deepcopy(params))
        self.total_pnl = {}
        self.global_orders = {}
        self.order_id_counter = 0
        self.bundle_id_counter = 0
        self.market_order_id_counter = 0
        self._timestamp = math.floor(time.time() * 1000)
        self.match_type = ''
        if not symbols:
            raise ValueError('symbols can\'t be null list')
        self.symbols = symbols
        self.latest_clobs = OrderedDict()
        self.latest_ohlcs = OrderedDict()
        self.last_updated_clob = None
        self.last_updated_ohlc = None
        for symbol in symbols:
            self.latest_clobs[symbol] = None
            self.info_by_symbol[symbol] = StrategyInfo(symbol)
            self.latest_ohlcs[symbol] = None
        self.strategy_class = strategy_class
        self.trade_adapter = TradeAdapter()
        self.is_apama = True
        self.is_async = not self.is_apama

        self.init_callbacks()
        self.strategy = self.strategy_class()
        for key, val in self.params.strategy_params.items():
            setattr(self.strategy, key, self.guess_val(val))
        args = inspect.getfullargspec(self.strategy.on_receive_marketdata) # type: ignore
        self.performance_calculator = PerformanceCalculator(strategy_indicator=False)  # 计算pnl cash inventory market_price的工具类实例
        self.performance_calculator.init_infos(symbols)
        self.stop_profit_loss_triggers = {}
        self.stop_profit_loss_marketprice_triggers = {symbol: {} for symbol in self.symbols}
        self.init_script_export_params()
        self.initialized = True

    @typechecked
    def update_strategy_params(self, params: Dict[str, Any]) -> None:
        if not self.initialized:
            raise Exception('state has not been initialized yet!')
        self.params = ExecutorParams(strategy_params=deepcopy(params), pattern_params=self.params.pattern_params)
        for key, val in self.params.strategy_params.items():
            setattr(self.strategy, key, self.guess_val(val))

    def guess_val(self, val):
        """
        guess a value is int or float or str
        and convert to that type
        eg.
        10.0    ==> 10
        10.1    ==> 10.1
        10      ==> 10
        'abc'   ==> 'abc'
        '10.0'  ==> 10
        '10.1'  ==> 10.1
        '10'    ==> 10
        """
        try:
            try:
                if float(val) == int(val):
                    return int(val)
                raise Exception('to next')
            except Exception as e:
                if '.' in val:
                    return float(val)
                else:
                    return int(val)
        except Exception as e:
            return val

    @property
    def timestamp(self):
        if self.is_apama:
            return int(time.time() * 1000)
        return self._timestamp

    @timestamp.setter
    def timestamp(self, val):
        if self.is_apama:
            return None # FIXME is this correct??
        else:
            self._last_timestamp = self._timestamp
            self._timestamp = val
            if self._timestamp//1000 != self._last_timestamp//1000:
                self.order_id_counter = 0

    def get_info(self, symbol: str) -> StrategyInfo:
        return self.info_by_symbol[symbol]

    @typechecked
    def get_bundle_id(self) -> Any:
        return self.bundle_id_counter

    @typechecked
    def get_order_id(self) -> Any:
        order_id = str(self.timestamp//1000) + transform_to_four(self.order_id_counter)
        return order_id

    @typechecked
    def generate_bundle_id(self) -> Any:
        self.bundle_id_counter += 1
        return self.get_bundle_id()

    @typechecked
    def generate_order_id(self) -> Any:
        self.order_id_counter += 1
        return self.get_order_id()

    @typechecked
    def generate_market_order_id(self) -> Any:
        """
        to ensure market_order_id has no duplicates
        state will not provide a get_market_order_id method.
        """
        self.market_order_id_counter += 1
        return str(self.market_order_id_counter)

    def init_callbacks(self) -> None:
        # strategy_callbacks are first initialized when Strategy class is interpreted
        # at that time the key in strategy_callbacks could only be argnames in on_receive_marketdata
        # so that's before state.initialize or state.apama_initialize is called
        # that said we have to reset the key as symbol here and delete the old ones
        if self.initialized:# and not self.is_apama:
            # as for reused process, the state.symbols might be changed
            # so the state.strategy_callbacks' keys need to be changed to new symbols
            for index, pair in enumerate(self.symbol_by_argname.items()):
                arg, old_symbol = pair
                callbacks = self.strategy_callbacks[old_symbol]
                del self.strategy_callbacks[old_symbol]
                self.strategy_callbacks[self.symbols[index]] = callbacks
                self.symbol_by_argname[arg] = self.symbols[index]
            return
        args = inspect.getfullargspec(self.strategy_class.on_receive_marketdata).args # type: ignore
        if args[0] == 'self':
            del args[0]
        if len(args) != len(self.symbols):
            raise ValueError('Amount of args in on_receive_marketdata must be the same as symbols')
        for index, arg in enumerate(args):
            self.symbol_by_argname[arg] = self.symbols[index]
        for argname, binding in list(self.strategy_callbacks.items()):
            self.strategy_callbacks[self.symbol_by_argname[argname]] = binding
            del self.strategy_callbacks[argname]
        # check for default callback
        # if no decorator is used, find callback in strategy
        # if callback can not be found in strategy, give it a default one that does nothing
        def not_implemented(callback_name):
            def _callback(*args, **kwargs):
                return None
            logger.debug(f'callback for {callback_name} is not implemented, will do nothing')
            return _callback
        for symbol in self.symbols:
            if not symbol in self.strategy_callbacks:
                self.strategy_callbacks[symbol] = {}
            binding = self.strategy_callbacks[symbol]
            for name in AVAILABLE_CALLBACK_NAMES:
                if not binding.get(name, None):
                    binding[name] = getattr(self.strategy_class, name, not_implemented(name))

    @typechecked
    def script_bindings(self) -> Dict[str, str]:
        return {func.__name__: name for name, func in self.script_callbacks.items()}
    
    @typechecked
    def get_precision_by_symbol(self, symbol: str) -> int:
        return self.settings.PRECISION.get(symbol, PRECISION)

    def get_metadata_by_symbol(self, symbol: str):
        return self.metadata.get(symbol, None)

    def request_econdata(self):
        if self.settings.ECON_DATA_USED:
            ret = self.request_method(method='POST', api_url='/metadata/econdata', params={'name_country': self.settings.ECON_DATA_USED})
            if ret is None:
                logger.warn('/metadata/econdata API请求失败！！！')
            else:
                for k, v in ret.items():
                    self.set_econdata(k, v)
        else:
            logger.warning("策略未定义所需使用的经济数据！！！")

    def set_econdata(self, k, v):
        if v:
            ts_list = []
            obj_list = []
            for econdata in v:
                econdata_obj = EconData(econdata)
                ts_list.append(econdata_obj.release_ts)
                obj_list.append(econdata_obj)
            ts_list.sort()
            obj_list = sorted(obj_list, key=lambda x: x.release_ts)
            self.econdata[k] = (ts_list, obj_list)
        else:
            logger.warn(f'{k} econdata is None, the backtest result maybe wrong !!!')

    def set_metadata(self, metadata):
        for mdata in metadata:
            # currently use display_name,
            # but in fact we should use 'code'!
            symbol = mdata['display_name']
            metadata_obj = MetaData(mdata)
            self.metadata[symbol] = metadata_obj
            if self.settings:
                self.settings.PRECISION[symbol] = int(math.ceil(round(math.log(metadata_obj.price_change_unit or 0.000001, 0.1), 3)))
            if metadata_obj.asset_class == 'FX':
                pricing = metadata_obj.pricing_currency.upper()
                base = metadata_obj.display_name.upper().replace(pricing, '').upper()
                self.fx_pairs[(base, pricing)] = {
                    'base_currency': base,
                    'pricing_currency': pricing,
                    'display_name': metadata_obj.display_name.upper()
                }
                self.fx_pairs[(pricing, base)] = self.fx_pairs[(base, pricing)]

    def request_method(self, method, api_url, params={}):
        import os
        import finonelib
        if self.settings["SPARK"]:
            server_urls = [self.settings["SERVER_HOST"]]
        else:
            server_urls = ['https://backtest.finone.quantinfotech.com',
                           'http://staging.finone.quantinfotech.com',
                           'http://dev.finone.quantinfotech.com',]

        if os.path.exists(f'{finonelib.__path__[0]}/.server'):
            with open(f'{finonelib.__path__[0]}/.server', 'r') as f:
                server_urls = f.readlines()
        for url in server_urls:
            try:
                if method.upper() == 'GET':
                    res = requests.get(f'{url}/api/v1{api_url}', params=params, timeout=10)
                    res = res.json()
                elif method.upper() == 'POST':
                    res = requests.post(f'{url}/api/v1{api_url}', data=json.dumps(params), timeout=10)
                    res = res.json()
            except Exception as e:
                logger.warning(f'Can not fetch data from {url}.')
                continue
            if res['success']:
                logger.warning(f'Fetched data from {url}')
                data = res['data']
                return data
                break
        logger.warning(f'Fetched data error, The backtest result may be incorrect. by {method} {api_url} for {params}')

    def request_metadata(self):
        import os
        import finonelib
        def write_metadata(data):
            try:
                with open(f'{finonelib.__path__[0]}/.metadata', 'w') as f:
                    json.dump(data, f)
            except Exception as e:
                try:
                    with open(f'./.metadata', 'w') as f:
                        json.dump(data, f)
                    logger.warning('metadata wrote to ./.metadata')
                except Exception as e:
                    logger.error('Can not write metadata to any directory!')
            else:
                logger.warning(f'metadata wrote to {finonelib.__path__[0]}/.metadata')

        def read_metadata():
            try:
                with open(f'{finonelib.__path__[0]}/.metadata', 'r') as f:
                    data = json.load(f)
                logger.warning(f'read metadata from {finonelib.__path__[0]}/.metadata')
                return data
            except Exception as e:
                try:
                    with open('./.metadata', 'r') as f:
                        data = json.load(f)
                    logger.warning(f'read metadata from ./.metadata')
                    return data
                except Exception as e:
                    logger.error('Can not read metadata from any directory!')
            return None

        data = self.request_method(method='GET', api_url='/metadata/tradingvariety/all')
        if data:
            write_metadata(data)
            self.set_metadata(data)
        else:
            data = read_metadata()
            if data:
                self.set_metadata(data)
            else:
                logger.warning('No metadata available! The backtest result may be incorrect.')    

    
    def get_impala_tablename(self, symbol):
        data = self.request_method(method='GET', api_url='/metadata/dataset/tablename', params={'symbol': symbol})
        if data:
            return data[symbol]
        logger.warning('get_impala_tablename, The backtest result may be incorrect.')


    def fill_tables_for_reporting_by_pair(self, ccy1, ccy2):
        from finonelib.methods import form_fx_pair, get_df_order_pirce_list, get_df_ohlc_price_list
        base, pricing, pair = form_fx_pair(ccy1, ccy2)
        if pair in self.settings.TABLES_FOR_REPORTING or base == pricing:
            return
        if self.settings.REPORTING_CURRENCY_MODE == 'high':
            # high frequency, use clob data
            table_name = self.get_impala_tablename(pair)
            if table_name:
                self.all_pairs_price[pair] = get_df_order_pirce_list(pair, table_name)
        else:
            # mid to low frequency, use ohlc data
            table_name = self.get_impala_tablename(pair)
            if table_name:
                self.all_pairs_price[pair] = get_df_ohlc_price_list(pair, table_name)


    def fill_tables_for_reporting_by_symbol(self, symbol):
        from finonelib.methods import form_fx_pair
        metadata = self.get_metadata_by_symbol(symbol)
        if metadata:
            # if metadata.asset_class == 'EQUITY_INDEX':
            #     pass
            if metadata.asset_class == 'FX':
                ccy1 = metadata.display_name[:3]
                ccy2 = metadata.display_name[3:]

                if self.settings.REPORTING_CURRENCY and self.settings.REPORTING_CURRENCY not in [ccy1,ccy2]:
                    all_pair_tmp = [[ccy1, ccy2], [ccy1, self.settings.REPORTING_CURRENCY], [ccy2, self.settings.REPORTING_CURRENCY]]
                else:
                    all_pair_tmp = [[ccy1, ccy2]]

                all_pair = [form_fx_pair(pair[0], pair[1]) for pair in all_pair_tmp]
                has_price = {}
                for pair in all_pair:
                    self.fill_tables_for_reporting_by_pair(pair[0], pair[1])
                    if pair[2] not in self.all_pairs_price  or not self.get_metadata_by_symbol(pair[2]):
                        # 结算货币价格有数据但是前面的时刻没有数据也应该不做reporting  但这里无法判断  实时转换的时候去判断
                        has_price[pair[2]] = False
                    else:
                        has_price[pair[2]] = True
                if all(list(has_price.values())):
                    self.symbols_reportable.append(symbol)

            # else:  # TODO
            #     ccy1 = metadata.pricing_currency
            #     ccy2 = self.settings.REPORTING_CURRENCY
            #     self.fill_tables_for_reporting_by_pair(ccy1, ccy2)

    def fill_tables_for_reporting(self):
        """
        we assume this method is called after symbols and settings and metadata are initialized
        """
        for symbol in self.symbols:
            self.fill_tables_for_reporting_by_symbol(symbol)

    def init_script_export_params(self):
        for name in self.settings.EXPORT_PARAMS:
            output = getattr(self.strategy, name)
            output_type = output.output_type
            if self.settings.SPARK:
                output_name = f"{output_type}_{self.settings.RECORD_ID}_{self.settings.RESULT_ID}_{name}".upper().replace('@', '_')
            elif 'MC_PATH_COUNTER' not in state.settings:
                output_name = f"script_{output_type}_{name}"
            else:
                mc_path = self.settings.MC_PATH_COUNTER
                output_name = f"script_{output_type}_{name}_path_{mc_path}"
            output._output_name = output_name

    

@typechecked
def fetch_orders() -> List[Order]:
    state.generate_bundle_id()
    return state.trade_adapter.fetch_orders()


MAX_PLAY_SPEED = 10e6
PRECISION = 6

GLOBAL_SETTINGS = {
    'START_TIME': 0,
    'END_TIME': 0,
    'HADOOP_MASTER_HOST': '',
    'HADOOP_IMPALA_HOST': '',
    'HADOOP_WORKER_HOSTS': [],
    'SPARK_KEY': '',
    'SERVER_HOST': '',
    'RECORD_ID': '',
    'RESULT_ID': '',
    'USER_TOKEN': '',
    'DEBUG': True,
    'DATASOURCE': 'local',
    'PLAY_SPEED': MAX_PLAY_SPEED,
    'OUTPUT_REPORT': False,
    'ORDER_TABLE': {},
    'LOCAL_DATA_PATH': {},
    'STRATEGY_NAME': '',
    'BACKTEST_NAME': '',
    'SPARK_REDIS_HOST': '',
    'SPARK_REDIS_PORT': 0,
    'SPARK_REDIS_DB': 0,
    'SEND_MATCH_INFO': False,
    'PRECISION': {},
    'MARKETDATA_INTERVAL': 5000, # in ms, 5seconds
    'ORDER_DELAY': 5, # in ms
    'SEND_MARKETDATA_PERIODICALLY': True, # to or not to send marketdata every MARKETDATA_INTERVAL
    'SEND_HEARTBEAT': False,
    'HEARTBEAT_INTERVAL': 1000, # 1s
    'SPARK': False,
    'METADATA': [],
    'REPORTING_CURRENCY_MODE': 'low', # high or low  OC先不考虑
    'REPORTING_CURRENCY': '',
    'TABLES_FOR_REPORTING': {},
    'ECON_DATA_USED': [],
    'TIME_ZONE': 'Asia/Shanghai',
    'EXPORT_PARAMS': []
}


class RuntimeSettings(DictWrapper):
    def __init__(self, settings={}, *args, **kwargs):
        DictWrapper.__init__(self, GLOBAL_SETTINGS, *args, **kwargs)
        for key, val in settings.items():
            if key.startswith('_') or not key.isupper():
                continue
            self[key] = val

    def update_custom_settings(self, settings):
        if self.SPARK:
            # spark 中运行时不会允许策略修改settings
            return
        for key, val in settings.items():
            if key.startswith('_') or not key.isupper():
                continue
            self[key] = val

state: RuntimeState = RuntimeState()
