from collections import deque
from copy import deepcopy
from datetime import datetime
from finonelib.interface.exchange import create_execution_from_order
from finonelib.interface.exchange import fetch_orders
from finonelib.interface.exchange import on_cancel_rejected
from finonelib.interface.exchange import on_order_cancelled
from finonelib.interface.exchange import on_order_executed
from finonelib.interface.exchange import on_order_partial_executed
from finonelib.interface.exchange import on_receive_marketdata
from finonelib.interface.exchange import on_receive_ohlc
from finonelib.interface.exchange import on_receive_heartbeat
from finonelib.interface.exchange import on_receive_transaction
from finonelib.interface.exchange import on_submit_accepted
from finonelib.interface.exchange import on_submit_rejected
from finonelib.interface.exchange import read_symbol_orders
from finonelib.methods import write_strategy_trade_record_file
from finonelib.methods import write_strategy_trade_record_file_by_execution
from finonelib.methods import write_order_report_file
from finonelib.methods import write_clobs_file
from finonelib.methods import write_performance_file
from finonelib.methods import write_report_file
from finonelib.methods import write_backtest_detail_file
from finonelib.methods import write_total_pnl
from finonelib.methods import put_results_to_hdfs
from finonelib.methods import put_file_to_hdfs
from finonelib.methods import insert_order
from finonelib.state import state
from finonelib.structs import ClobData
from finonelib.structs import OHLCData
from finonelib.structs import ExecutedTrade
from finonelib.structs import Execution
from finonelib.structs import ExecutionStatus
from finonelib.structs import Order
from finonelib.structs import OHLCOrderUpdater
from finonelib.structs import OrderAction
from finonelib.structs import OrderOwnership
from finonelib.structs import OrderSide
from finonelib.structs import OrderType
from finonelib.structs import MatchType
from finonelib.structs import StopPNLAction
from finonelib.structs import StopPNLMode
from finonelib.utils import TradingTime
from finonelib.utils import format_trading_time_to_dt
import json
import logging
import math
import random
import re
import time
import zlib


logger = logging.getLogger(__name__)

def format_time(ts):
    return datetime.fromtimestamp(ts/1000)


def parse_symbol(name):
    return re.sub('#[^@]*', '', name).replace('@', '_')


execution_status_to_callbacks = {
    ExecutionStatus.FILLED_FULLY: on_order_executed,
    ExecutionStatus.FILLED_PARTIALLY: on_order_partial_executed,
    ExecutionStatus.CANCELLED: on_order_cancelled,
    ExecutionStatus.CANCELLED_BY_MARKET: on_order_cancelled,
    ExecutionStatus.CANCEL_REJECTED: on_cancel_rejected,
    ExecutionStatus.REJECTED: on_submit_rejected,
}

class MainLoop(object):
    SYMBOL_AMOUNT_IN_QUEUE = 3
    BUNDLE_LEN = 1500

    def __init__(self, symbols):
        self.list_symbols = deepcopy(symbols)
        self.symbols = set(symbols) # list转set有可能导致for loop先后顺序不一致
        self.order_queue = []
        self.symbol_stopped = set()
        self.symbol_marketdata = {}
        self.last_clob_time_by_symbol = {}
        self.read_orders_generators = {symbol: self.read_orders(symbol) for symbol in symbols}
        self.no_mdata_tradingtime = format_trading_time_to_dt('') # 如果没有拿不到metadata，使用的交易时间（全天24h）

    def read_orders(self, symbol):
        try:
            for order in state.pattern.generate_orders(symbol):
                yield order # this order could be None
        except Exception as e:
            raise e
        finally:
            logger.debug(f'{symbol} stopped')
            self.symbol_stopped.add(symbol)

    def check_symbols(self, valid_symbols):
        """
        check symbols that are not finished have enough orders in order_queue
        """
        for symbol in valid_symbols:
            l = [order for order in self.order_queue if order.symbol == symbol]
            if len(l) >= self.SYMBOL_AMOUNT_IN_QUEUE:
                continue
            else:
                return False
        return True

    def get_other_orders(self):
        """
        this method uses read_orders_generators to fill order_queue
        return False if all data were read, else True
        """
        if self.check_symbols(self.symbols - self.symbol_stopped):
            return False
        if self.symbol_stopped == self.symbols:
            return True
        for symbol in self.symbols - self.symbol_stopped:
            # for each symbol, read until there's SYMBOL_AMOUNT_IN_QUEUE orders in queue
            while len([order for order in self.order_queue if order.symbol == symbol]) < self.SYMBOL_AMOUNT_IN_QUEUE:
                try:
                    next_order = self.read_orders_generators[symbol].send(None)
                    if not next_order:
                        # if pattern gives a None, means it want all orders be matched before next order is yielded
                        break
                    else:
                        # use insert_order to avoid sorting order_queue
                        insert_order(self.order_queue, next_order, key=lambda x:x.timestamp)
                except StopIteration as e:
                    break
        return False

    def queue_strategy_orders(self):
        orders = fetch_orders()
        if orders:
            for order in orders:
                if not order.delayed:
                    order.timestamp += state.settings.ORDER_DELAY
                    order.delayed = True
            self.order_queue.extend(orders)
            self.order_queue.sort(key=lambda x:x.timestamp)
            return True
        return False

    def submit_stop_pnl_order(self, stop_profit_loss, execution):
        if execution.status == ExecutionStatus.FILLED_PARTIALLY:
            full_qty = stop_profit_loss.order.qty
            qty = int(round(stop_profit_loss.qty * execution.qty / full_qty, 0))
            stop_profit_loss.remaining_qty -= qty
        elif execution.status == ExecutionStatus.FILLED_FULLY:
            qty = stop_profit_loss.remaining_qty
        else:
            # ignore other status
            return False

        if stop_profit_loss.order_type == OrderType.LIMIT:
            # 限价止盈止损，成交后直接下单
            price = stop_profit_loss.calc_order_price(execution.price)
            order = Order(state.timestamp, execution.symbol,
                          price, qty, stop_profit_loss.order_type, stop_profit_loss.side,
                          OrderAction.PLACE, OrderOwnership.STRATEGY,
                          bundle_id=state.generate_bundle_id(), tag='SYSTEM STOP PROFIT LOSS LIMIT ORDER')
            self.order_queue.append(order)
        else:
            # 市价单止盈止损，成交后创建行情监听器，行情到了以后再下单
            price = stop_profit_loss.calc_order_price(execution.price)
            if stop_profit_loss.side == OrderSide.BID:
                if stop_profit_loss.action == StopPNLAction.STOP_PROFIT:
                    lamb = lambda mktd: mktd.p_ask_array[0] >= price if mktd.p_ask_array else False
                elif stop_profit_loss.action == StopPNLAction.STOP_LOSS:
                    lamb = lambda mktd: mktd.p_ask_array[0] <= price if mktd.p_ask_array else False
            if stop_profit_loss.side == OrderSide.ASK:
                if stop_profit_loss.action == StopPNLAction.STOP_PROFIT:
                    lamb = lambda mktd: mktd.p_bid_array[0] >= price if mktd.p_bid_array else False
                elif stop_profit_loss.action == StopPNLAction.STOP_LOSS:
                    lamb = lambda mktd: mktd.p_bid_array[0] <= price if mktd.p_bid_array else False
            state.stop_profit_loss_marketprice_triggers[execution.symbol][lamb] = (stop_profit_loss, qty)
        if ExecutionStatus.FILLED_PARTIALLY:
            return False


    def submit_stop_pnl_market_order(self, marketdata):
        for lamb, v in state.stop_profit_loss_marketprice_triggers[marketdata.symbol].items():
            stop_profit_loss, qty = v
            if lamb(marketdata):
                order = Order(state.timestamp, marketdata.symbol,
                              0, qty, stop_profit_loss.order_type, stop_profit_loss.side,
                              OrderAction.PLACE, OrderOwnership.STRATEGY,
                              bundle_id=state.generate_bundle_id(), tag='SYSTEM STOP PROFIT LOSS MARKET ORDER')
                self.order_queue.append(order)


    def do_match(self, order):
        bids_for_dbg = [] 
        asks_for_dbg = []
        if state.settings.SEND_MATCH_INFO:
            bids_for_dbg, asks_for_dbg = self.calc_pre_match(order)

        clob = None
        trades = []
        executions = []
        if order.ownership == OrderOwnership.OTHERS:
            logger.debug('[process_orders] processing other order')
            clob, trades, executions = state.pattern.match(order.symbol, deepcopy(order))
            order.matched = True
            if clob:
                state.performance_calculator.update_clob(clob)
                # for LC only
                if isinstance(order, OHLCOrderUpdater):
                    ohlcdata = OHLCData(order.timestamp, order.symbol, order.open, order.high, order.low, order.close)
                    on_receive_ohlc(ohlcdata)
                    # FIXME
                    state.settings.SEND_MARKETDATA_PERIODICALLY = False
                elif not self.symbol_marketdata.get(clob.symbol):
                    # first clob must be sent immediately
                    # OHLCOrderUpdater won't send first clob
                    self.last_clob_time_by_symbol[clob.symbol] = state.timestamp
                    logger.debug('sending first marketdata')
                    on_receive_marketdata(clob)
                self.symbol_marketdata[clob.symbol] = clob
                self.submit_stop_pnl_market_order(clob)
        else:
            # 策略发出来的单因为加上了ORDER_DELAY所以也会使得时间变动
            # 不然在trade或execution回调中连续发出来的单可能会导致死循环
            logger.debug(f'state.timestamp[maker order]: {format_time(state.timestamp)} to {format_time(order.timestamp)}')
            if order.price < 0 or order.qty <= 0 or (order.price == 0 and order.order_type == OrderType.LIMIT):
                # 策略发出的非法订单要立刻拒单
                logger.error(f'invalid strategy order {order}')
                execution = create_execution_from_order(order, ExecutionStatus.REJECTED)
                on_submit_rejected(execution)
                self.queue_strategy_orders()
                return
            logger.debug('[process_orders] processing strategy order')
            order.market_order_id = state.generate_market_order_id()
            state.global_orders[order.market_order_id] = order
            if order.action == OrderAction.PLACE:
                metadata = state.get_metadata_by_symbol(order.symbol)
                if metadata:
                    if (metadata.order_quantity_min and order.qty < metadata.order_quantity_min) or (metadata.order_quantity_max and order.qty > metadata.order_quantity_max):
                        execution = create_execution_from_order(order, ExecutionStatus.REJECTED)
                        on_submit_rejected(execution)
                        self.queue_strategy_orders()
                        return
                execution = create_execution_from_order(order, ExecutionStatus.ACCEPTED)
                order.accepted = True
                on_submit_accepted(execution)
            clob, trades, executions = state.pattern.match(order.symbol, deepcopy(order))
            order.matched = True
            if clob:
                state.performance_calculator.update_clob(clob)
                self.symbol_marketdata[clob.symbol] = clob
                self.submit_stop_pnl_market_order(clob)
        # 先处理executions再处理trades
        for execution in executions:
            if execution.ownership != OrderOwnership.STRATEGY:
                # no need for match to decide which one belongs to maker
                continue
            stop_profit_loss = state.stop_profit_loss_triggers.get(execution.order_id, None)
            if stop_profit_loss:
                self.submit_stop_pnl_order(stop_profit_loss, execution)
            callback = execution_status_to_callbacks.get(execution.status, None)
            if callback:
                callback(execution)
            else:
                logger.debug('[ERROR] not supported status: {execution.status}')
        for trade in trades:
            on_receive_transaction(trade)
        self.queue_strategy_orders()

        if state.settings.SEND_MATCH_INFO:
            self.calc_post_match(order, bids_for_dbg, asks_for_dbg, trades)

    def send_marketdata_periodically(self):
        # 这里不用self.symbols而用self.list_symbols是因为
        # list转set以后循环顺序可能不一致，无法保证流程的一致性
        for symbol in self.list_symbols:
            marketdata = self.symbol_marketdata.get(symbol, None)
            if marketdata and self.last_clob_time_by_symbol[symbol] + state.settings.MARKETDATA_INTERVAL == state.timestamp:
                copied_marketdata = deepcopy(marketdata)
                copied_marketdata.timestamp = state.timestamp
                self.symbol_marketdata[symbol] = copied_marketdata
                self.last_clob_time_by_symbol[copied_marketdata.symbol] = state.timestamp
                if copied_marketdata.timestamp <= state.settings.END_TIME and (not symbol in self.symbol_stopped or len([o for o in self.order_queue if o.symbol == symbol])):
                    logger.debug('sending marketdata periodically')
                    on_receive_marketdata(copied_marketdata)
        self.queue_strategy_orders()

    def force_send_marketdata(self, symbol):
        marketdata = self.symbol_marketdata.get(symbol, None)
        if not marketdata:
            return
        copied_marketdata = deepcopy(marketdata)
        copied_marketdata.timestamp = state.timestamp
        self.symbol_marketdata[symbol] = copied_marketdata
        self.last_clob_time_by_symbol[copied_marketdata.symbol] = state.timestamp
        on_receive_marketdata(copied_marketdata)
        self.queue_strategy_orders()

    def calc_pre_match(self, order):
        bids = []
        asks = []
        matcher = state.pattern.symbol_matchers.get(order.symbol, None)
        if state.match_type in [MatchType.LP]:
            asks = matcher.simulated_clob_ask_list if matcher else []
            bids = matcher.simulated_clob_bid_list if matcher else []
        elif state.match_type in [MatchType.LC, MatchType.OC]:
            asks = matcher.ask_list if matcher else []
            bids = matcher.bid_list if matcher else []
        return bids, asks

    def calc_post_match(self, order, bids, asks, trades_ret):
        # post match
        info = state.get_info(order.symbol)
        if not hasattr(info, 'bid_volume'):
            info.bid_volume = 0
        if not hasattr(info, 'ask_volume'):
            info.ask_volume = 0
        info.bid_volume += order.qty if order and order.side == OrderSide.BID and order.ownership == OrderOwnership.MARKET_MAKER else 0
        info.ask_volume += order.qty if order and order.side == OrderSide.ASK and order.ownership == OrderOwnership.MARKET_MAKER  else 0
        market_price = None
        if hasattr(info, 'bid_prices'):
            market_price = info.bid_prices[-1] if info.bid_prices else None
        dbg_info = {
            'timestamp': order.timestamp,
            'bid':[x.to_json() for x in bids],
            'ask':[x.to_json() for x in asks],
            'next_order': order.to_json(),
            'symbol': order.symbol,
            'trades': [x.to_json() for x in trades_ret],
            'market_price': market_price,
            'maker_inventory': info.acc_inventory[-1] if info.acc_inventory else 0,
            'maker_volume_bid': info.bid_volume,
            'maker_volume_ask':info.ask_volume
        }

        dbg_info_list = state.performance_calculator.dbg_infos[order.symbol]
        dbg_info_list.append(zlib.compress(bytes(json.dumps(dbg_info), encoding='utf-8')))
        if len(dbg_info_list) >= self.BUNDLE_LEN:
            state.redis_cli.rpush(f'DEBUG_TOOL_{parse_symbol(order.symbol).upper()}_{state.settings.RESULT_ID}', *dbg_info_list)
            state.performance_calculator.dbg_infos[order.symbol] = []
    
    def update_next_heartbeat_timestamp(self, next_heartbeat_timestamp):
        next_htb_trading_ts_list = []
        # 不同symbol的下一个交易时间不一样，所以heartbeat也会不同，应取出所有symbol中的最小heartbeat_timestamp
        for symbol in state.symbols:
            mdata = state.get_metadata_by_symbol(symbol)
            trading_dt = mdata.trading_session if mdata else self.no_mdata_tradingtime
            next_trading_ts = TradingTime(next_heartbeat_timestamp, trading_dt).next_trading_ts
            next_htb_trading_ts_list.append(next_trading_ts)
        next_heartbeat_timestamp = min(next_htb_trading_ts_list)
        return next_heartbeat_timestamp

    def get_mkd_trading_next_ts_list(self):
        next_mkd_trading_ts_list = []
        # 不同symbol的下一个marketdata_ts不一样
        for symbol, ts in self.last_clob_time_by_symbol.items():
            mdata = state.get_metadata_by_symbol(symbol)
            trading_dt = mdata.trading_session if mdata else self.no_mdata_tradingtime
            next_mkd_trading_ts = TradingTime(ts, trading_dt).next_trading_ts
            next_mkd_trading_ts_list.append(next_mkd_trading_ts)
        return next_mkd_trading_ts_list

    def start(self):
        state.timestamp = state.settings.START_TIME
        last_heartbeat = 0
        while state.timestamp < state.settings.END_TIME or self.order_queue:
            order = None
            ########## MATCH ##########
            if self.order_queue and state.timestamp == self.order_queue[0].timestamp:
                order = self.order_queue.pop(0)
                self.do_match(order)
                order.matched = True
            elif self.order_queue and self.order_queue[0].timestamp > state.settings.END_TIME:
                break
            ###########################

            ####### MARKETDATA ########
            if state.settings.SEND_MARKETDATA_PERIODICALLY:
                self.send_marketdata_periodically()
            elif isinstance(order, OHLCOrderUpdater):
                # 只会在LC进到这里
                self.force_send_marketdata(order.symbol)
            ###########################
            
            ##### FILL ORDER QUEUE ####
            data_finished = self.get_other_orders()
            if data_finished and not self.order_queue:
                # all finished
                break
            ###########################

            # timestamp jump to either next_order or next_heartbeat or next_marketdata
            next_order = self.order_queue[0] if self.order_queue else None
            next_order_timestamp = next_order.timestamp if next_order else state.settings.END_TIME
            if state.settings.SEND_HEARTBEAT:
                next_heartbeat_timestamp = state.timestamp + state.settings.HEARTBEAT_INTERVAL - state.timestamp % state.settings.HEARTBEAT_INTERVAL
                # 有可能下一个heartbeat的ts不是交易时间，则update到下一交易时间
                next_heartbeat_timestamp = self.update_next_heartbeat_timestamp(next_heartbeat_timestamp)
            else:
                next_heartbeat_timestamp = state.settings.END_TIME
            if state.settings.SEND_MARKETDATA_PERIODICALLY:
                # 获取到所有腿的下一个marketdata的时间
                next_mkd_trading_ts_list = self.get_mkd_trading_next_ts_list()
                next_marketdata_timestamp = min(next_mkd_trading_ts_list + [state.settings.END_TIME]) + state.settings.MARKETDATA_INTERVAL
            else:
                next_marketdata_timestamp = state.settings.END_TIME
            # print(state.timestamp, next_order_timestamp, next_heartbeat_timestamp, next_marketdata_timestamp, len(self.order_queue))
            
            # heartbeat should be sent after all orders or marketdata that have the same timestamp
            ######## HEARTBEAT ########
            if state.settings.SEND_HEARTBEAT:
                if state.timestamp != last_heartbeat and state.timestamp % state.settings.HEARTBEAT_INTERVAL == 0:
                    if state.timestamp < next_order_timestamp and state.timestamp < next_marketdata_timestamp:                        
                        last_heartbeat = state.timestamp
                        on_receive_heartbeat(state.timestamp)
                        self.queue_strategy_orders()
                        pass
            ###########################
            next_timestamp = min([next_order_timestamp, next_heartbeat_timestamp, next_marketdata_timestamp])
            state.timestamp = next_timestamp
        state.timestamp = state.settings.END_TIME
        # in case last marketdata has the same time as END_TIME
        if state.settings.SEND_MARKETDATA_PERIODICALLY:
            self.send_marketdata_periodically()
        # should we fetch and then reject all remaining orders?


            


def start_backtest() -> None:
    import logging.config
    from finonelib.log import ColoredDebugFormatter, ColoredVerboseFormatter
    LOGGING = {
        'version': 1,
        'disable_existing_loggers': not state.settings.DEBUG,
        'formatters': {
            'verbose': {
                '()': ColoredVerboseFormatter
            },
            'debug': {
                '()': ColoredDebugFormatter
            }
        },
        'handlers': {
            'general': {
                'level': 'DEBUG',
                'class': 'logging.StreamHandler',
                'formatter': 'debug' if state.settings.DEBUG else 'verbose',
            }
        },
        'loggers': {
            '': {
                'handlers': ['general'],
                'propagate': True,
                'level': 'DEBUG',
            },
            'impala': {
                'handlers': ['general'],
                'propagate': True,
                'level': 'WARNING'
            },
            'urllib3': {
                'handlers': ['general'],
                'propagate': True,
                'level': 'ERROR'
            },
        },
    }

    logging.config.dictConfig(LOGGING)

    if state.is_apama:
        raise Exception('in apama mode there is no backtest!')
    global symbol_stopped, symbol_marketdata, order_queue
    symbol_stopped = set()
    symbol_marketdata = {}
    order_queue = []

    mainloop = MainLoop(state.symbols)
    mainloop.start()

    import time
    st = time.time() * 1000
    for symbol in state.symbols:
        dbg_info_list = state.performance_calculator.dbg_infos[symbol]
        if dbg_info_list:
            state.redis_cli.rpush(f'DEBUG_TOOL_{parse_symbol(symbol).upper()}_{state.settings.RESULT_ID}', *dbg_info_list)
            state.performance_calculator.dbg_infos[symbol] = []
    print(f'[TEST] dbg-tool end_ts: {time.time() * 1000 - st}')

    st1 = time.time() * 1000
    # 脚本不保存行情等数据
    if state.settings.OUTPUT_REPORT and not state.settings.EXPORT_PARAMS:
        write_strategy_trade_record_file(state.symbols)
        print(f'[TEST] write csv 1: {time.time() * 1000 - st1}')
        st2 = time.time() * 1000
        
        write_strategy_trade_record_file_by_execution(state.symbols)
        st3 = time.time() * 1000
        print(f'[TEST] write csv 2: {time.time() * 1000 - st2}')

        write_order_report_file(state.symbols)
        st4 = time.time() * 1000
        print(f'[TEST] write csv 3: {time.time() * 1000 - st3}')

        write_clobs_file(state.symbols)
        st5 = time.time() * 1000
        print(f'[TEST] write csv 4: {time.time() * 1000 - st4}')

        write_report_file(state.symbols)
        st6 = time.time() * 1000
        print(f'[TEST] write csv 5: {time.time() * 1000 - st5}')

        write_performance_file(state.symbols)
        st7 = time.time() * 1000
        print(f'[TEST] write csv 6: {time.time() * 1000 - st6}')

        write_backtest_detail_file(state.symbols)
        st8 = time.time() * 1000
        print(f'[TEST] write csv 7: {time.time() * 1000 - st7}')

        write_total_pnl(state.symbols)
        st9 = time.time() * 1000
        print(f'[TEST] write csv 8: {time.time() * 1000 - st8}')

        if state.settings.SPARK:
            put_results_to_hdfs()
        print(f'[TEST] write csv end_ts: {time.time() * 1000 - st9}')

    if not state.settings.SPARK:
        method_name = 'finalize'
        if getattr(state.strategy, method_name, None):
            state.strategy.finalize()
        if getattr(state.pattern, method_name, None):
            state.pattern.finalize()

    for name in state.settings.EXPORT_PARAMS:
        output = getattr(state.strategy, name)
        output.store(force=True)
        if state.settings.SPARK:
            put_file_to_hdfs(output.output_name)
