from typing import Dict
from typeguard import typechecked
from datetime import datetime, timedelta
from datetime import time as dt_time
import json
import time
import bisect


class Singleton(object):
    def __init__(self, klass):
        self.klass = klass
        self.instance = None

    def __call__(self, *args, **kwds):
        if self.instance == None:
            self.instance = self.klass(*args, **kwds)
        return self.instance


class DictWrapper(dict):
    def __init__(self, *args, **kwargs):
        super(DictWrapper, self).__init__(*args, **kwargs)

    def __getattribute__(self, item):
        try:
            return self[item]
        except KeyError as e:
            return object.__getattribute__(self, item)

    def __setattr__(self, item, val):
        self[item] = val


class BaseTypeList(list):
    t = None

    def __init__(self, *args, **kwargs):
        super(BaseTypeList, self).__init__(*args, **kwargs)
        for item in self:
            if not isinstance(item, self.t):
                raise TypeError(f'not all values in list is a {self.t}')

    def append(self, v):
        if not isinstance(v, self.t):
            raise TypeError(f'{v} of {type(v)} is not a {self.t}')
        return super(BaseTypeList, self).append(v)

    def extend(self, l):
        for item in l:
            if not isinstance(item, self.t):
                raise TypeError(f'not all values in list is a {self.t}')
        return super(BaseTypeList, self).extend(l)

__typed_list:Dict[object, BaseTypeList] = {}
def type_list(list_type):
    if list_type in __typed_list:
        return __typed_list[list_type]

    class TypeList(BaseTypeList):
        t = list_type

    if not list_type in __typed_list:
        __typed_list[list_type] = TypeList
    return TypeList


class MetaReadOnly(type):
    def __setattr__(cls, name, val):
        raise AttributeError(f"{cls.__name__}.{name} is readonly.")


@typechecked
def transform_to_four(count:int) -> str:
    if count > 999:
        count = str(count)
    elif count > 99:
        count = f'0{count}'
    elif count > 9:
        count = f'00{count}'
    else:
        count = f'000{count}'
    return count


def run_with_template(template_name, strategy, pattern_params, *args, **kwargs):
    from importlib import import_module
    try:
        template = import_module(f'finonelib.template.{template_name}')
    except ImportError as e:
        raise Exception(f'template {template_name} not found!')
    template.run(strategy, pattern_params, *args, **kwargs)


UNIT2TIMEDELTA = {
    '1min': timedelta(seconds=60),
    '5min': timedelta(seconds=300),
    '15min': timedelta(seconds=900),
    '30min': timedelta(seconds=1800),
    '1h': timedelta(seconds=3600),
    '4h': timedelta(seconds=14400),
    '1d': timedelta(seconds=86400),
    '1w': timedelta(seconds=604800),
    '1mon': timedelta(seconds=2592000), 
}


@typechecked
def pass_minute(prev: int, next: int) -> bool:
    """
    用来检查两个时间戳之间是否跨越了一分钟的0秒
    prev与next都是13位时间戳
    """
    prev = datetime.fromtimestamp(prev / 1000)
    next = datetime.fromtimestamp(next / 1000)
    if next > prev and next.minute != prev.minute:
        return True
    return False


@typechecked
def pass_period(prev: int, next: int, period: str) -> bool:
    """
    用来检查两个时间戳之间是否跨越了period指定的时长
    period可选值：
    1min, 5min, 15min, 30min, 1h, 4h, 1d, 1w, 1mon
    1分钟，5分钟，15分钟，30分钟，1小时，4小时，1天，1周，1月
    """
    prev = datetime.fromtimestamp(prev / 1000)
    next = datetime.fromtimestamp(next / 1000)
    delta = UNIT2TIMEDELTA.get(period, None)
    if not delta:
        raise Exception(f'不支持的__unit__: {period}')
    if next > prev and (next - prev) > delta:
        return True
    return False


@typechecked
def whole_minute(ts: int) -> int:
    """
    用来获取某一个时间戳前最近的一个整分0秒的时间戳
    """
    dt = datetime.fromtimestamp(ts / 1000)
    dt = datetime(year=dt.year, month=dt.month, day=dt.day, hour=dt.hour, minute=dt.minute)
    return int(dt.timestamp() * 1000)


def vwap(q_array, p_array):
    """
    计算市场价格
    """
    # 计算市场的平军价格　LC情况存量变现时，未计滑点价差变化(滑点)
    if len(q_array) != len(p_array):
        raise ValueError("Length of q array does not equal to the length of p array")
    else:
        sum_p = 0
        sum_q = 0
        for i in range(len(q_array)):
            if p_array[i] > 0:
                sum_p += q_array[i] * p_array[i]
                sum_q += q_array[i]
        if sum_q == 0:
            return 0.0
        return float(sum_p / sum_q)


def get_version(VERSION):
    version = [str(v) for v in VERSION]
    return ".".join(version)

def get_build():
    import socket
    return socket.gethostname()

def format_trading_time_to_dt(trading_time):
    """拿到的时间是字符串或json或dict，其中时间是str，转为daetime.time的对象，方便时间比较"""

    if not trading_time:
        trading_time = {}
    elif isinstance(trading_time, str):
        try:
            trading_time = json.loads(trading_time)
        except:
            raise ValueError(
                f'This trading session "{trading_time}" is invalid')
    elif isinstance(trading_time, dict):
        trading_time = trading_time
    else:
        raise ValueError(f'This trading session "{trading_time}" is invalid')

    def time_format(time_str):
        if time_str:
            if time_str == '00:00(+1)':
                return dt_time(23, 59, 59, 999999)
            else:
                try:
                    time_struct = time.strptime(time_str, '%H:%M')
                except:
                    raise ValueError(f'This time "{time_str}" is invalid')
                return dt_time(hour=time_struct.tm_hour, minute=time_struct.tm_min)

    trading_dt = {}
    if not trading_time:
        # 如果没有交易时间，则按全天24小时处理
        for weekday in range(7):
            trading_dt[weekday] = [
                [dt_time(0, 0), dt_time(23, 59, 59, 999999)]]
        trading_dt
    for abbr, start_end_list in trading_time.items():
        new_start_end_list = []
        for start_end in start_end_list:
            try:
                assert(isinstance(start_end, list))
            except:
                raise ValueError(
                    f'This trading session "{trading_time}" is invalid')
            start_time = time_format(start_end[0])
            end_time = time_format(start_end[1])
            new_start_end_list.append([start_time, end_time])
        try:
            weekday = time.strptime(abbr, '%a').tm_wday
        except:
            raise ValueError(
                f'This trading session "{trading_time}" is invalid')
        trading_dt[weekday] = new_start_end_list
    return trading_dt


class TradingTime:
    """
    根据symbol和时间戳ts获取当前是否是交易时间，以及获取下一个交易时间的时间戳
    """

    def __init__(self, ts, trading_dt):
        self.trading_dt = trading_dt
        self.ts = ts
        self.dt = datetime.fromtimestamp(ts/1000)
        self.is_trading = self.is_trading()
        self.next_trading_ts = self.next_trading_ts()

    def is_trading(self):
        start_end_list = self.trading_dt[self.dt.weekday()]
        for start_end in start_end_list:
            start, end = start_end[0], start_end[1]
            if all([start, end]) and start <= self.dt.time() <= end:
                return True
        return False

    def next_trading_ts(self):
        """
        获取下一个交易时间戳，如果是当前时间是交易时间则返回当前时间，
        否则返回下一个交易时间的13位时间戳（跳过非交易时间）
        """
        def get_next_day_start(curr_weekday):
            r_weekday = curr_weekday + 1
            start = self.trading_dt[r_weekday][0][0] if r_weekday <= 6 else self.trading_dt[r_weekday-7][0][0]
            if start:
                return r_weekday, start
            else:
                return get_next_day_start(r_weekday)

        next_ts = self.ts
        if not self.is_trading:
            curr_weekday = self.dt.weekday()
            curr_day_start_end = self.trading_dt[curr_weekday]
            next_is_today = True
            if curr_day_start_end[-1][-1] and self.dt.time() > curr_day_start_end[-1][-1]:
                next_is_today = False
            for start_end in curr_day_start_end:
                (start, end) = start_end
                if all([start, end]):
                    if self.dt.time() < end:
                        next_dt = self.dt.replace(
                            hour=start.hour, minute=start.minute, second=start.second, microsecond=start.microsecond)
                        break
                else:
                    next_is_today = False
                if not next_is_today:
                    break
            if not next_is_today:
                r_weekday, start = get_next_day_start(curr_weekday)
                next_dt = (self.dt + timedelta(days=r_weekday-curr_weekday)).replace(
                    hour=start.hour, minute=start.minute, second=start.second, microsecond=start.microsecond
                )
            next_ts = int(next_dt.timestamp()*1000)
        return next_ts
import pandas as pd
import copy
import csv
import time
import numpy as np


class Bloomberg:
    class ClobData:
        def __init__(self, ts=None, q_bid_array=[0.0], p_bid_array=[0.0], q_ask_array=[0.0], p_ask_array=[0.0]):
            self.ts = ts
            self.q_bid_array = q_bid_array
            self.p_bid_array = p_bid_array
            self.q_ask_array = q_ask_array
            self.p_ask_array = p_ask_array
    # 只有一档价格,所有每次覆盖第一档
    def update_clob(self, clob, type, price, qty):
        if type == "BID":
            clob.p_bid_array[0] = price
            clob.q_bid_array[0] = qty
        elif type == "ASK":
            clob.p_ask_array[0] = price
            clob.q_ask_array[0] = qty
        return clob

    def format_clob(self, filename, symbol):
        clobs = list()

        df = pd.read_csv(filename)
        df = df[ (df["type"] == "BID") | (df["type"] == "ASK") ]
        records = df.to_dict('records')
        clob = None
        for data in records:
            if clob and clob.ts == data["time"]:
                clob = self.update_clob(clob, data["type"], data["price"], data["qty"])
            else:
                if clob:
                    temp_clob = copy.deepcopy(clob)
                    clobs.append(temp_clob)
                ts = data["time"]
                clob = Bloomberg.ClobData(ts)
                clob = self.update_clob(clob, data["type"], data["price"], data["qty"])

        with open(f'{symbol.lower()}_orderbook.csv', 'w', newline='',encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['ts', 'vASK1', 'vASK2', 'vASK3', 'vASK4', 'vASK5', 'vBID1', 'vBID2', 'vBID3',
                                'vBID4', 'vBID5', 'pASK1', 'pASK2', 'pASK3', 'pASK4', 'pASK5', 'pBID1', 'pBID2',
                                'pBID3',
                                'pBID4', 'pBID5', 'symbol'])
            for clob in clobs:
                if len(clob.q_ask_array) < 5:
                    diff = 5 - len(clob.q_ask_array)
                    for i in range(diff):
                        clob.q_ask_array.append(0.0)
                if len(clob.q_bid_array) < 5:
                    diff = 5 - len(clob.q_bid_array)
                    for i in range(diff):
                        clob.q_bid_array.append(0.0)
                if len(clob.p_ask_array) < 5:
                    diff = 5 - len(clob.p_ask_array)
                    for i in range(diff):
                        clob.p_ask_array.append(0.0)
                if len(clob.p_bid_array) < 5:
                    diff = 5 - len(clob.p_bid_array)
                    for i in range(diff):
                        clob.p_bid_array.append(0.0)
                q_ask1 = clob.q_ask_array[0]
                q_ask2 = clob.q_ask_array[1]
                q_ask3 = clob.q_ask_array[2]
                q_ask4 = clob.q_ask_array[3]
                q_ask5 = clob.q_ask_array[4]
                q_bid1 = clob.q_bid_array[0]
                q_bid2 = clob.q_bid_array[1]
                q_bid3 = clob.q_bid_array[2]
                q_bid4 = clob.q_bid_array[3]
                q_bid5 = clob.q_bid_array[4]
                p_ask1 = clob.p_ask_array[0]
                p_ask2 = clob.p_ask_array[1]
                p_ask3 = clob.p_ask_array[2]
                p_ask4 = clob.p_ask_array[3]
                p_ask5 = clob.p_ask_array[4]
                p_bid1 = clob.p_bid_array[0]
                p_bid2 = clob.p_bid_array[1]
                p_bid3 = clob.p_bid_array[2]
                p_bid4 = clob.p_bid_array[3]
                p_bid5 = clob.p_bid_array[4]
                writer.writerow(
                    [int(time.mktime(time.strptime(clob.ts, "%Y/%m/%d %H:%M:%S")))*1000, q_ask1, q_ask2, q_ask3, q_ask4, q_ask5, q_bid1, q_bid2, q_bid3, q_bid4,
                        q_bid5, p_ask1, p_ask2, p_ask3, p_ask4, p_ask5, p_bid1, p_bid2, p_bid3, p_bid4, p_bid5, symbol.upper()])


def format_transaction(filename, symbol):
    df = pd.read_csv(filename)
    df = df[ df["type"] == "TRADE" ]
    df['side'] = np.where(df["price"]-df["price"].shift().fillna(0) >= 0, 1, -1)
    df['ts'] = df.apply(lambda row: int(time.mktime(time.strptime(row["time"], "%Y/%m/%d %H:%M:%S")))*1000, axis=1)
    df['symbol'] = symbol.upper()
    df = df.drop(["time","type"], axis=1)
    df.to_csv(f'{symbol.lower()}_transaction.csv', index=False, encoding='utf_8')


class GF:
    class ClobData:
        def __init__(self, ts):
            self.ts = ts
            self.q_bid_array = []
            self.p_bid_array = []
            self.q_ask_array = []
            self.p_ask_array = []
    def update_clob(self, clob, side, depth, price, qty):
        if side == "报卖价":
            if depth == "第1档":
                clob.p_bid_array = []
                clob.q_bid_array = []
            clob.p_bid_array.append(price)
            clob.q_bid_array.append(qty)
        else:
            if depth == "第1档":
                clob.p_ask_array = []
                clob.q_ask_array = []
            clob.p_ask_array.append(price)
            clob.q_ask_array.append(qty)
    
    def format_clob(self, filename, symbol):

        df = pd.read_excel(filename)
        df = df.drop("tap", axis=1)
        records = df.to_dict('records')

        clobs = list()
        clob = None

        for data in records:
            if clob and clob.ts == str(data["date"]) + " " + str(data["time"]):
                self.update_clob(clob, data["side"], data["depth"], data["price"], data["qty"])
            else:
                ts = str(data["date"]) + " " + str(data["time"])
                if clob:
                    temp_clob = copy.deepcopy(clob)
                    clobs.append(temp_clob)
                    clob.ts = ts
                else:
                    clob = GF.ClobData(ts)
                self.update_clob(clob, data["side"], data["depth"], data["price"], data["qty"])


        with open(f'{symbol.lower()}_orderbook.csv', 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['datetime','ts', 'vASK1', 'vASK2', 'vASK3', 'vASK4', 'vASK5', 'vBID1', 'vBID2', 'vBID3',
                                'vBID4', 'vBID5', 'pASK1', 'pASK2', 'pASK3', 'pASK4', 'pASK5', 'pBID1', 'pBID2',
                                'pBID3',
                                'pBID4', 'pBID5', 'symbol'])
            for clob in clobs:
                if len(clob.q_ask_array) < 5:
                    diff = 5 - len(clob.q_ask_array)
                    for i in range(diff):
                        clob.q_ask_array.append(0.0)
                if len(clob.q_bid_array) < 5:
                    diff = 5 - len(clob.q_bid_array)
                    for i in range(diff):
                        clob.q_bid_array.append(0.0)
                if len(clob.p_ask_array) < 5:
                    diff = 5 - len(clob.p_ask_array)
                    for i in range(diff):
                        clob.p_ask_array.append(0.0)
                if len(clob.p_bid_array) < 5:
                    diff = 5 - len(clob.p_bid_array)
                    for i in range(diff):
                        clob.p_bid_array.append(0.0)
                q_ask1 = clob.q_ask_array[0]
                q_ask2 = clob.q_ask_array[1]
                q_ask3 = clob.q_ask_array[2]
                q_ask4 = clob.q_ask_array[3]
                q_ask5 = clob.q_ask_array[4]
                q_bid1 = clob.q_bid_array[0]
                q_bid2 = clob.q_bid_array[1]
                q_bid3 = clob.q_bid_array[2]
                q_bid4 = clob.q_bid_array[3]
                q_bid5 = clob.q_bid_array[4]
                p_ask1 = clob.p_ask_array[0]
                p_ask2 = clob.p_ask_array[1]
                p_ask3 = clob.p_ask_array[2]
                p_ask4 = clob.p_ask_array[3]
                p_ask5 = clob.p_ask_array[4]
                p_bid1 = clob.p_bid_array[0]
                p_bid2 = clob.p_bid_array[1]
                p_bid3 = clob.p_bid_array[2]
                p_bid4 = clob.p_bid_array[3]
                p_bid5 = clob.p_bid_array[4]
                writer.writerow(
                    [clob.ts,int(time.mktime(time.strptime(clob.ts, "%Y%m%d %H:%M:%S.%f")))*1000, q_ask1, q_ask2, q_ask3, q_ask4, q_ask5, q_bid1, q_bid2, q_bid3, q_bid4,
                        q_bid5, p_ask1, p_ask2, p_ask3, p_ask4, p_ask5, p_bid1, p_bid2, p_bid3, p_bid4, p_bid5, symbol.upper()])


def get_time_range_by_time_type(time_type):
    """
    通过颗粒度获取相应时间长度(毫秒数)，计算平均每颗粒度的报单量计算
    如５min颗粒度，毫秒数是5*60*1000,
    tick级别数据，目前按1min算
    """
    time_range_dict = {
        '1tick': 1*60*1000,
        '1s': 1*60*1000,
        '1min': 1*60*1000,
        '5min': 5*60*1000,
        '15min': 15*60*1000,
        '30min': 30*60*1000,
        '1h': 1*60*60*1000,
        '4h': 4*60*60*1000,
        '1d': 24*60*60*1000,
        '1w': 7*24*60*60*1000,
        '1mon': 30*24*60*60*1000
    }
    return time_range_dict[time_type]


def sequence_index(lst, value):
    index = bisect.bisect_left(lst, value)
    try:
        if lst[index] == value:
            return index
        else:
            raise ValueError(f'{value} not in list')    
    except IndexError:
        raise ValueError(f'{value} not in list')
