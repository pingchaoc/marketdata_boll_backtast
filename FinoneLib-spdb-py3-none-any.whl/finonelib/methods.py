from datetime import datetime
from finonelib.state import state
from finonelib.structs import *
import copy
import csv
import math
import numpy as np
import pandas as pd
import os
import random
import scipy.stats as st
import re
import bisect
from finonelib.utils import sequence_index

import logging

logger = logging.getLogger(__name__)

# def insert_order(order_list, new_order, key):
    # import pdb; pdb.set_trace()
    # insert_position = -1
    # for index, order in enumerate(order_list):
        # if key(order) > key(new_order):
            # insert_position = index
            # break
    # else:
        # order_list.insert(len(order_list), new_order)
        # return
    # # if insert_position >= 0:
    # order_list.insert(insert_position, new_order)

def insert_order(order_list, new_order, key):
    start = 0
    stop = len(order_list)-1
    mid = 0
    while start <= stop:
        mid=(start+stop) // 2
        if key(new_order) >= key(order_list[mid]):
            start = mid + 1
        elif key(new_order) < key(order_list[mid]):
            stop = mid - 1
    try:
        if key(new_order) >= key(order_list[mid]):
            mid = mid + 1
    except IndexError:
        mid = -1
    order_list.insert(mid, new_order)

@typechecked
def clob_to_ohlc(clobs: List[ClobData]) -> OHLCData:
    open = clobs[0].p_bid_array[0]
    close = clobs[-1].p_bid_array[0]
    bid_price_list = [clob.p_bid_array[0] for clob in clobs]
    high = max(bid_price_list)
    low = min(bid_price_list)
    return OHLCData(clobs[-1].timestamp, clobs[-1].symbol, open, high, low, close)


def clob_to_limit_orders(market_clob):
    """
        function: clob转成order
        args: clob  (item.clob type-ClobData)
        return: bid ask 对应的order列表

    """

    limit_bid_order_list = list()
    limit_ask_order_list = list()

    for index, p_ask in enumerate(market_clob.p_ask_array):
        ask_order = Order(timestamp=market_clob.timestamp,
                          symbol=market_clob.symbol,
                          price=p_ask,
                          qty=market_clob.q_ask_array[index],
                          order_type=OrderType.LIMIT,
                          side=OrderSide.ASK,
                          action=OrderAction.PLACE,
                          ownership=OrderOwnership.OTHERS,
                          bundle_id=state.generate_bundle_id())
        ask_order.order_id = -1
        ask_order.market_order_id = state.generate_market_order_id()
        limit_ask_order_list.append(ask_order)

    for index, p_bid in enumerate(market_clob.p_bid_array):
        bid_order = Order(timestamp=market_clob.timestamp,
                          symbol=market_clob.symbol,
                          price=p_bid,
                          qty=market_clob.q_bid_array[index],
                          order_type=OrderType.LIMIT,
                          side=OrderSide.BID,
                          action=OrderAction.PLACE,
                          ownership=OrderOwnership.OTHERS,
                          bundle_id=state.generate_bundle_id())
        bid_order.order_id = -1
        bid_order.market_order_id = state.generate_market_order_id()
        limit_bid_order_list.append(bid_order)

    # 排序
    limit_bid_order_list.sort(key=lambda x: x.price, reverse=True)
    limit_ask_order_list.sort(key=lambda x: x.price, reverse=False)

    return limit_bid_order_list, limit_ask_order_list

def limit_orders_to_clob_market_all(limit_bid_orders, limit_ask_orders, time_stamp, symbol):

    limit_bid_orders.sort(key=lambda x: x.price, reverse=True)
    limit_ask_orders.sort(key=lambda x: x.price, reverse=False)
    time = time_stamp
    p_bid_array = []
    q_bid_array = []
    p_ask_array = []
    q_ask_array = []

    unique_bid_prices = list(set([x.price for x in limit_bid_orders]))
    unique_bid_prices.sort()
    unique_bid_prices.reverse()
    unique_ask_prices = list(set([x.price for x in limit_ask_orders]))
    unique_ask_prices.sort()

    bid_price_qty = {}
    for x in limit_bid_orders:
        if not x.price in bid_price_qty:
            bid_price_qty[x.price] = 0
        bid_price_qty[x.price] += x.qty
    ask_price_qty = {}
    for x in limit_ask_orders:
        if not x.price in ask_price_qty:
            ask_price_qty[x.price] = 0
        ask_price_qty[x.price] += x.qty

    for price in unique_bid_prices:
        p_bid_array.append(price)
        q_bid_array.append(bid_price_qty[price])
        # if len(p_bid_array) > 4:
        #     break

    for price in unique_ask_prices:
        p_ask_array.append(price)
        q_ask_array.append(ask_price_qty[price])
        # if len(p_ask_array) > 4:
        #     break

    clob = ClobData(time, symbol, q_bid_array, p_bid_array, q_ask_array, p_ask_array)

    return clob


def limit_orders_to_clob(limit_bid_orders, limit_ask_orders, timestamp, symbol):

    # limit_bid_orders.sort(key=lambda x: (-x.price, x.timestamp))
    # limit_ask_orders.sort(key=lambda x: (x.price, x.timestamp))
    p_bid_array = []
    q_bid_array = []
    p_ask_array = []
    q_ask_array = []

    price_grade = 0
    last_price = 0

    for order in limit_bid_orders:
        if order.price != last_price:
            last_price = order.price
            price_grade += 1
            if price_grade > 5:
                break
            p_bid_array.append(order.price)
            q_bid_array.append(order.qty)
        else:
            q_bid_array[-1] += order.qty
        # if len(q_bid_array) < price_grade:
        #     q_bid_array.append(order.qty)
        # else:
        #     q_bid_array[price_grade - 1] += order.qty

    price_grade = 0
    last_price = 0
    for order in limit_ask_orders:
        if order.price != last_price:
            last_price = order.price
            price_grade += 1
            if price_grade > 5:
                break
            p_ask_array.append(order.price)
            q_ask_array.append(order.qty)
        else:
            q_ask_array[-1] += order.qty
        # if len(q_ask_array) < price_grade:
        #     q_ask_array.append(order.qty)
        # else:
        #     q_ask_array[price_grade - 1] += order.qty
    clob = ClobData(timestamp, symbol, q_bid_array, p_bid_array, q_ask_array, p_ask_array)

    return clob


class OrderSimulator:
    def __init__(self, symbol, depth, min_move, qty_min, qty_max):
        self.symbol = symbol
        self.depth = depth
        self.min_move = min_move
        self.qty_min = qty_min
        self.qty_max = qty_max
        self.bid_limit_lambda = []
        self.bid_cancel_lambda = []
        self.bid_market_lambda = []
        self.ask_limit_lambda = []
        self.ask_cancel_lambda = []
        self.ask_market_lambda = []

    def get_buy_market_order(self, time, rate_mean, rate_var):
        rate = max(0, np.random.normal(rate_mean, rate_var))
        qty = self.poisson_generator(rate, self.qty_max)
        mkt_order = list()
        if qty >= 1:
            order = Order(timestamp=time,
                          symbol=self.symbol,
                          price=0,
                          qty=qty,
                          order_type=OrderType.MARKET,
                          side=OrderSide.BID,
                          action=OrderAction.PLACE,
                          ownership=OrderOwnership.OTHERS,
                          bundle_id=state.get_bundle_id())

            # this order is not from maker, set order_id to -1
            order.order_id = -1
            order.market_order_id = state.generate_market_order_id()

            mkt_order.append(order)

        return mkt_order

    def get_sell_market_order(self, time, rate_mean, rate_var):
        rate = max(0, np.random.normal(rate_mean, rate_var))
        qty = self.poisson_generator(rate, self.qty_max)
        mkt_order = list()
        if qty >= 1:
            order = Order(timestamp=time,
                          symbol=self.symbol,
                          price=0,
                          qty=qty,
                          order_type=OrderType.MARKET,
                          side=OrderSide.ASK,
                          action=OrderAction.PLACE,
                          ownership=OrderOwnership.OTHERS,
                          bundle_id=state.get_bundle_id())

            # this order is not from maker, set order_id to -1
            order.order_id = -1
            order.market_order_id = state.generate_market_order_id()

            mkt_order.append(order)
        return mkt_order

    def get_bid_cancellation_orders(self, clob_limit_bid_list, clob_limit_ask_list, time, A_up, A_down, K_up,
                                    K_down):
        order_list = []
        clob = limit_orders_to_clob(clob_limit_bid_list, clob_limit_ask_list, time, self.symbol)
        length = len(clob.p_bid_array)
        A = round(random.uniform(A_down, A_up), 3)
        K = round(random.uniform(K_down, K_up), 3)
        if len(clob.p_ask_array) == 0:
            return list()
        p_ask_best = clob.p_ask_array[0]
        for i in range(length):
            cancel_rate = self.bid_cancel_order_ratio(clob.p_bid_array[i], p_ask_best, A, K)
            cancel_qty = int(cancel_rate * clob.q_bid_array[i])
            if cancel_qty >= 1:
                order = Order(timestamp=time,
                              symbol=self.symbol,
                              price=clob.p_bid_array[i],
                              qty=cancel_qty,
                              order_type=OrderType.LIMIT,
                              side=OrderSide.BID,
                              action=OrderAction.CANCEL,
                              ownership=OrderOwnership.OTHERS,
                              bundle_id=state.get_bundle_id())

                # this order is not from maker, set order_id to -1
                order.order_id = -1
                order.market_order_id = state.generate_market_order_id()
                order_list.append(order)
        return order_list

    def get_ask_cancellation_orders(self, clob_limit_bid_list, clob_limit_ask_list, time, A_up, A_down, K_up,
                                    K_down):
        order_list = []
        clob = limit_orders_to_clob(clob_limit_bid_list, clob_limit_ask_list, time, self.symbol)
        length = len(clob.p_ask_array)
        A = round(random.uniform(A_down, A_up), 3)
        K = round(random.uniform(K_down, K_up), 3)
        if len(clob.p_bid_array) == 0:
            return list()
        p_bid_best = clob.p_bid_array[0]
        for i in range(length):
            cancel_rate = self.ask_cancel_order_ratio(clob.p_ask_array[i], p_bid_best, A, K)
            cancel_qty = int(cancel_rate * clob.q_ask_array[i])
            if cancel_qty >= 1:
                order = Order(timestamp=time,
                              symbol=self.symbol,
                              price=clob.p_ask_array[i],
                              qty=cancel_qty,
                              order_type=OrderType.LIMIT,
                              side=OrderSide.ASK,
                              action=OrderAction.CANCEL,
                              ownership=OrderOwnership.OTHERS,
                              bundle_id=state.get_bundle_id())

                # this order is not from maker, set order_id to -1
                order.order_id = -1
                order.market_order_id = state.generate_market_order_id()
                order_list.append(order)
        return order_list

    def get_bid_limit_orders(self, clob_limit_bid_list, clob_limit_ask_list, time, A_up, A_down, K_up, K_down):
        order_list = []
        A = round(random.uniform(A_down, A_up), 3)
        K = round(random.uniform(K_down, K_up), 3)
        # TODO simulate limit order
        if len(clob_limit_ask_list) == 0:
            return list()
        p_ask_best = clob_limit_ask_list[0].price
        # 生成此时刻的市场新limit order
        for i in range(self.depth):
            bid = p_ask_best - (i + 1) * self.min_move
            qty = int(self.limit_bid_arrive_order_generator(bid, p_ask_best, A, K, self.qty_max))
            # print("Bid Order Qty:" + str(qty) + ", Price:" + str(bid))
            if qty >= 1:
                order = Order(timestamp=time,
                              symbol=self.symbol,
                              price=bid,
                              qty=qty,
                              order_type=OrderType.LIMIT,
                              side=OrderSide.BID,
                              action=OrderAction.PLACE,
                              ownership=OrderOwnership.OTHERS,
                              bundle_id=state.get_bundle_id())

                # this order is not from maker, set order_id to -1
                order.order_id = -1
                order.market_order_id = state.generate_market_order_id()
                order_list.append(order)

        return order_list

    def get_ask_limit_orders(self, clob_limit_bid_list, clob_limit_ask_list, time, A_up, A_down, K_up, K_down):
        order_list = []
        A = round(random.uniform(A_down, A_up), 3)
        K = round(random.uniform(K_down, K_up), 3)
        # TODO simulate limit order
        if len(clob_limit_bid_list) == 0:
            return list()
        p_bid_best = clob_limit_bid_list[0].price
        for i in range(self.depth):
            ask = p_bid_best + (i + 1) * self.min_move
            qty = int(self.limit_ask_arrive_order_generator(ask, p_bid_best, A, K, self.qty_max))
            # print("Ask Order Qty:" + str(qty) + ", Price:" + str(ask))
            if qty >= 1:
                order = Order(timestamp=time,
                              symbol=self.symbol,
                              price=ask,
                              qty=qty,
                              order_type=OrderType.LIMIT,
                              side=OrderSide.ASK,
                              action=OrderAction.PLACE,
                              ownership=OrderOwnership.OTHERS,
                              bundle_id=state.get_bundle_id())

                # this order is not from maker, set order_id to -1
                order.order_id = -1
                order.market_order_id = state.generate_market_order_id()
                order_list.append(order)
        return order_list

    def get_init_clob(self, time, price_mid, depth, spread):

        q_bid_array = []
        q_ask_array = []
        p_bid_array = []
        p_ask_array = []

        ask_p = price_mid + spread * self.min_move / 2
        bid_p = price_mid - spread * self.min_move / 2

        for i in range(depth):
            ask_p += self.min_move
            p_ask_array.append(ask_p)
            qty_ask = int(self.func_qty(ask_p, price_mid, self.qty_max, self.qty_min))
            q_ask_array.append(qty_ask)

            bid_p -= self.min_move
            p_bid_array.append(bid_p)
            qty_bid = int(self.func_qty(bid_p, price_mid, self.qty_max, self.qty_min))
            q_bid_array.append(qty_bid)

        clob = ClobData(time, self.symbol, q_bid_array, p_bid_array, q_ask_array, p_ask_array)

        return clob

    def func_qty(self, price, price_mid, qty_max, qty_min):
        rate = 10
        return (qty_max - qty_min) * (1 - math.exp(-rate * abs(price - price_mid)))

    def poisson_generator(self, rate, qty_max):
        rand_prob = random.random()
        return self.poisson_num(rate, rand_prob, qty_max)

    def poisson_num(self, rate, prob, vol_max):
        index = int(st.poisson.ppf(prob, rate))
        return min(index, vol_max)

    def limit_bid_arrive_order_generator(self, bid, p_ask_best, A, K, qty_max):
        delta = p_ask_best - bid
        arrive_rate = A * math.exp(-K * delta)
        rand_prob = random.random()
        return self.poisson_num(arrive_rate, rand_prob, qty_max)

    def limit_ask_arrive_order_generator(self, ask, p_bid_best, A, K, qty_max):
        delta = ask - p_bid_best
        arrive_rate = A * math.exp(-K * delta)
        rand_prob = random.random()
        return self.poisson_num(arrive_rate, rand_prob, qty_max)

    def bid_cancel_order_ratio(self, bid, p_ask_best, A, K):
        delta = p_ask_best - bid
        mean = A * math.exp(-K * delta)
        vari = 0.01 * mean
        return min(0.6, abs(np.random.normal(mean, vari)))

    def ask_cancel_order_ratio(self, ask, p_bid_best, A, K):
        delta = ask - p_bid_best
        mean = A * math.exp(-K * delta)
        vari = 0.01 * mean
        return min(0.6, abs(np.random.normal(mean, vari)))


def makefilename(symbol: str, key: str) -> str:
    os.makedirs(f'{state.settings.RESULT_ID}', exist_ok=True)
    if state.settings.SPARK:
        return f"{state.settings.RESULT_ID}/{symbol}_{state.settings.RECORD_ID}_{state.settings.RESULT_ID}_{key}".upper().replace('@', '_') + '.csv'
    if 'MC_PATH_COUNTER' not in state.settings:
        return f"{state.settings.RESULT_ID}/{symbol}_{key}.csv"
    else:
        mc_path = state.settings.MC_PATH_COUNTER
        return f"{state.settings.RESULT_ID}/{symbol}_{key}_path_{mc_path}.csv"


def ts_to_datetime(ts):
    return datetime.fromtimestamp(int(ts)/1000).strftime('%Y-%m-%d %H:%M:%S.%f')


def sort_csv_by_ts(file_name):
    df = pd.read_csv(file_name, float_precision='round_trip')
    df = df.sort_values(by=['ts','dataset'],axis = 0,ascending = True)
    df = df.reset_index()
    try:
        del df['index']
    except Exception as e:
        pass
    df['id'] = df.index
    df.to_csv(file_name, index=False)

# WRITE TO CSV
def write_backtest_detail_file(symbols):
    file_name = makefilename('all', 'backtest_detail')
    with open(file_name, 'w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(('id', 'dataset','ts', 'time', 'acc_pnl', 'acc_inventory', 'acc_cash', 'market_price','reporting_acc_pnl','reporting_acc_cash'))
        table_index = 0
        for symbol in symbols:
            info = state.get_info(symbol)
            for index, ts in enumerate(info.time_axis):
                writer.writerow((table_index, 
                                symbol,
                                ts, 
                                ts_to_datetime(ts), 
                                info.acc_pnl[index],
                                info.acc_inventory[index],
                                info.acc_cash[index], 
                                info.bid_prices[index],
                                info.reporting_acc_pnl[index],
                                info.reporting_acc_cash[index]))
                table_index += 1
    sort_csv_by_ts(file_name)


def write_total_pnl(symbols):
    file_name = makefilename('all', 'total_pnl')
    with open(file_name, 'w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(('id', 'dataset','ts', 'time', 'acc_pnl', 'acc_inventory', 'acc_cash', 'market_price', 'reporting_acc_pnl','reporting_acc_cash'))
        table_index = 0
        for index, ts in enumerate(state.get_info(symbols[0]).time_axis):
            writer.writerow((table_index, 
                            'total',
                            ts, 
                            ts_to_datetime(ts), 
                            sum([state.get_info(symbol).acc_pnl[index] for symbol in symbols]),
                            None,
                            None,
                            None,
                            None,
                            None))
            table_index += 1

def write_order_report_file(symbols):
    order_report_file = makefilename('all', 'orders')
    with open(order_report_file, 'w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        index = 0
        writer.writerow(('id', 'dataset', 'ts', 'time', 'price', 'qty', 'order_side', 'order_type', 'action', 'tag', 'order_id', 'market_order_id','bundle_id'))
        for symbol in symbols:
            for order in state.get_info(symbol).orders:
                writer.writerow((index,
                                symbol,
                                order.timestamp,
                                ts_to_datetime(order.timestamp),
                                order.price,
                                order.qty,
                                'BID' if order.side == OrderSide.BID else 'ASK',
                                'LIMIT' if order.order_type == OrderType.LIMIT else 'MARKET',
                                'PLACE' if order.action == OrderAction.PLACE else 'CANCEL',
                                order.tag,
                                order.order_id,
                                order.market_order_id,
                                order.bundle_id))
                index += 1
    sort_csv_by_ts(order_report_file)

def write_report_file(symbols):
    file_name = makefilename('all', "REPORT")
    with open(file_name, 'w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(('id', 'ts', 'time', 'dataset','cash', 'inventory', 'bid', 'ask', 'pnl'))

        table_index = 0

        match_type = state.match_type
        for symbol in symbols:
            PRECISION = state.get_precision_by_symbol(symbol)
            info = state.get_info(symbol)
            ts_clobs = []
            clob_index = 0
            # make sure each point in time_axis has its own clob value
            for ts in info.time_axis:
                while clob_index < len(info.clobs) and info.clobs[clob_index].timestamp <= ts:
                    clob_index += 1
                if clob_index == 0:
                    ts_clobs.append(info.clobs[clob_index])
                else:
                    ts_clobs.append(info.clobs[clob_index-1])

            if match_type == 'LC':
                if state.get_info(symbol).time_axis:
                    last_data = None
                    cur_date = datetime.fromtimestamp(info.time_axis[0] / 1000).date()
                    for index, ts in enumerate(info.time_axis):
                        tmp_date = datetime.fromtimestamp(ts / 1000).date()
                        if tmp_date != cur_date:
                            writer.writerow(last_data)
                            cur_date = tmp_date
                            table_index += 1
                        final_ts = info.time_axis[index]
                        final_cash = round(info.acc_cash[index], PRECISION)
                        final_inventory = info.acc_inventory[index]
                        final_bid = ts_clobs[index].p_bid_array[0] if ts_clobs else 0
                        final_ask = ts_clobs[index].p_ask_array[0] if ts_clobs else 0
                        final_pnl = round(info.acc_pnl[index], PRECISION)
                        last_data = (table_index, final_ts, ts_to_datetime(final_ts), symbol, final_cash, final_inventory, final_bid, final_ask, final_pnl)
                    writer.writerow(last_data)
            elif match_type == 'LP':
                for index, ts in enumerate(info.time_axis):
                    data = (table_index,
                            ts, 
                            ts_to_datetime(ts), 
                            symbol,
                            round(info.acc_cash[index], PRECISION), 
                            info.acc_inventory[index], 
                            ts_clobs[index].p_bid_array[0] if ts_clobs else 0, 
                            ts_clobs[index].p_ask_array[0] if ts_clobs else 0, 
                            round(info.acc_pnl[index], PRECISION))
                    writer.writerow(data)
                    table_index += 1

    sort_csv_by_ts(file_name)


def write_clobs_file(symbols):
    file_name = makefilename('all', "clobs")
    with open(file_name, 'w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(('id', 'ts', 'time', 'dataset', 'group_id', 'cash', 'inventory', 'bid', 'ask', 'acc_pnl', 'pnl','price'))
        for symbol in symbols:
            PRECISION = state.get_precision_by_symbol(symbol)
            info = state.get_info(symbol)
            trade_executions_timestamp = [x.timestamp for x in info.executions if x.status in [ExecutionStatus.FILLED_FULLY, ExecutionStatus.FILLED_PARTIALLY] and x.ownership == OrderOwnership.MARKET_MAKER]
            trade_list = info.trade_list
            trade_ts_list = [x.timestamp for x in trade_list]
            last_acc_pnl = 0
            real_group_id = 0
            last_tmp_group_id = -2
            for index, clob in enumerate(info.clobs):
                group_id = bisect.bisect_left(trade_executions_timestamp, clob.timestamp)
                if group_id != last_tmp_group_id:
                    real_group_id +=1
                    last_tmp_group_id = group_id
                current_ts_index = bisect.bisect_right(info.time_axis, clob.timestamp) - 1
                acc_pnl = round(info.acc_pnl[current_ts_index], PRECISION) if current_ts_index >= 0 else 0

                price = None
                current_trade_index = bisect.bisect_left(trade_ts_list, clob.timestamp)
                if trade_list:
                    if current_trade_index < len(trade_list):
                        price = trade_list[current_trade_index].price
                    else:
                        price = trade_list[-1].price

                data = (index,
                        clob.timestamp, 
                        ts_to_datetime(clob.timestamp), 
                        symbol,
                        real_group_id,
                        round(info.acc_cash[current_ts_index], PRECISION) if current_ts_index >= 0 else 0, 
                        round(info.acc_inventory[current_ts_index], PRECISION) if current_ts_index >= 0 else 0, 
                        clob.p_bid_array[0] if clob.p_bid_array else 0, 
                        clob.p_ask_array[0] if clob.p_ask_array else 0, 
                        acc_pnl,
                        acc_pnl - last_acc_pnl,
                        price)
                last_acc_pnl = acc_pnl
                writer.writerow(data)

    sort_csv_by_ts(file_name)


def write_strategy_trade_record_file_by_execution(symbols):
    trade_record_file = makefilename('all', 'filled_executions')
    with open(trade_record_file, 'w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(('id', 'ts', 'time','dataset', 'group_id', 'market_id', 'order_id',  'order_type', 'order_side', 'price', 'qty', 'tag', 'inventory', 'split'))
        for symbol in symbols:
            PRECISION = state.get_precision_by_symbol(symbol)
            info = state.get_info(symbol)
            order_ids = [x.order_id for x in info.orders if x.action != OrderAction.CANCEL]
            place_orders = [x for x in info.orders if x.action != OrderAction.CANCEL]
            clob_ts_lst = [x.timestamp for x in info.clobs]
            trade_executions = [x for x in info.executions if x.status in [ExecutionStatus.FILLED_FULLY, ExecutionStatus.FILLED_PARTIALLY] and x.ownership == OrderOwnership.MARKET_MAKER]

            real_group_id = 0
            last_tmp_group_id = -2
            start_index = 0
            for index, execution in enumerate(trade_executions):
                group_id = bisect.bisect_right(clob_ts_lst, execution.timestamp) - 1
                if group_id != last_tmp_group_id:
                    real_group_id +=1
                    last_tmp_group_id = group_id

                start_index = sequence_index(order_ids, execution.order_id) 
                current_order = place_orders[start_index] if info.orders else None
                
                tag = current_order.tag if current_order else '-'
                tag = tag if tag else '-'

                split=0
                if execution.status == ExecutionStatus.FILLED_PARTIALLY or (current_order and execution.qty < current_order.qty):
                    split=1

                writer.writerow((index,
                                execution.timestamp,
                                ts_to_datetime(execution.timestamp),
                                symbol,
                                real_group_id,
                                execution.market_order_id,
                                execution.order_id,
                                'LIMIT' if execution.order_type == OrderType.LIMIT else 'MARKET',
                                'BID' if execution.side == OrderSide.BID else 'ASK',
                                round(execution.price, PRECISION),
                                execution.qty,
                                tag,
                                info.acc_inventory[sequence_index(info.time_axis, execution.timestamp)] if info.acc_inventory else 0,
                                split ))

    sort_csv_by_ts(trade_record_file)


def write_strategy_trade_record_file(symbols):
    trade_record_file = makefilename('all', 'trade_record')
    with open(trade_record_file, 'w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(('id', 'dataset', 'ts', 'time', 'order_type', 'order_side', 'price', 'qty'))
        index = 0
        for symbol in symbols:
            PRECISION = state.get_precision_by_symbol(symbol)
            trade_executions = [x for x in state.get_info(symbol).executions if x.status in [ExecutionStatus.FILLED_FULLY, ExecutionStatus.FILLED_PARTIALLY, ExecutionStatus.CANCELLED]]
            for execution in trade_executions:
                writer.writerow((index,
                                symbol,
                                execution.timestamp,
                                ts_to_datetime(execution.timestamp),
                                'LIMIT' if execution.order_type == OrderType.LIMIT else 'MARKET',
                                'BID' if execution.side == OrderSide.BID else 'ASK',
                                round(execution.price, PRECISION),
                                execution.qty))
                index +=1

    sort_csv_by_ts(trade_record_file)

def write_performance_file(symbols):
    performance_file = makefilename('all', 'performance')
    with open(performance_file, 'w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        performance_headers = [
            'mm_total_revenue',
            'floating_pnl',
            'realized_pnl',
            'mm_annualized_return',
            'max_pnl_timepoint',

            'mm_maximum_retracement_value',
            'mm_maximum_retracement_time',
            'max_draw_down_start_time',
            'max_draw_down_end_time',
            'mm_return_retracement_ratio',

            'transaction_order_rate',
            'total_volume',
            'average_volume',
            'total_transactions',
            'average_transactions',
            'transaction_success_rate',
            'best_order_rate',
            'submit_orders_times',
            'submit_orders_volume',
            'avg_bar_volume',

            'mm_historical_average_holding',
            'mm_historical_average_holding_time',
            'long_max',
            'long_max_timestamp',
            'short_max',
            'short_max_timestamp'
        ]
        writer.writerow(['dataset','is_reporting','currency'] + performance_headers)
        for symbol in symbols:
            performances = state.performance_calculator.get_strategy_performance(symbol)
            _, currency, _ = form_fx_pair(symbol[:3], symbol[3:]) 
            writer.writerow([symbol, 0, currency]+[performances[header] for header in performance_headers])
        if state.settings.REPORTING_CURRENCY:  
            if state.symbols == state.symbols_reportable:  # 有可能有标的没有元数据 只要一个标的没有元数据, total_pnl就不可信
                for symbol in symbols:
                    performances = state.performance_calculator.get_strategy_reporting_performance(symbol)
                    writer.writerow([symbol, 1, state.settings.REPORTING_CURRENCY]+[performances[header] if header in performances else None for header in performance_headers])

                performances = state.performance_calculator.get_strategy_total_performance()
                writer.writerow(['total', 1, state.settings.REPORTING_CURRENCY]+[performances[header] if header in performances else None for header in performance_headers])
            else:
                logger.warn('部分symbol无元数据, reporting数据无意义!!!')


def put_results_to_hdfs():
    import ibis
    hdfs = ibis.hdfs_connect(host=state.settings.HADOOP_MASTER_HOST, port=50070, user='admin')
    client = ibis.impala.connect(host=state.settings.HADOOP_IMPALA_HOST, hdfs_client=hdfs)
    file_dir = os.path.join('.', str(state.settings.RESULT_ID))
    for _, _, csv_names in os.walk(file_dir):
        for csv_name in csv_names:
            # if csv_name.startswith('ALL'):
            #     continue
            import_csv(client=client, hdfs=hdfs,
                file_name=os.path.join(file_dir,csv_name),
                db_name=state.settings.STRATEGY_FILE_HDFS_PATH.split('/')[-1],
                file_dir=f'{state.settings.STRATEGY_FILE_HDFS_PATH}/{state.settings.RESULT_ID}/', 
                drop=True
            )
    import shutil
    shutil.rmtree(f'{state.settings.RESULT_ID}')

def put_file_to_hdfs(path, delete_local=False):
    import ibis
    hdfs = ibis.hdfs_connect(host=state.settings.HADOOP_MASTER_HOST, port=50070, user='admin')
    client = ibis.impala.connect(host=state.settings.HADOOP_IMPALA_HOST, hdfs_client=hdfs)
    import_csv(client=client, hdfs=hdfs,
        file_name=path,
        db_name=state.settings.STRATEGY_FILE_HDFS_PATH.split('/')[-1],
        file_dir=f'{state.settings.STRATEGY_FILE_HDFS_PATH}/{state.settings.RESULT_ID}/', 
        drop=True
    )
    if delete_local:
        import os
        os.remove(path)


def fit_col_name(name):
    _name = name
    name = name.lower()
    if re.findall('[#\[\] ]', name):
        raise Exception('Invalid col name {}! Please fix your csv file')
    return name


def fit_dtype(dtype):
    if dtype.name == 'object':
        return 'string'
    if 'float' in dtype.name:
        if dtype.name == 'float64':
            return 'double'
        return 'float'
    if dtype.name == 'bool':
        return 'boolean'
    if 'datetime' in dtype.name:
        return 'timestamp'
    return dtype.name


def fit_table_name(file_name):
    table_name = file_name.split('/')[-1].split('.')[0].lower()
    table_name = re.sub(' ', '_', table_name)
    return table_name


def form_fx_pair(ccy1, ccy2):
    fx_pair = state.fx_pairs.get((ccy1, ccy2), None)
    if ccy1 == ccy2:
        return ccy1, ccy2 ,f'{ccy1}{ccy2}'
    if not fx_pair:
        return '', '', ''
    return fx_pair['base_currency'], fx_pair['pricing_currency'], fx_pair['display_name']


def import_csv(client, hdfs, file_name, table_name='', db_name='default', file_dir=None, drop=False):
    import ibis
    table_name = fit_table_name(file_name) if not table_name else table_name
    df = pd.read_csv(file_name, float_precision="round_trip")
    headers = list(df.dtypes.items())
    print(headers)
    for i in range(len(headers)):
        name = headers[i][0]
        dtype = headers[i][1]
        name = fit_col_name(name)
        dtype = fit_dtype(dtype)
        headers[i] = (name, dtype)
    print('Following are the header&type to be stored in hive:')
    print(headers)
    schema = ibis.schema(headers)
    if not client.exists_database(db_name):
        client.create_database(db_name)
    db = client.database(db_name)
    if table_name in db.list_tables():
        if not drop:
            raise Exception('Table {} already exists!'.format(table_name))
        else:
            db.table(table_name).drop()
    db.create_table(table_name, schema=schema)
    table = db.table(table_name)
    table.insert(df)
    if not file_dir:
        hdfs.put('/user/admin/', file_name, overwrite=True)
    else:
        hdfs.mkdir(file_dir)
        hdfs.put(file_dir, file_name, overwrite=True)


def get_df_order_pirce_list(symbol, table_name):
    if state.settings.DATASOURCE == 'hadoop':
        import ibis
        ibis.options.sql.default_limit = None
        hdfs = ibis.hdfs_connect(host=state.settings.HADOOP_MASTER_HOST, port=50070, user='admin')
        client = ibis.impala.connect(host=state.settings.HADOOP_WORKER_HOSTS[0], hdfs_client=hdfs)
        db = client.database(table_name.split('.')[0])
        table_order = db.table(table_name.split('.')[1])

        start_time = 0
        # 去start_time的前值
        condition = [table_order.ts<state.settings.START_TIME]
        df_order = table_order.filter(condition).sort_by([('ts', False)]).limit(1).execute()
        for row in df_order.iterrows():
            order_info = row[1]
            start_time = order_info['ts']

        condition = [table_order.ts>=start_time, table_order.ts<=state.settings.END_TIME]
        df_order = table_order.filter(condition).sort_by(['ts', 'id']).execute()
        ret_data = [[],[]]
        for row in df_order.iterrows():
            order_info = row[1]
            ret_data[0].append(order_info['ts'])
            ret_data[1].append(round(float(order_info['price']), state.get_precision_by_symbol(symbol)))
            # ret_data[order_info['ts']] = round(float(order_info['price']), state.get_precision_by_symbol(symbol))
        return ret_data

    elif state.settings.DATASOURCE == 'local':
        df_order = pd.read_csv(state.settings.LOCAL_DATA_PATH[symbol], header=0)
        ret_data = [[],[]]
        ret_data[0] = list(df_order[df_order.ts>=state.settings.START_TIME][df_order.ts<state.settings.END_TIME]['ts'])
        ret_data[1] = list(df_order[df_order.ts>=state.settings.START_TIME][df_order.ts<state.settings.END_TIME]['price'])
        return ret_data


def get_df_ohlc_price_list(symbol, table_name):
    if state.settings.DATASOURCE == 'hadoop':
        import ibis
        ibis.options.sql.default_limit = None
        hdfs = ibis.hdfs_connect(host=state.settings.HADOOP_MASTER_HOST, port=50070, user='admin')
        client = ibis.impala.connect(host=state.settings.HADOOP_WORKER_HOSTS[0], hdfs_client=hdfs)
        db = client.database(table_name.split('.')[0])
        table_order = db.table(table_name.split('.')[1])

        start_time = 0
        # 去start_time的前值
        condition = [table_order.ts<state.settings.START_TIME]
        df_order = table_order.filter(condition).sort_by([('ts', False)]).limit(1).execute()
        for row in df_order.iterrows():
            order_info = row[1]
            start_time = order_info['ts']
            
        condition = [table_order.ts>=start_time, table_order.ts<state.settings.END_TIME]
        df_order = table_order.filter(condition).sort_by(['ts']).execute()
        # ret_data = {}
        ret_data = [[],[]]
        for row in df_order.iterrows():
            order_info = row[1]
            ret_data[0].append(order_info['ts'])
            ret_data[1].append(round(float(order_info['close']), state.get_precision_by_symbol(symbol)))
            # ret_data[order_info['ts']] = round(float(order_info['close']), state.get_precision_by_symbol(symbol))
        return ret_data
    elif state.settings.DATASOURCE == 'local':
        df_order = pd.read_csv(state.settings.LOCAL_DATA_PATH[symbol], header=0)
        ret_data = [[],[]]
        ret_data[0] = list(df_order[df_order.ts>=state.settings.START_TIME][df_order.ts<state.settings.END_TIME]['ts'])
        ret_data[1] = list(df_order[df_order.ts>=state.settings.START_TIME][df_order.ts<state.settings.END_TIME]['close'])
        return ret_data


def plt_position_report(symbol):
    info = state.get_info(symbol)
    import matplotlib.pyplot as plt
    import matplotlib.ticker as ticker
    len_time_axis = len(info.time_axis)

    fig = plt.figure(figsize=(20, 15))

    ax = plt.subplot(3, 2, 1)


    # plt.plot(__strategy__.time_axis, [trade.price for trade in __strategy__.trade_list])
    # time_axis = [str() for clob in info.clobs]
    time_axis = [datetime.fromtimestamp(clob.timestamp/1000) for clob in info.clobs]
    def format_clob_date(x, pos=None):
        #保证下标不越界,很重要,越界会导致最终plot坐标轴label无显示
        thisind = np.clip(int(x+0.5), 0, len(time_axis)-1)
        return time_axis[thisind].strftime('%Y-%m-%d')
    ind = np.arange(len(time_axis))
    plt.plot(ind, [clob.p_bid_array[0] if clob.p_bid_array else clob.p_ask_array[0] for clob in info.clobs])
    ax.xaxis.set_major_formatter(ticker.FuncFormatter(format_clob_date))
    plt.ylabel("Trade Price")
    plt.title("Market Price")


    ind = np.arange(len(info.time_axis))
    def format_date(x, pos=None):
        thisind = np.clip(int(x+0.5), 0, len(info.time_axis)-1)
        return datetime.fromtimestamp(info.time_axis[thisind]/1000).strftime('%Y-%m-%d')
    ax = plt.subplot(3, 2, 2)
    #
    plt.plot(ind, info.acc_cash[:len_time_axis])
    ax.xaxis.set_major_formatter(ticker.FuncFormatter(format_date))
    plt.ylabel("Acc Cash")
    plt.title("Cash Balance")

    ax = plt.subplot(3, 2, 3)
    plt.plot(ind, info.acc_inventory[:len_time_axis])
    ax.xaxis.set_major_formatter(ticker.FuncFormatter(format_date))
    plt.ylabel("Acc Inventory")
    plt.title("Inventory")

    ax = plt.subplot(3, 2, 4)
    plt.plot(ind, info.acc_inventory_value[:len_time_axis])
    ax.xaxis.set_major_formatter(ticker.FuncFormatter(format_date))
    plt.ylabel("Acc Inventory Value")
    plt.title("Inventory Value")

    ax = plt.subplot(3, 2, 5)
    plt.plot(ind, info.acc_trade_volume[:len_time_axis])
    ax.xaxis.set_major_formatter(ticker.FuncFormatter(format_date))
    plt.ylabel("Acc Trade Volume")
    plt.title("Trade Volume")

    ax = plt.subplot(3, 2, 6)
    plt.plot(ind, info.acc_pnl[:len_time_axis])
    ax.xaxis.set_major_formatter(ticker.FuncFormatter(format_date))
    plt.ylabel("Acc Pnl")
    plt.title("Pnl")

    fig.autofmt_xdate()
    fig.suptitle(symbol)
    plt.show()

def plt_total_pnl():
    import matplotlib.pyplot as plt
    import matplotlib.ticker as ticker
    fig = plt.figure(figsize=(10, 15))
    time_axis = [datetime.fromtimestamp(ts/1000) for ts in state.total_pnl.keys()]
    def format_date(x, pos=None):
        #保证下标不越界,很重要,越界会导致最终plot坐标轴label无显示
        thisind = np.clip(int(x+0.5), 0, len(time_axis)-1)
        return time_axis[thisind].strftime('%Y-%m-%d')
    ind = np.arange(len(time_axis))
    plt.plot(ind, list(state.total_pnl.values()))
    fig.axes[0].xaxis.set_major_formatter(ticker.FuncFormatter(format_date))
    plt.ylabel("Total PnL")
    plt.title("Total PnL")
    fig.autofmt_xdate()
    plt.show()


def deduce_orders(temp_limit_bid_order_list, temp_limit_ask_order_list, deal):
    # next_limit_bid_order_list next_limit_ask_order_list todo
    # bid 降序 ask 升序


    orders_list = list()

    if deal.side == OrderSide.SELL:

        unique_ask_prices = []
        for limit_ask_order in temp_limit_ask_order_list:
            if limit_ask_order.price not in unique_ask_prices:
                unique_ask_prices.append(limit_ask_order.price)

        if len(unique_ask_prices) > 0:
            # ask 最优价格下移, 假装成交后对无法继续成交的Limit order list没有影响
            if deal.price < unique_ask_prices[0]:
            
                limit_order = Order(symbol=deal.symbol,
                                    timestamp=deal.timestamp,
                                    order_type=OrderType.LIMIT,
                                    side=OrderSide.SELL,
                                    qty=deal.qty,
                                    price=deal.price,
                                    ownership=OrderOwnership.OTHERS,
                                    action=OrderAction.PLACE,
                                    bundle_id=state.get_bundle_id())
                setattr(limit_order, 'order_id', state.generate_order_id())
                orders_list.append(limit_order)
                
                market_order = Order(
                                    symbol=deal.symbol,
                                    timestamp=deal.timestamp,
                                    order_type=OrderType.MARKET,
                                    side=OrderSide.BUY,
                                    qty=deal.qty,
                                    price=0,
                                    ownership=OrderOwnership.OTHERS,
                                    action=OrderAction.PLACE,
                                    bundle_id=state.get_bundle_id())
                setattr(market_order, 'order_id', state.generate_order_id())
                orders_list.append(market_order)

                # # TODO 需要check倒挂逻辑
                # if deal.price <= temp_limit_bid_order_list[0].price:
                #     print("Mis pricing Bid Order")
                #     for bid_order in temp_limit_bid_order_list:
                #         if deal.price <= bid_order.price:
                #             get_order_id_counter(state.generate_order_id() + 1)
                #             cancel_order = Order(deal.timestamp, OrderType.CANCELLATION, Side.BUY,
                #                                  bid_order.qty, bid_order.price, bid_order.ownership, Sequence.THIS_FRAME_EARLY,
                #                                  True)
                #             setattr(cancel_order, 'order_id', state.generate_order_id())
                #             orders_list.append(cancel_order)
                #             temp_limit_bid_order_list.pop(0)
                #         else:
                #             break

            # ask 最优价格上行 则复杂
            elif deal.price > unique_ask_prices[0]:
                del_list = list()
                add_list = list()
                for j in range(len(unique_ask_prices)):
                    if deal.price > unique_ask_prices[j]:
                        if j < len(unique_ask_prices)-1:
                            for limit_ask in temp_limit_ask_order_list:
                                if limit_ask.price == unique_ask_prices[j]:
                                    
                                    cancel_order = Order(
                                                        symbol=deal.symbol,
                                                        timestamp=deal.timestamp,
                                                        order_type=OrderType.LIMIT,
                                                        side=OrderSide.SELL,
                                                        qty=limit_ask.qty,
                                                        price=limit_ask.price,
                                                        ownership=OrderOwnership.OTHERS,
                                                        action=OrderAction.CANCEL,
                                                        bundle_id=state.get_bundle_id())
                                    setattr(cancel_order, 'order_id', state.generate_order_id())
                                    orders_list.append(cancel_order)
                                    del_list.append(limit_ask)
                        else:
                            for limit_ask in temp_limit_ask_order_list:
                                if limit_ask.price == unique_ask_prices[j]:
                                    
                                    cancel_order = Order(symbol=deal.symbol,
                                                         timestamp=deal.timestamp, 
                                                         order_type=OrderType.LIMIT,
                                                         side=OrderSide.ASK,
                                                         qty=limit_ask.qty, 
                                                         price=limit_ask.price, 
                                                         ownership=OrderOwnership.OTHERS,
                                                         action=OrderAction.CANCEL,
                                                         bundle_id=state.get_bundle_id())
                                    setattr(cancel_order, 'order_id', state.generate_order_id())
                                    orders_list.append(cancel_order)
                                    del_list.append(limit_ask)
                                    
                                    limit_order = Order(symbol=deal.symbol,
                                                        timestamp=deal.timestamp, 
                                                        order_type=OrderType.LIMIT, 
                                                        side=OrderSide.ASK,
                                                        qty=deal.qty, 
                                                        price=deal.price, 
                                                        ownership=OrderOwnership.OTHERS,
                                                        action=OrderAction.PLACE,
                                                        bundle_id=state.get_bundle_id())
                                    setattr(limit_order, 'order_id', state.generate_order_id())
                                    orders_list.append(limit_order)
                                    
                                    market_order = Order(symbol=deal.symbol,
                                                         timestamp=deal.timestamp,
                                                         order_type=OrderType.MARKET, 
                                                         side=OrderSide.BUY,
                                                         qty=deal.qty, 
                                                         price=0, 
                                                         ownership=OrderOwnership.OTHERS,
                                                         action=OrderAction.PLACE,
                                                         bundle_id=state.get_bundle_id())
                                    setattr(market_order, 'order_id', state.generate_order_id())
                                    orders_list.append(market_order)
                    # 小于等于其实是一样的逻辑，而且只会2选1
                    elif deal.price == unique_ask_prices[j]:
                        for limit_ask in temp_limit_ask_order_list:
                            if limit_ask.price == unique_ask_prices[j]:
                                if deal.qty > limit_ask.qty:
                                    # 补多 limit order
                                    
                                    limit_order = Order(symbol=deal.symbol,
                                                        timestamp=deal.timestamp,
                                                        order_type=OrderType.LIMIT,
                                                        side=OrderSide.SELL,
                                                        qty=deal.qty - limit_ask.qty,
                                                        price=deal.price,
                                                        ownership=OrderOwnership.OTHERS,
                                                        action=OrderAction.PLACE,
                                                        bundle_id=state.get_bundle_id())
                                    setattr(limit_order, 'order_id', state.generate_order_id())
                                    orders_list.append(limit_order)
                                    
                                    market_order = Order(symbol=deal.symbol,
                                                         timestamp=deal.timestamp,
                                                         order_type=OrderType.MARKET,
                                                         side=OrderSide.BUY,
                                                         qty=deal.qty,
                                                         price=0,
                                                         ownership=OrderOwnership.OTHERS,
                                                         action=OrderAction.PLACE,
                                                         bundle_id=state.get_bundle_id())
                                    setattr(market_order, 'order_id', state.generate_order_id())
                                    orders_list.append(market_order)
                                    del_list.append(limit_ask)
                                elif deal.qty == limit_ask.qty:
                                    
                                    market_order = Order(symbol=deal.symbol,
                                                         timestamp=deal.timestamp,
                                                         order_type=OrderType.MARKET,
                                                         side=OrderSide.BUY,
                                                         qty=deal.qty,
                                                         price=0,
                                                         ownership=OrderOwnership.OTHERS,
                                                         action=OrderAction.PLACE,
                                                         bundle_id=state.get_bundle_id())
                                    setattr(market_order, 'order_id', state.generate_order_id())
                                    orders_list.append(market_order)
                                    del_list.append(limit_ask)
                                else:
                                    
                                    market_order = Order(symbol=deal.symbol,
                                                         timestamp=deal.timestamp,
                                                         order_type=OrderType.MARKET,
                                                         side=OrderSide.BUY,
                                                         qty=deal.qty,
                                                         price=0,
                                                         ownership=OrderOwnership.OTHERS,
                                                         action=OrderAction.PLACE,
                                                         bundle_id=state.get_bundle_id())
                                    setattr(market_order, 'order_id', state.generate_order_id())
                                    limit_ask.qty -= deal.qty
                                    orders_list.append(market_order)
                        break
                    else:
                        for limit_ask in temp_limit_ask_order_list:
                            if limit_ask.price == unique_ask_prices[j]:
                                # 补多 limit order
                                
                                limit_order = Order(symbol=deal.symbol,
                                                    timestamp=deal.timestamp,
                                                    order_type=OrderType.LIMIT,
                                                    side=OrderSide.SELL,
                                                    qty=deal.qty,
                                                    price=deal.price,
                                                    ownership=OrderOwnership.OTHERS,
                                                    action=OrderAction.PLACE,
                                                    bundle_id=state.get_bundle_id())
                                setattr(limit_order, 'order_id', state.generate_order_id())
                                orders_list.append(limit_order)
                                
                                market_order = Order(symbol=deal.symbol,
                                                     timestamp=deal.timestamp,
                                                     order_type=OrderType.MARKET,
                                                     side=OrderSide.BUY,
                                                     qty=deal.qty,
                                                     price=0,
                                                     ownership=OrderOwnership.OTHERS,
                                                     action=OrderAction.PLACE,
                                                     bundle_id=state.get_bundle_id())
                                setattr(market_order, 'order_id', state.generate_order_id())
                                orders_list.append(market_order)
                        break

                for item in temp_limit_ask_order_list:
                    if item not in del_list:
                        add_list.append(item)
                temp_limit_ask_order_list.clear()
                temp_limit_ask_order_list.extend(add_list)

            elif deal.price == unique_ask_prices[0]:
                # 找到已有的limit order
                del_list = list()
                add_list = list()
                for limit_ask in temp_limit_ask_order_list:
                    if limit_ask.price == deal.price:
                        if deal.qty > limit_ask.qty:
                            # 补多 limit order
                            
                            limit_order = Order(symbol=deal.symbol,
                                                timestamp=deal.timestamp,
                                                order_type=OrderType.LIMIT,
                                                side=OrderSide.SELL,
                                                qty=deal.qty - limit_ask.qty,
                                                price=deal.price,
                                                ownership=OrderOwnership.OTHERS,
                                                action=OrderAction.PLACE,
                                                bundle_id=state.get_bundle_id())
                            setattr(limit_order, 'order_id', state.generate_order_id())
                            orders_list.append(limit_order)
                            
                            market_order = Order(symbol=deal.symbol,
                                                 timestamp=deal.timestamp,
                                                 order_type=OrderType.MARKET,
                                                 side=OrderSide.BUY,
                                                 qty=deal.qty,
                                                 price=0,
                                                 ownership=OrderOwnership.OTHERS,
                                                 action=OrderAction.PLACE,
                                                 bundle_id=state.get_bundle_id())
                            setattr(market_order, 'order_id', state.generate_order_id())
                            orders_list.append(market_order)
                            del_list.append(limit_ask)
                        elif deal.qty == limit_ask.qty:
                            
                            market_order = Order(symbol=deal.symbol,
                                                 timestamp=deal.timestamp,
                                                 order_type=OrderType.MARKET,
                                                 side=OrderSide.BUY,
                                                 qty=deal.qty,
                                                 price=0,
                                                 ownership=OrderOwnership.OTHERS,
                                                 action=OrderAction.PLACE,
                                                 bundle_id=state.get_bundle_id())
                            setattr(market_order, 'order_id', state.generate_order_id())
                            orders_list.append(market_order)
                            del_list.append(limit_ask)
                        else:
                            
                            market_order = Order(symbol=deal.symbol,
                                                 timestamp=deal.timestamp,
                                                 order_type=OrderType.MARKET,
                                                 side=OrderSide.BUY,
                                                 qty=deal.qty,
                                                 price=0,
                                                 ownership=OrderOwnership.OTHERS,
                                                 action=OrderAction.PLACE,
                                                 bundle_id=state.get_bundle_id())
                            # update limit ask qty
                            limit_ask.qty -= deal.qty
                            setattr(market_order, 'order_id', state.generate_order_id())
                            orders_list.append(market_order)

                for item in temp_limit_ask_order_list:
                    if item not in del_list:
                        add_list.append(item)
                temp_limit_ask_order_list.clear()
                temp_limit_ask_order_list.extend(add_list)


    elif deal.side == OrderSide.BUY:

        unique_bid_prices = []
        for limit_bid_order in temp_limit_bid_order_list:
            if limit_bid_order.price not in unique_bid_prices:
                unique_bid_prices.append(limit_bid_order.price)

        if len(unique_bid_prices) > 0:

            # bid 最优价格上移, 假装成交后对无法继续成交的Limit order list没有影响
            if deal.price > unique_bid_prices[0]:
                
                limit_order = Order(symbol=deal.symbol,
                                    timestamp=deal.timestamp,
                                    order_type=OrderType.LIMIT,
                                    side=OrderSide.BUY,
                                    qty=deal.qty,
                                    price=deal.price,
                                    ownership=OrderOwnership.OTHERS,
                                    action=OrderAction.PLACE,
                                    bundle_id=state.get_bundle_id())
                setattr(limit_order, 'order_id', state.generate_order_id())
                orders_list.append(limit_order)
                
                market_order = Order(symbol=deal.symbol,
                                     timestamp=deal.timestamp,
                                     order_type=OrderType.MARKET,
                                     side=OrderSide.SELL,
                                     qty=deal.qty,
                                     price=0,
                                     ownership=OrderOwnership.OTHERS,
                                     action=OrderAction.PLACE,
                                     bundle_id=state.get_bundle_id())
                setattr(market_order, 'order_id', state.generate_order_id())
                orders_list.append(market_order)

                # # TODO 需要check倒挂逻辑
                # if deal.price >= temp_limit_ask_order_list[0].price:
                #     print("Mis pricing Ask Order")
                #     for ask_order in temp_limit_ask_order_list:
                #         if deal.price >= ask_order.price:
                #             get_order_id_counter(state.generate_order_id() + 1)
                #             cancel_order = Order(deal.timestamp, OrderType.CANCELLATION, Side.SELL,
                #                                  ask_order.qty, ask_order.price, ask_order.ownership,
                #                                  Sequence.THIS_FRAME_EARLY, True)
                #             setattr(cancel_order, 'order_id', state.generate_order_id())
                #             orders_list.append(cancel_order)
                #             temp_limit_ask_order_list.pop(0)
                #         else:
                #             break

            # bid 最优价格下行 则复杂
            elif deal.price < unique_bid_prices[0]:
                del_list = list()
                add_list = list()
                for j in range(len(unique_bid_prices)):
                    if deal.price < unique_bid_prices[j]:
                        if j < len(unique_bid_prices) - 1:
                            for limit_bid in temp_limit_bid_order_list:
                                if limit_bid.price == unique_bid_prices[j]:
                                    
                                    # cancel_order = Order(deal.timestamp,
                                    #                      OrderType.CANCELLATION, Side.BUY,
                                    #                      limit_bid.qty, limit_bid.price, OrderOwnership.OTHERS,
                                    #                      Sequence.THIS_FRAME_EARLY, True)
                                    cancel_order = Order(symbol=deal.symbol,
                                                        timestamp=deal.timestamp,
                                                        order_type=OrderType.LIMIT,
                                                        side=OrderSide.BUY,
                                                        qty=limit_bid.qty,
                                                        price=limit_bid.price,
                                                        ownership=OrderOwnership.OTHERS,
                                                        action=OrderAction.CANCEL,
                                                        bundle_id=state.get_bundle_id())
                                    setattr(cancel_order, 'order_id', state.generate_order_id())
                                    orders_list.append(cancel_order)
                                    # temp_limit_bid_order_list.pop(0)
                                    del_list.append(limit_bid)
                        else:
                            for limit_bid in temp_limit_bid_order_list:
                                if limit_bid.price == unique_bid_prices[j]:
                                    
                                    cancel_order = Order(symbol=deal.symbol,
                                                         timestamp=deal.timestamp,
                                                         order_type=OrderType.LIMIT, 
                                                         side=OrderSide.BID,
                                                         qty=limit_bid.qty, 
                                                         price=limit_bid.price, 
                                                         ownership=OrderOwnership.OTHERS,
                                                         action=OrderAction.CANCEL,
                                                         bundle_id=state.get_bundle_id())
                                    setattr(cancel_order, 'order_id', state.generate_order_id())
                                    orders_list.append(cancel_order)
                                    del_list.append(limit_bid)
                                    
                                    limit_order = Order(symbol=deal.symbol,
                                                        timestamp=deal.timestamp,
                                                        order_type=OrderType.LIMIT, 
                                                        side=OrderSide.BID,
                                                        qty=deal.qty, 
                                                        price=deal.price,
                                                        ownership=OrderOwnership.OTHERS,
                                                        action=OrderAction.PLACE,
                                                        bundle_id=state.get_bundle_id())
                                    setattr(limit_order, 'order_id', state.generate_order_id())
                                    orders_list.append(limit_order)
                                    
                                    market_order = Order(symbol=deal.symbol,
                                                         timestamp=deal.timestamp,
                                                         order_type=OrderType.MARKET, 
                                                         side=OrderSide.SELL,
                                                         qty=deal.qty, 
                                                         price=0, 
                                                         ownership=OrderOwnership.OTHERS,
                                                         action=OrderAction.PLACE,
                                                         bundle_id=state.get_bundle_id())
                                    setattr(market_order, 'order_id', state.generate_order_id())
                                    orders_list.append(market_order)
                    # 小于等于其实是一样的逻辑，而且只会2选1
                    elif deal.price == unique_bid_prices[j]:
                        for limit_bid in temp_limit_bid_order_list:
                            if limit_bid.price == unique_bid_prices[j]:
                                if deal.qty > limit_bid.qty:
                                    # 补多 limit order
                                    
                                    limit_order = Order(symbol=deal.symbol,
                                                        timestamp=deal.timestamp,
                                                        order_type=OrderType.LIMIT,
                                                        side=OrderSide.BUY,
                                                        qty=deal.qty - limit_bid.qty,
                                                        price=deal.price,
                                                        ownership=OrderOwnership.OTHERS,
                                                        action=OrderAction.PLACE,
                                                        bundle_id=state.get_bundle_id())
                                    setattr(limit_order, 'order_id', state.generate_order_id())
                                    orders_list.append(limit_order)
                                    
                                    market_order = Order(symbol=deal.symbol,
                                                         timestamp=deal.timestamp,
                                                         order_type=OrderType.MARKET,
                                                         side=OrderSide.SELL,
                                                         qty=deal.qty,
                                                         price=0,
                                                         ownership=OrderOwnership.OTHERS,
                                                         action=OrderAction.PLACE,
                                                         bundle_id=state.get_bundle_id())
                                    setattr(market_order, 'order_id', state.generate_order_id())
                                    orders_list.append(market_order)
                                    del_list.append(limit_bid)
                                elif deal.qty == limit_bid.qty:
                                    
                                    market_order = Order(symbol=deal.symbol,
                                                         timestamp=deal.timestamp,
                                                         order_type=OrderType.MARKET,
                                                         side=OrderSide.SELL,
                                                         qty=deal.qty,
                                                         price=0,
                                                         ownership=OrderOwnership.OTHERS,
                                                         action=OrderAction.PLACE,
                                                         bundle_id=state.get_bundle_id())
                                    setattr(market_order, 'order_id', state.generate_order_id())
                                    orders_list.append(market_order)
                                    del_list.append(limit_bid)
                                else:
                                    
                                    market_order = Order(symbol=deal.symbol,
                                                         timestamp=deal.timestamp,
                                                         order_type=OrderType.MARKET,
                                                         side=OrderSide.SELL,
                                                         qty=deal.qty,
                                                         price=0,
                                                         ownership=OrderOwnership.OTHERS,
                                                         action=OrderAction.PLACE,
                                                         bundle_id=state.get_bundle_id())
                                    # update limit bid qty
                                    limit_bid.qty -= deal.qty
                                    setattr(market_order, 'order_id', state.generate_order_id())
                                    orders_list.append(market_order)
                        break
                    else:
                        for limit_bid in temp_limit_bid_order_list:
                            if limit_bid.price == unique_bid_prices[j]:
                                # 补多 limit order
                                
                                limit_order = Order(symbol=deal.symbol,
                                                    timestamp=deal.timestamp,
                                                    order_type=OrderType.LIMIT,
                                                    side=OrderSide.BUY,
                                                    qty=deal.qty,
                                                    price=deal.price,
                                                    ownership=OrderOwnership.OTHERS,
                                                    action=OrderAction.PLACE,
                                                    bundle_id=state.get_bundle_id())
                                setattr(limit_order, 'order_id', state.generate_order_id())
                                orders_list.append(limit_order)
                                
                                market_order = Order(symbol=deal.symbol,
                                                     timestamp=deal.timestamp,
                                                     order_type=OrderType.MARKET,
                                                     side=OrderSide.SELL,
                                                     qty=deal.qty,
                                                     price=0,
                                                     ownership=OrderOwnership.OTHERS,
                                                     action=OrderAction.PLACE,
                                                     bundle_id=state.get_bundle_id())
                                setattr(market_order, 'order_id', state.generate_order_id())
                                orders_list.append(market_order)
                        break

                for item in temp_limit_bid_order_list:
                    if item not in del_list:
                        add_list.append(item)
                temp_limit_bid_order_list.clear()
                temp_limit_bid_order_list.extend(add_list)

            elif deal.price == unique_bid_prices[0]:
                # 找到已有的limit order
                del_list = list()
                add_list = list()
                for limit_bid in temp_limit_bid_order_list:
                    if limit_bid.price == deal.price:
                        if deal.qty > limit_bid.qty:
                            # 补多 limit order
                            
                            limit_order = Order(symbol=deal.symbol,
                                                timestamp=deal.timestamp,
                                                order_type=OrderType.LIMIT,
                                                side=OrderSide.BUY,
                                                qty=deal.qty - limit_bid.qty,
                                                price=deal.price,
                                                ownership=OrderOwnership.OTHERS,
                                                action=OrderAction.PLACE,
                                                bundle_id=state.get_bundle_id())
                            setattr(limit_order, 'order_id', state.generate_order_id())
                            orders_list.append(limit_order)
                            
                            market_order = Order(symbol=deal.symbol,
                                                 timestamp=deal.timestamp,
                                                 order_type=OrderType.MARKET,
                                                 side=OrderSide.SELL,
                                                 qty=deal.qty,
                                                 price=0,
                                                 ownership=OrderOwnership.OTHERS,
                                                 action=OrderAction.PLACE,
                                                 bundle_id=state.get_bundle_id())
                            setattr(market_order, 'order_id', state.generate_order_id())
                            orders_list.append(market_order)
                            del_list.append(limit_bid)
                        elif deal.qty == limit_bid.qty:
                            
                            market_order = Order(symbol=deal.symbol,
                                                 timestamp=deal.timestamp,
                                                 order_type=OrderType.MARKET,
                                                 side=OrderSide.SELL,
                                                 qty=deal.qty,
                                                 price=0,
                                                 ownership=OrderOwnership.OTHERS,
                                                 action=OrderAction.PLACE,
                                                 bundle_id=state.get_bundle_id())
                            setattr(market_order, 'order_id', state.generate_order_id())
                            orders_list.append(market_order)
                            del_list.append(limit_bid)
                        else:
                            
                            market_order = Order(symbol=deal.symbol,
                                                 timestamp=deal.timestamp,
                                                 order_type=OrderType.MARKET,
                                                 side=OrderSide.SELL,
                                                 qty=deal.qty,
                                                 price=0,
                                                 ownership=OrderOwnership.OTHERS,
                                                 action=OrderAction.PLACE,
                                                 bundle_id=state.get_bundle_id())
                            setattr(market_order, 'order_id', state.generate_order_id())
                            # update limit bid qty
                            limit_bid.qty -= deal.qty
                            orders_list.append(market_order)

                for item in temp_limit_bid_order_list:
                    if item not in del_list:
                        add_list.append(item)
                temp_limit_bid_order_list.clear()
                temp_limit_bid_order_list.extend(add_list)

    return orders_list, temp_limit_bid_order_list, temp_limit_ask_order_list


def process_clobs(temp_limit_bid_order_list, temp_limit_ask_order_list, next_clob):
    orders_list = list()

    # current_clob timestamp doesn't matter
    current_clob = limit_orders_to_clob(temp_limit_bid_order_list, temp_limit_ask_order_list, next_clob.timestamp, next_clob.symbol)

    for j in range(len(current_clob.p_ask_array)):
        if current_clob.p_ask_array[j] not in next_clob.p_ask_array:
            
            cancel_order = Order(symbol=next_clob.symbol,
                                 timestamp=next_clob.timestamp, 
                                 order_type=OrderType.LIMIT,
                                 side=OrderSide.ASK,
                                 qty=current_clob.q_ask_array[j],
                                 price=current_clob.p_ask_array[j], 
                                 ownership=OrderOwnership.OTHERS,
                                 action=OrderAction.CANCEL,
                                 bundle_id=state.get_bundle_id())
            setattr(cancel_order, 'order_id', state.generate_order_id())
            orders_list.append(cancel_order)
        else:
            continue

    # 对比ask
    for j in range(len(next_clob.p_ask_array)):
        if next_clob.p_ask_array[j] not in current_clob.p_ask_array:
            
            limit_order = Order(symbol=next_clob.symbol,
                                timestamp=next_clob.timestamp, 
                                order_type=OrderType.LIMIT, 
                                side=OrderSide.ASK,
                                qty=next_clob.q_ask_array[j], 
                                price=next_clob.p_ask_array[j],
                                ownership=OrderOwnership.OTHERS, 
                                action=OrderAction.PLACE,
                                bundle_id=state.get_bundle_id())
            setattr(limit_order, 'order_id', state.generate_order_id())
            orders_list.append(limit_order)
        else:
            for i in range(len(current_clob.p_ask_array)):
                if current_clob.p_ask_array[i] == next_clob.p_ask_array[j]:
                    # 变少了
                    if current_clob.q_ask_array[i] > next_clob.q_ask_array[j]:
                        
                        cancel_order = Order(symbol=next_clob.symbol,
                                             timestamp=next_clob.timestamp, 
                                             order_type=OrderType.LIMIT,
                                             side=OrderSide.ASK,
                                             qty=current_clob.q_ask_array[i] - next_clob.q_ask_array[j],
                                             price=current_clob.p_ask_array[i], 
                                             ownership=OrderOwnership.OTHERS,
                                             action=OrderAction.PLACE,
                                             bundle_id=state.get_bundle_id())
                        setattr(cancel_order, 'order_id', state.generate_order_id())
                        orders_list.append(cancel_order)
                    # 变多了
                    elif current_clob.q_ask_array[i] < next_clob.q_ask_array[j]:
                        
                        limit_order = Order(symbol=next_clob.symbol,
                                            timestamp=next_clob.timestamp, 
                                            order_type=OrderType.LIMIT, 
                                            side=OrderSide.ASK,
                                            qty=next_clob.q_ask_array[j] - current_clob.q_ask_array[i],
                                            price=current_clob.p_ask_array[i], 
                                            ownership=OrderOwnership.OTHERS,
                                            action=OrderAction.PLACE,
                                            bundle_id=state.get_bundle_id())
                        setattr(limit_order, 'order_id', state.generate_order_id())
                        orders_list.append(limit_order)
                else:
                    continue

    for j in range(len(current_clob.p_bid_array)):
        if current_clob.p_bid_array[j] not in next_clob.p_bid_array:
            
            cancel_order = Order(symbol=next_clob.symbol,
                                 timestamp=next_clob.timestamp, 
                                 order_type=OrderType.LIMIT,
                                 side=OrderSide.BID,
                                 qty=current_clob.q_bid_array[j],
                                 price=current_clob.p_bid_array[j], 
                                 ownership=OrderOwnership.OTHERS,
                                 action=OrderAction.CANCEL,
                                 bundle_id=state.get_bundle_id())
            setattr(cancel_order, 'order_id', state.generate_order_id())
            orders_list.append(cancel_order)
        else:
            continue

    # 对比bid
    for j in range(len(next_clob.p_bid_array)):
        if next_clob.p_bid_array[j] not in current_clob.p_bid_array:
            
            limit_order = Order(symbol=next_clob.symbol,
                                timestamp=next_clob.timestamp, 
                                order_type=OrderType.LIMIT, 
                                side=OrderSide.BID,
                                qty=next_clob.q_bid_array[j], 
                                price=next_clob.p_bid_array[j],
                                ownership=OrderOwnership.OTHERS,
                                action=OrderAction.PLACE,
                                bundle_id=state.get_bundle_id())
            setattr(limit_order, 'order_id', state.generate_order_id())
            orders_list.append(limit_order)
        else:
            for i in range(len(current_clob.p_bid_array)):
                if current_clob.p_bid_array[i] == next_clob.p_bid_array[j]:
                    # 变少了
                    if current_clob.q_bid_array[i] > next_clob.q_bid_array[j]:
                        
                        cancel_order = Order(symbol=next_clob.symbol,
                                             timestamp=next_clob.timestamp, 
                                             order_type=OrderType.LIMIT,
                                             side=OrderSide.BID,
                                             qty=current_clob.q_bid_array[i] - next_clob.q_bid_array[j],
                                             price=current_clob.p_bid_array[i], 
                                             ownership=OrderOwnership.OTHERS,
                                             action=OrderAction.CANCEL,
                                             bundle_id=state.get_bundle_id())
                        setattr(cancel_order, 'order_id', state.generate_order_id())
                        orders_list.append(cancel_order)
                    # 变多了
                    elif current_clob.q_bid_array[i] < next_clob.q_bid_array[j]:
                        
                        limit_order = Order(symbol=next_clob.symbol,
                                            timestamp=next_clob.timestamp, 
                                            order_type=OrderType.LIMIT, 
                                            side=OrderSide.BID,
                                            qty=next_clob.q_bid_array[j] - current_clob.q_bid_array[i],
                                            price=current_clob.p_bid_array[i], 
                                            ownership=OrderOwnership.OTHERS,
                                            action=OrderAction.PLACE,
                                            bundle_id=state.get_bundle_id())
                        setattr(limit_order, 'order_id', state.generate_order_id())
                        orders_list.append(limit_order)
                else:
                    continue

    return orders_list
