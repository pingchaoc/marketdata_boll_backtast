# -*- coding: utf-8 -*-
"""
@author: QuantInfoTech
"""
import logging


class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


fmt_color = {
    logging.NOTSET: bcolors.OKBLUE,
    logging.DEBUG: bcolors.OKBLUE,
    logging.INFO: bcolors.OKGREEN,
    logging.WARNING: bcolors.WARNING,
    logging.ERROR: bcolors.FAIL,
    logging.CRITICAL: bcolors.FAIL,
}


def get_debug_fmt(levelno):
    lvlcolor = fmt_color[levelno]
    return bcolors.HEADER + \
        '[%(asctime)s][%(name)s]' + bcolors.ENDC + lvlcolor +\
        '(%(levelname)s)' + bcolors.ENDC +\
        '<%(funcName)s:%(lineno)d>:\n' + lvlcolor +\
        '%(message)s' + bcolors.ENDC


class ColoredDebugFormatter(logging.Formatter):

    def __init__(self):
        super().__init__(fmt="%(levelno)d: %(msg)s", datefmt=None, style='%')

    def set_format(self, levelno):
        self._style._fmt = get_debug_fmt(levelno)

    def format(self, record):

        # Save the original format configured by the user
        # when the logger formatter was instantiated
        format_orig = self._style._fmt

        # Replace the original format with one customized by logging level
        self.set_format(record.levelno)

        # Call the original formatter class to do the grunt work
        result = logging.Formatter.format(self, record)

        # Restore the original format configured by the user
        self._style._fmt = format_orig

        return result


class ColoredVerboseFormatter(ColoredDebugFormatter):

    def set_format(self, levelno):
        self._style._fmt = '[%(asctime)s][pid:%(process)d][%(name)s](%(levelname)s)<line:%(lineno)d> at (%(pathname)s)<%(funcName)s>: %(message)s'
