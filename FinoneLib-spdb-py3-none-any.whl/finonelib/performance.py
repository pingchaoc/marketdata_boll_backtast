# -*- coding: utf-8 -*-
"""
@author: QuantInfoTech
"""

from typeguard import typechecked
from finonelib.structs import *
from finonelib.utils import vwap, get_time_range_by_time_type
import logging
import datetime
import bisect

from dateutil.relativedelta import relativedelta

logger = logging.getLogger(__name__)

class PerformanceInfo(object):

    @typechecked
    def __init__(self, symbol: str):
        from finonelib.state import state
        self.symbol = symbol
        self.orders = []
        self.id_execution_mapper = {} # {market_order_id: Execution} ACCEPTED ONLY
        self.marketdata = []
        self.clobs = []
        self.executions = []

        self._last_timestamp = 0
        self._inventory = 0
        self._trade_volume = 0

        self.ts_inventory = {}

        self.cash = 0
        self.realized_pnl = 0.0
        self.floating_pnl = 0
        self.floating_cash = 0

        self.reporting_cash = 0
        self.reporting_realized_pnl = 0.0
        self.reporting_floating_pnl = 0
        self.reporting_floating_cash = 0

        self.ts_pnl = {}
        self.ts_realized_pnl = {}
        self.ts_floating_pnl = {}

        self.ts_reporting_pnl = {}
        self.ts_reporting_realized_pnl = {}
        self.ts_reporting_floating_pnl = {}

        
        self.average_cost = 0

        self.total_commission = 0.0
        self.metadata = state.get_metadata_by_symbol(symbol)

    @property
    def trade_volume(self):
        return self._trade_volume

    @trade_volume.setter
    def trade_volume(self, x):
        self._trade_volume = x

    @property
    def inventory(self):
        return self._inventory

    @inventory.setter
    def inventory(self, x):
        self.ts_inventory[self.last_timestamp] = x
        self._inventory = x

    @property
    def last_timestamp(self):
        return self._last_timestamp

    @last_timestamp.setter
    def last_timestamp(self, x):
        self._last_timestamp = x
    
    def calculate_commission(self, execution: Execution):
        commission = 0.0
        if self.metadata and self.metadata.commission_rate:
            commission = execution.qty * execution.price * self.metadata.commission_rate
            self.total_commission += commission
        return commission


class ReportingCurrencyConvertor(object):

    def __init__(self, symbol):
        from finonelib.state import state
        self.symbol = symbol
        self.ccy1, self.ccy2, self.pair = self.symbol2ccys(self.symbol)
        self.can_report = True
        self.reporting_ccy = state.settings.REPORTING_CURRENCY
        self.reporting_price = {}
    
    def symbol2ccys(self, symbol):
        from finonelib.state import state
        from finonelib.methods import form_fx_pair
        metadata = state.get_metadata_by_symbol(symbol)
        if metadata.asset_class == 'FX':
            ccy1 = metadata.display_name[:3]
            ccy2 = metadata.display_name[3:]
            return form_fx_pair(ccy1, ccy2)
        else:
            ccy1 = metadata.pricing_currency
            ccy2 = self.reporting_ccy
            return form_fx_pair(ccy1, ccy2)

    def get_market_price(self, ts, ccy1, ccy2):
        if ccy1 == ccy2:
            return 1, 1
        # mock function
        # 这里要查历史数据，所以不用管逻辑，先返回CCY1CCY2的固定bid_price, ask_pricee
        from finonelib.methods import form_fx_pair
        from finonelib.state import state
        _, _, pair = form_fx_pair(ccy1, ccy2)
        price_list = state.all_pairs_price[pair]
        if price_list:
            bid_tss = price_list[0]

            if pair in self.reporting_price:
                prev_status = self.reporting_price[pair]
                last_final_index = prev_status[0]
                last_ts = prev_status[1]
                if last_final_index + 2 < len(bid_tss):
                    if ts == last_ts:
                        return prev_status[2], prev_status[3]
                    if ts < bid_tss[last_final_index + 1]:
                        return prev_status[2], prev_status[3]
                    elif ts < bid_tss[last_final_index + 2]:
                        bid_price = price_list[1][last_final_index + 1]
                        metadata = state.get_metadata_by_symbol(pair)
                        ask_price = bid_price + round(metadata.spread * metadata.price_change_unit, state.get_precision_by_symbol(pair))
                        self.reporting_price[pair] = [last_final_index+1, ts, bid_price, ask_price]
                        return bid_price, ask_price
                    else:
                        index = bisect.bisect_left(bid_tss, ts)
                        if ts in bid_tss:
                            final_index = index
                        else:
                            final_index = index - 1

                        if final_index == -1:
                            final_index = 0
                        
                        bid_price = price_list[1][final_index]
                        metadata = state.get_metadata_by_symbol(pair)
                        ask_price = bid_price + round(metadata.spread * metadata.price_change_unit, state.get_precision_by_symbol(pair))
                        self.reporting_price[pair] = [final_index, ts, bid_price, ask_price]            
                        return bid_price, ask_price
                else:
                    index = bisect.bisect_left(bid_tss, ts)
                    if ts in bid_tss:
                        final_index = index
                    else:
                        final_index = index - 1

                    if final_index == -1:
                        final_index = 0
                    
                    bid_price = price_list[1][final_index]
                    metadata = state.get_metadata_by_symbol(pair)
                    ask_price = bid_price + round(metadata.spread * metadata.price_change_unit, state.get_precision_by_symbol(pair))
                    self.reporting_price[pair] = [final_index, ts, bid_price, ask_price]
                    return bid_price, ask_price    
            else:
                index = bisect.bisect_left(bid_tss, ts)
                if ts in bid_tss:
                    final_index = index
                else:
                    final_index = index - 1

                if final_index == -1:
                    final_index = 0
                
                bid_price = price_list[1][final_index]
                metadata = state.get_metadata_by_symbol(pair)
                ask_price = bid_price + round(metadata.spread * metadata.price_change_unit, state.get_precision_by_symbol(pair))
                self.reporting_price[pair] = [final_index, ts, bid_price, ask_price]
                return bid_price, ask_price

        logger.warn('get_market_price return None reporting result maybe error!!!')

    def to_reporting_pnl(self, symbol, timestamp, one_pnl, reporting_currecy):
        from finonelib.methods import form_fx_pair
        # symbol = execution.symbol
        # timestamp = execution.timestamp
        _, pricing_currency, _ = form_fx_pair(symbol[:3], symbol[3:])

        if pricing_currency==reporting_currecy:
            return one_pnl
        else:
            if one_pnl>0:
                front, back, symbol = form_fx_pair(pricing_currency, reporting_currecy)
                if reporting_currecy==front:
                    transformed_one_pnl=one_pnl*self.get_market_price(timestamp,pricing_currency,reporting_currecy)[0]
                    return transformed_one_pnl
                elif reporting_currecy==back:
                    transformed_one_pnl=one_pnl/self.get_market_price(timestamp,reporting_currecy,pricing_currency)[1]
                    return transformed_one_pnl
                else:
                    logger.warn('form_fx_pair maybe error!')

            elif one_pnl<0:
                front, back, symbol = form_fx_pair(pricing_currency, reporting_currecy)
                if reporting_currecy==front:
                    transformed_one_pnl=one_pnl*self.get_market_price(timestamp,pricing_currency,reporting_currecy)[1]
                    return transformed_one_pnl
                elif reporting_currecy==back:
                    transformed_one_pnl=one_pnl/self.get_market_price(timestamp,reporting_currecy,pricing_currency)[0]
                    return transformed_one_pnl
                else:
                    logger.warn('form_fx_pair maybe error!')
            else:
                return 0


class PerformanceCalculator(object):
    PRECISION = 6

    def __init__(self, strategy_indicator=False):
        self.strategy_indicator = strategy_indicator
        self.infos = {}
        self.reporting_currency_convertor = {}
        self.dbg_infos = {}
    
    def init_infos(self, symbols):
        for symbol in symbols:
            self.infos[symbol] = PerformanceInfo(symbol)
            self.dbg_infos[symbol] = []

    def init_convertors(self, symbols):
        for symbol in symbols:
            self.reporting_currency_convertor[symbol] = ReportingCurrencyConvertor(symbol)

    def once_pnl(self, qty, clob):
        if qty > 0:
            vwap_price = vwap(clob.q_bid_array, clob.p_bid_array)
            return round(vwap_price * qty, self.PRECISION)
        else:
            vwap_price = vwap(clob.q_ask_array, clob.p_ask_array)
            return round(vwap_price * qty, self.PRECISION)


    def update_marketdata(self, marketdata: ClobData):
        """这个方法只接受发给策略的clob，而不是所有match出来的clob"""
        from finonelib.state import state
        info = self.infos[marketdata.symbol]
        if marketdata.timestamp < info.last_timestamp:
            raise Exception('wrong timestamp')
        info.last_timestamp = marketdata.timestamp
        info.marketdata.append(marketdata)

        info.floating_cash = self.once_pnl(info.inventory, info.marketdata[-1])
        info.ts_pnl[marketdata.timestamp] = info.cash + info.floating_cash

        info.floating_pnl = round(info.floating_cash - info.average_cost * info.inventory, self.PRECISION)

        if state.settings.REPORTING_CURRENCY and marketdata.symbol in self.reporting_currency_convertor:
            info.reporting_cash = self.reporting_currency_convertor[marketdata.symbol].to_reporting_pnl(
                symbol=marketdata.symbol, 
                timestamp=marketdata.timestamp, 
                one_pnl=info.cash, 
                reporting_currecy=state.settings.REPORTING_CURRENCY
            )
            info.reporting_floating_cash = self.reporting_currency_convertor[marketdata.symbol].to_reporting_pnl(
                symbol=marketdata.symbol, 
                timestamp=marketdata.timestamp, 
                one_pnl=info.floating_cash, 
                reporting_currecy=state.settings.REPORTING_CURRENCY
            )
            info.ts_reporting_pnl[marketdata.timestamp] = self.reporting_currency_convertor[marketdata.symbol].to_reporting_pnl(
                symbol=marketdata.symbol, 
                timestamp=marketdata.timestamp, 
                one_pnl=info.cash + info.floating_cash, 
                reporting_currecy=state.settings.REPORTING_CURRENCY
            )
            # info.reporting_realized_pnl = self.reporting_currency_convertor[execution.symbol].to_reporting_pnl(
            #     symbol=execution.symbol, 
            #     timestamp=execution.timestamp, 
            #     one_pnl=realized_pnl, 
            #     reporting_currecy=state.settings.REPORTING_CURRENCY
            # )

            info.reporting_floating_pnl = self.reporting_currency_convertor[marketdata.symbol].to_reporting_pnl(
                symbol=marketdata.symbol, 
                timestamp=marketdata.timestamp, 
                one_pnl=info.floating_pnl, 
                reporting_currecy=state.settings.REPORTING_CURRENCY
            )
            info.ts_reporting_floating_pnl[marketdata.timestamp] = info.reporting_floating_pnl 

    def update_clob(self, clob: ClobData):
        """与update_marketdata不同的是这个方法接受全部match出来的clob"""
        info = self.infos[clob.symbol]
        # 这里也不更新last_timestamp，进存储所有clob用来计算最佳报价
        info.clobs.append(clob)

    def update_execution(self, execution: Execution):
        from finonelib.state import state
        if execution.ownership == OrderOwnership.STRATEGY:
            if not execution.symbol in self.infos:
                self.infos[execution.symbol] = PerformanceInfo(execution.symbol)
            info = self.infos[execution.symbol]
            if execution.timestamp < info.last_timestamp:
                raise Exception('wrong timestamp')
            info.last_timestamp = execution.timestamp
            info.executions.append(execution)
            # execution status.. do next
            if execution.status == ExecutionStatus.ACCEPTED:
                info.id_execution_mapper[execution.order_id] = {
                    'enter': execution,
                    'exits': [],
                    'cancelled': False
                }
            elif execution.status == ExecutionStatus.FILLED_FULLY:
                info.trade_volume += execution.qty
                qty = execution.qty if execution.side == OrderSide.BID else -execution.qty
                commission = info.calculate_commission(execution)
                info.cash = info.cash - qty * execution.price - commission
                original_inventory = info.inventory
                info.inventory += qty
                info.floating_cash = self.once_pnl(info.inventory, info.marketdata[-1])
                if info.average_cost:
                    if (original_inventory + qty):
                        info.average_cost =  round((info.average_cost * original_inventory + qty * execution.price) / (original_inventory + qty), self.PRECISION)
                    else:
                        info.average_cost = 0
                    info.realized_pnl = round(info.cash + info.average_cost * info.inventory, self.PRECISION)
                    info.ts_realized_pnl[execution.timestamp] = info.realized_pnl
                else:
                    info.average_cost = execution.price
                info.floating_pnl = round(info.floating_cash - info.average_cost * info.inventory, self.PRECISION)
                info.ts_floating_pnl[execution.timestamp] = info.floating_pnl
                
                info.ts_pnl[execution.timestamp] = info.cash + info.floating_cash
                if state.settings.REPORTING_CURRENCY and execution.symbol in self.reporting_currency_convertor:
                    info.reporting_cash = self.reporting_currency_convertor[execution.symbol].to_reporting_pnl(
                        symbol=execution.symbol, 
                        timestamp=execution.timestamp, 
                        one_pnl=info.cash, 
                        reporting_currecy=state.settings.REPORTING_CURRENCY
                    )
                    info.reporting_floating_cash = self.reporting_currency_convertor[execution.symbol].to_reporting_pnl(
                        symbol=execution.symbol, 
                        timestamp=execution.timestamp, 
                        one_pnl=info.floating_cash, 
                        reporting_currecy=state.settings.REPORTING_CURRENCY
                    )
                    info.ts_reporting_pnl[execution.timestamp] = self.reporting_currency_convertor[execution.symbol].to_reporting_pnl(
                        symbol=execution.symbol, 
                        timestamp=execution.timestamp, 
                        one_pnl=info.cash + info.floating_cash, 
                        reporting_currecy=state.settings.REPORTING_CURRENCY
                    )
                    info.reporting_realized_pnl = self.reporting_currency_convertor[execution.symbol].to_reporting_pnl(
                        symbol=execution.symbol, 
                        timestamp=execution.timestamp, 
                        one_pnl=info.realized_pnl, 
                        reporting_currecy=state.settings.REPORTING_CURRENCY
                    )
                    info.ts_reporting_realized_pnl[execution.timestamp] = info.reporting_realized_pnl
                    info.reporting_floating_pnl = self.reporting_currency_convertor[execution.symbol].to_reporting_pnl(
                        symbol=execution.symbol, 
                        timestamp=execution.timestamp, 
                        one_pnl=info.floating_pnl, 
                        reporting_currecy=state.settings.REPORTING_CURRENCY
                    )
                    info.ts_reporting_floating_pnl[execution.timestamp] = info.reporting_floating_pnl

                info.id_execution_mapper[execution.order_id]['exits'].append(execution)
            elif execution.status == ExecutionStatus.FILLED_PARTIALLY:
                info.trade_volume += execution.qty
                qty = execution.qty if execution.side == OrderSide.BID else -execution.qty
                commission = info.calculate_commission(execution)
                info.cash = info.cash - qty * execution.price - commission
                original_inventory = info.inventory
                info.inventory += qty
                info.floating_cash = self.once_pnl(info.inventory, info.marketdata[-1])
                if info.average_cost:
                    if (original_inventory + qty):
                        info.average_cost =  round((info.average_cost * original_inventory + qty * execution.price) / (original_inventory + qty), self.PRECISION)
                    else:
                        info.average_cost = 0
                    info.realized_pnl = round(info.cash + info.average_cost * info.inventory, self.PRECISION)
                    info.ts_realized_pnl[execution.timestamp] = info.realized_pnl
                else:
                    info.average_cost = execution.price
                info.floating_pnl = round(info.floating_cash - info.average_cost * info.inventory, self.PRECISION)
                info.ts_floating_pnl[execution.timestamp] = info.floating_pnl

                info.ts_pnl[execution.timestamp] = info.cash + info.floating_cash

                if state.settings.REPORTING_CURRENCY and execution.symbol in self.reporting_currency_convertor:
                    info.reporting_cash = self.reporting_currency_convertor[execution.symbol].to_reporting_pnl(
                        symbol=execution.symbol, 
                        timestamp=execution.timestamp, 
                        one_pnl=info.cash, 
                        reporting_currecy=state.settings.REPORTING_CURRENCY
                    )
                    info.reporting_floating_cash = self.reporting_currency_convertor[execution.symbol].to_reporting_pnl(
                        symbol=execution.symbol, 
                        timestamp=execution.timestamp, 
                        one_pnl=info.floating_cash, 
                        reporting_currecy=state.settings.REPORTING_CURRENCY
                    )
                    info.ts_reporting_pnl[execution.timestamp] = self.reporting_currency_convertor[execution.symbol].to_reporting_pnl(
                        symbol=execution.symbol, 
                        timestamp=execution.timestamp, 
                        one_pnl=info.cash + info.floating_cash, 
                        reporting_currecy=state.settings.REPORTING_CURRENCY
                    )
                    info.reporting_realized_pnl = self.reporting_currency_convertor[execution.symbol].to_reporting_pnl(
                        symbol=execution.symbol, 
                        timestamp=execution.timestamp, 
                        one_pnl=info.realized_pnl, 
                        reporting_currecy=state.settings.REPORTING_CURRENCY
                    )
                    info.ts_reporting_realized_pnl[execution.timestamp] = info.reporting_realized_pnl
                    info.reporting_floating_pnl = self.reporting_currency_convertor[execution.symbol].to_reporting_pnl(
                        symbol=execution.symbol, 
                        timestamp=execution.timestamp, 
                        one_pnl=info.floating_pnl, 
                        reporting_currecy=state.settings.REPORTING_CURRENCY
                    )
                    info.ts_reporting_floating_pnl[execution.timestamp] = info.reporting_floating_pnl

                info.id_execution_mapper[execution.order_id]['exits'].append(execution)
            elif execution.status == ExecutionStatus.CANCELLED:
                info.id_execution_mapper[execution.order_id]['cancelled'] = True

    def latest_repository(self, symbol):
        from finonelib.state import state
        info = self.infos[symbol]
        repository = Repository(info.last_timestamp,
                                symbol,
                                round(info.cash + info.floating_cash, 6),
                                info.inventory,
                                info.cash,
                                info.reporting_cash,
                                round(info.reporting_realized_pnl + info.reporting_floating_pnl, 6))
        return repository

    def get_strategy_performance(self, symbol):
        info = self.infos[symbol]
        performance = {}
        # 损益指标  (要有total)
        performance['mm_total_revenue'] = 0  # 累计收益
        performance['floating_pnl'] = 0  # 浮动损益
        performance['realized_pnl'] = 0  # 平仓损益
        performance['mm_annualized_return'] = 0  # 年化收益
        performance['max_pnl_timepoint'] = None  # 最大收益出现时刻

        # 回撤统计  (要有total)
        performance['mm_maximum_retracement_value'] = 0  # 最大回撤
        performance['mm_maximum_retracement_time'] =  0  # 最大回撤时长
        performance['max_draw_down_start_time'] = None  # 最大回撤比较点
        performance['max_draw_down_end_time'] = None  # 最大回撤时间点
        performance['mm_return_retracement_ratio'] = 0  # 收益回测比
         
        # 成交统计
        performance['transaction_order_rate'] = 0  # 成交量比例(成交交易报价比率)
        performance['total_volume'] = 0  # 总交易量（总成交量）
        performance['average_volume'] = 0  # 平均每颗粒度成交量
        performance['total_transactions'] = 0  # 总交易次数
        performance['average_transactions'] = 0  # 平均交易次数
        performance['transaction_success_rate'] = 0  # 交易成功率
        performance['best_order_rate'] = 0  # 最佳报单比例
        performance['submit_orders_times'] = 0 # 总保单次数
        performance['submit_orders_volume'] = 0 # 总报单量
        performance['avg_bar_volume'] = 0 # 平均每颗粒度报单量
        

        # 持仓统计
        # performance['mm_historical_maximum_holding'] = None  # 历史最大持仓
        # performance['mm_historical_maximum_holding_time'] = None  # 最大持仓时长
        performance['mm_historical_average_holding'] = 0  # 历史平均持仓
        performance['mm_historical_average_holding_time'] = 0  # 平均持仓时长
        performance['long_max'] = 0  # 历史最大多仓  
        performance['long_max_timestamp'] = None  # 历史最大多仓时间
        performance['short_max'] = 0  # 历史最大空仓
        performance['short_max_timestamp'] = None # 历史最大空仓时间

        if not info.ts_pnl:
            # 代表没有成交过
            return performance
        holding_durations = self.get_holding_durations(info)
        max_draw_down, max_draw_down_duration, max_draw_down_start_time, max_draw_down_end_time = self.get_max_drawdown_and_duration(info)

        # 损益指标   
        performance['mm_total_revenue'] = self.get_total_revenue(info)  # 累计收益
        performance['floating_pnl'] = self.get_floating_pnl(info)  # 浮动损益
        performance['realized_pnl'] = self.get_realized_pnl(info)  # 平仓损益
        performance['mm_annualized_return'] = self.get_annualized_return(info)  # 年化收益
        performance['max_pnl_timepoint'] = self.get_max_pnl_timepoint(info)  # 最大收益出现时刻

        # 回撤统计   (要有total)
        performance['mm_maximum_retracement_value'] = max_draw_down  # 最大回撤
        performance['mm_maximum_retracement_time'] = max_draw_down_duration  # 最大回撤时长
        performance['max_draw_down_start_time'] = max_draw_down_start_time # 最大回撤比较点
        performance['max_draw_down_end_time'] = max_draw_down_end_time  # 最大回撤时间点
        performance['mm_return_retracement_ratio'] = self.get_return_drawdown_ratio(self.get_total_revenue(info), max_draw_down)  # 收益回测比

        # 成交统计
        performance['transaction_order_rate'] = self.get_trade_vol_over_quote_vol(info)  # 成交量比例(成交交易报价比率)
        performance['total_volume'] = self.get_total_volume(info)  # 总交易量（总成交量）
        performance['average_volume'] = self.get_average_volume(info)  # 平均每颗粒度成交量
        performance['total_transactions'] = self.get_total_transactions(info)  # 总交易次数
        performance['average_transactions'] = self.get_average_transactions(info)  # 平均交易次数
        performance['transaction_success_rate'] = self.get_transaction_success_rate(info)  # 交易成功率
        performance['best_order_rate'] = self.get_best_order_rate(info)  # 最佳报单比例
        # 总保单次数
        # 总报单量
        # 平均每颗粒度报单量
        performance['submit_orders_volume'], performance['submit_orders_times'], performance['avg_bar_volume'] = self.get_submit_orders_info(info) 


        # 持仓统计
        # performance['mm_historical_maximum_holding'] = self.get_max_holding(info)  # 历史最大持仓
        # performance['mm_historical_maximum_holding_time'] = self.get_max_holding_duration(holding_durations)  # 最大持仓时长
        performance['mm_historical_average_holding'] = self.get_avg_holding(info)   # 历史平均持仓
        performance['mm_historical_average_holding_time'] = self.get_avg_holding_duration(holding_durations)  # 平均持仓时长
        performance['long_max'], performance['long_max_timestamp'] = self.get_long_max(info) # 历史最大多仓  历史最大多仓时间
        performance['short_max'], performance['short_max_timestamp'] = self.get_short_max(info)  # 历史最大空仓  历史最大空仓时间


        # 历史遗留
        performance['average_transactions_per_second'] = self.get_average_transactions_per_second(info) # 平均每秒交易次数
        performance['average_volume_per_min'] = self.get_average_volume_per_min(info)  # 平均每分钟成交量
        return performance
    
    def get_strategy_reporting_performance(self, symbol):
        info = self.infos[symbol]
        performance = {}

        # 损益指标   reporting_currency
        performance['mm_total_revenue'] = 0  # 累计收益
        performance['floating_pnl'] = 0  # 浮动损益
        performance['realized_pnl'] = 0  # 平仓损益
        performance['mm_annualized_return'] = 0  # 年化收益
        performance['max_pnl_timepoint'] = None  # 最大收益出现时刻

        # 回撤统计  reporting_currency  (要有total)
        performance['mm_maximum_retracement_value'] = 0  # 最大回撤
        performance['mm_maximum_retracement_time'] =  0  # 最大回撤时长
        performance['max_draw_down_start_time'] = None  # 最大回撤比较点
        performance['max_draw_down_end_time'] = None  # 最大回撤时间点
        performance['mm_return_retracement_ratio'] = 0  # 收益回测比

        # 成交统计
        performance['transaction_order_rate'] = 0  # 成交量比例(成交交易报价比率)
        performance['total_volume'] = 0  # 总交易量（总成交量）
        performance['average_volume'] = 0  # 平均每颗粒度成交量
        performance['total_transactions'] = 0  # 总交易次数
        performance['average_transactions'] = 0  # 平均交易次数
        performance['transaction_success_rate'] = 0  # 交易成功率
        performance['best_order_rate'] = 0  # 最佳报单比例
        performance['submit_orders_times'] = 0 # 总保单次数
        performance['submit_orders_volume'] = 0 # 总报单量
        performance['avg_bar_volume'] = 0 # 平均每颗粒度报单量
        

        # 持仓统计
        # performance['mm_historical_maximum_holding'] = None  # 历史最大持仓
        # performance['mm_historical_maximum_holding_time'] = None  # 最大持仓时长
        performance['mm_historical_average_holding'] = 0  # 历史平均持仓
        performance['mm_historical_average_holding_time'] = 0  # 平均持仓时长
        performance['long_max'] = 0  # 历史最大多仓  
        performance['long_max_timestamp'] = None  # 历史最大多仓时间
        performance['short_max'] = 0  # 历史最大空仓
        performance['short_max_timestamp'] = None # 历史最大空仓时间
        
        if not info.ts_pnl:
            # 代表没有成交过
            return performance
        holding_durations = self.get_holding_durations(info)
        max_draw_down_reporting, max_draw_down_duration_reporting, max_draw_down_start_time_reporting, max_draw_down_end_time_reporting = self.get_max_drawdown_and_duration(info, reporting=True)

        # 损益指标   reporting_currency  (要有total)
        performance['mm_total_revenue'] = self.get_total_revenue_reporting(info)  # 累计收益
        performance['floating_pnl'] = self.get_floating_pnl_reporting(info)  # 浮动损益
        performance['realized_pnl'] = self.get_realized_pnl_reporting(info) # 平仓损益
        performance['mm_annualized_return'] = self.get_annualized_return_reporting(info)  # 年化收益
        performance['max_pnl_timepoint'] = self.get_max_pnl_timepoint_reporting(info)  # 最大收益出现时刻

        # 回撤统计   reporting_currency  (要有total)
        performance['mm_maximum_retracement_value'] = max_draw_down_reporting  # 最大回撤
        performance['mm_maximum_retracement_time'] = max_draw_down_duration_reporting  # 最大回撤时长
        performance['max_draw_down_start_time'] = max_draw_down_start_time_reporting # 最大回撤比较点
        performance['max_draw_down_end_time'] = max_draw_down_end_time_reporting  # 最大回撤时间点
        performance['mm_return_retracement_ratio'] = self.get_return_drawdown_ratio(self.get_total_revenue_reporting(info), max_draw_down_reporting)  # 收益回测比

        # 成交统计
        performance['transaction_order_rate'] = self.get_trade_vol_over_quote_vol(info)  # 成交量比例(成交交易报价比率)
        performance['total_volume'] = self.get_total_volume(info)  # 总交易量（总成交量）
        performance['average_volume'] = self.get_average_volume(info)  # 平均每颗粒度成交量
        performance['total_transactions'] = self.get_total_transactions(info)  # 总交易次数
        performance['average_transactions'] = self.get_average_transactions(info)  # 平均交易次数
        performance['transaction_success_rate'] = self.get_transaction_success_rate(info)  # 交易成功率
        performance['best_order_rate'] = self.get_best_order_rate(info)  # 最佳报单比例
        # 总保单次数
        # 总报单量
        # 平均每颗粒度报单量
        performance['submit_orders_volume'], performance['submit_orders_times'], performance['avg_bar_volume'] = self.get_submit_orders_info(info) 


        # 持仓统计
        # performance['mm_historical_maximum_holding'] = self.get_max_holding(info)  # 历史最大持仓
        # performance['mm_historical_maximum_holding_time'] = self.get_max_holding_duration(holding_durations)  # 最大持仓时长
        performance['mm_historical_average_holding'] = self.get_avg_holding(info)   # 历史平均持仓
        performance['mm_historical_average_holding_time'] = self.get_avg_holding_duration(holding_durations)  # 平均持仓时长
        performance['long_max'], performance['long_max_timestamp'] = self.get_long_max(info) # 历史最大多仓  历史最大多仓时间
        performance['short_max'], performance['short_max_timestamp'] = self.get_short_max(info)  # 历史最大空仓  历史最大空仓时间


        return performance

    def get_strategy_total_performance(self):
        #  暂时放在这里, 只能最后调用 回测过程中调用 可能计算出来的值是不对的
        from finonelib.state import state
        infos = list(self.infos.values())
        performance = {}

        performance['mm_total_revenue'] = 0  # 累计收益
        performance['floating_pnl'] = 0  # 浮动损益
        performance['realized_pnl'] = 0  # 平仓损益
        performance['mm_annualized_return'] = 0  # 年化收益
        performance['max_pnl_timepoint'] = None  # 最大收益出现时刻

        # 回撤统计  reporting_currency  (要有total)
        performance['mm_maximum_retracement_value'] = 0  # 最大回撤
        performance['mm_maximum_retracement_time'] =  0  # 最大回撤时长
        performance['max_draw_down_start_time'] = None  # 最大回撤比较点
        performance['max_draw_down_end_time'] = None  # 最大回撤时间点
        performance['mm_return_retracement_ratio'] = 0  # 收益回测比

        if infos:
            # 损益指标   reporting_currency  (要有total)
            performance['mm_total_revenue'] = sum([self.get_total_revenue_reporting(info) for info in infos])  # 累计收益
            performance['floating_pnl'] = sum([self.get_floating_pnl_reporting(info) for info in infos])  # 浮动损益
            performance['realized_pnl'] = sum([self.get_realized_pnl_reporting(info) for info in infos]) # 平仓损益
            performance['mm_annualized_return'] = self.get_annualized_return_total_reporting()  # 年化收益
            performance['max_pnl_timepoint'] = self.get_max_pnl_timepoint_total_reporting()  # 最大收益出现时刻


            max_draw_down, max_draw_down_duration, max_draw_down_start_time, max_draw_down_end_time = self.get_max_drawdown_and_duration(infos[0], total=True)
            # 回撤统计   reporting_currency  (要有total)
            performance['mm_maximum_retracement_value'] = max_draw_down  # 最大回撤
            performance['mm_maximum_retracement_time'] = max_draw_down_duration  # 最大回撤时长
            performance['max_draw_down_start_time'] = max_draw_down_start_time # 最大回撤比较点
            performance['max_draw_down_end_time'] = max_draw_down_end_time  # 最大回撤时间点
            performance['mm_return_retracement_ratio'] = self.get_return_drawdown_ratio(list(state.total_pnl.values())[-1], max_draw_down)  # 收益回测比
        
        return performance
    
    ########################   LP Performance   ########################

    def get_submit_orders_info(self, info):
        """总报单量　报单次数　平均每颗粒度报单量"""
        from finonelib.state import state

        submit_orders_times = 0
        submit_orders_volume = 0.0
        for execution in info.executions:
            submit_orders_times += 1
            submit_orders_volume += execution.qty
        time_range = info.marketdata[-1].timestamp - info.marketdata[0].timestamp
        if not time_range:
            avg_bar_volume = 0.0
        else:
            time_type = state.settings['SYMBOL_TIME_TYPE'][info.symbol]
            bar_num = time_range / get_time_range_by_time_type(time_type)
            avg_bar_volume = round(submit_orders_volume/bar_num, self.PRECISION)
        return submit_orders_volume, submit_orders_times, avg_bar_volume

    def get_annualized_return_total_reporting(self):
        # 年化收益
        from finonelib.state import state
        val = 0.0
        time_list = list(state.total_pnl.keys())
        pnl_list = list(state.total_pnl.values())
        if len(time_list) > 0:
            time_range = time_list[-1] - time_list[0]
            if time_range:
                msec_yearly = 260 * 8 * 60 * 60 * 1000
                val = round(pnl_list[-1] * msec_yearly / time_range, 6)
        return val

    def get_max_pnl_timepoint_total_reporting(self):
        from finonelib.state import state
        if state.total_pnl:
            max_pnl = list(state.total_pnl.values())[0]
            max_pnl_ts  = list(state.total_pnl.keys())[0]
            for ts, pnl in state.total_pnl.items():
                if pnl > max_pnl:
                    max_pnl = pnl
                    max_pnl_ts = ts
            return max_pnl_ts
        else:
            return None

    def get_max_holding(self, info):
        """最大持仓"""
        acc_inventory = list(info.ts_inventory.values())
        return round(max([abs(x) for x in acc_inventory] + [0]), 6)

    def get_avg_holding(self, info):
        """平均持仓"""
        acc_inventory = list(info.ts_inventory.values())
        return round(sum([abs(x) for x in acc_inventory] + [0]) / max([len(acc_inventory), 1]), 6)

    def get_holding_durations(self, info):
        """全部持仓时间段"""
        holding_durations = []
        holding_start = 0
        last_inventory = None
        for ts, inventory in info.ts_inventory.items():
            if last_inventory is None:
                last_inventory = inventory
                if inventory:
                    holding_start = ts
            elif inventory * last_inventory <= 0:
                if holding_start:
                    holding_durations.append((holding_start, ts))
                    holding_start = 0
                    if inventory != 0:
                        holding_start = ts
                else:
                    holding_start = ts
        if holding_start:
            holding_durations.append((holding_start, ts))
            holding_start = 0
        holding_durations = [end - start for start, end in holding_durations]
        return holding_durations

    def get_max_holding_duration(self, holding_durations):
        """最大持仓时间"""
        return max(holding_durations + [0])

    def get_avg_holding_duration(self, holding_durations):
        """平均持仓时间"""
        return sum(holding_durations + [0]) / max(len(holding_durations), 1)

    def get_trade_vol_over_quote_vol(self, info):
        """成交量比例"""
        quote_vol = sum([e.qty for e in info.executions if e.status == ExecutionStatus.ACCEPTED] + [0])
        return round(info.trade_volume / max(quote_vol, 1), 6)

    def get_max_drawdown_and_duration(self, info, years=None, reporting=False, total=False):
        """最大回撤/最大回撤时长"""
        if total:
            from finonelib.state import state
            ts_pnl_pairs = sorted(list(state.total_pnl.items()), key=lambda x:x[0])
        else:
            if reporting:
                ts_pnl_pairs = sorted(list(info.ts_reporting_pnl.items()), key=lambda x:x[0])
            else:
                ts_pnl_pairs = sorted(list(info.ts_pnl.items()), key=lambda x:x[0])

        timestamps = [x[0] for x in ts_pnl_pairs]
        pnls = [x[1] for x in ts_pnl_pairs]
        if years:
            current_timestamp = timestamps[-1]
            current_pnl = pnls[-1]
            current_time = datetime.datetime.fromtimestamp(current_timestamp/1000)
            pre_time = current_time - relativedelta(years=years)
            pre_timestamp = pre_time.timestamp() * 1000
            timestamps = [x for x in timestamps if x >= pre_timestamp]
            pnls = pnls[:len(timestamps)]

        max_pnl = max(pnls)
        min_pnl = min(pnls)
        max_pnl_index = pnls.index(max_pnl)
        min_pnl_index = pnls.index(min_pnl)
        try:
            max_before_min_pnl = max(pnls[:min_pnl_index])
            max_before_min_pnl_index = pnls[:min_pnl_index].index(max_before_min_pnl)
        except ValueError as e:
            max_before_min_pnl = min_pnl
            max_before_min_pnl_index = min_pnl_index
        try:
            min_after_max_pnl = min(pnls[max_pnl_index:])
            min_after_max_pnl_index = -(pnls[:max_pnl_index-1:-1].index(min_after_max_pnl) + 1)
        except ValueError as e:
            min_after_max_pnl = max_pnl
            min_after_max_pnl_index = max_pnl_index
        if max_pnl - min_after_max_pnl > max_before_min_pnl - min_pnl:
            max_draw_down = max_pnl - min_after_max_pnl
            max_draw_down_duration = timestamps[min_after_max_pnl_index] - timestamps[max_pnl_index]
            start_ts = timestamps[max_pnl_index]
            end_ts = timestamps[min_after_max_pnl_index]
        else:
            max_draw_down = max_before_min_pnl - min_pnl
            max_draw_down_duration = timestamps[min_pnl_index] - timestamps[max_before_min_pnl_index]
            start_ts = timestamps[max_before_min_pnl_index]
            end_ts = timestamps[min_pnl_index]

        return round(max_draw_down, 6), max_draw_down_duration, start_ts, end_ts

    def get_total_revenue(self, info):
        """累计收益"""
        return round(info.cash + info.floating_cash, 6)

    def get_total_revenue_reporting(self, info):
        """累计收益  reporting currency"""
        return round(info.reporting_cash + info.reporting_floating_cash, 6)

    def get_annualized_return(self, info):
        """年化收益"""
        time_range = info.clobs[-1].timestamp - info.clobs[0].timestamp
        if not time_range:
            return 0.0
        msec_yearly = 260 * 8 * 60 * 60 * 1000
        return round((info.cash + info.floating_cash) * msec_yearly / time_range, 6)

    def get_annualized_return_reporting(self, info):
        """年化收益"""
        time_range = info.clobs[-1].timestamp - info.clobs[0].timestamp
        if not time_range:
            return 0.0
        msec_yearly = 260 * 8 * 60 * 60 * 1000
        return round((info.reporting_cash + info.reporting_floating_cash) * msec_yearly / time_range, 6)

    def get_return_drawdown_ratio(self, pnl, max_draw_down):
        """收益回撤比"""
        if not max_draw_down:
            return 0.0
        return round(pnl / max_draw_down, 6)

    def get_total_transactions(self, info):
        """总交易次数， 只记全部成交"""
        return len([x for x in info.executions if x.status == ExecutionStatus.FILLED_FULLY])

    def get_average_transactions_per_second(self, info):
        """每秒平均交易次数"""
        time_range = info.clobs[-1].timestamp - info.clobs[0].timestamp
        if not time_range:
            return 0.0
        return round(self.get_total_transactions(info) / (time_range / 1000), 2)

    def get_transaction_success_rate(self, info):
        """交易成功率"""
        fully = len([x for x in info.executions if x.status == ExecutionStatus.FILLED_FULLY])
        accepted = len([x for x in info.executions if x.status == ExecutionStatus.ACCEPTED])
        if not accepted:
            return 0.0
        return round(fully / accepted, 6)


    def get_best_order_rate(self, info):
        """最佳报价比例"""
        accepted_executions = [e for e in info.executions if e.status == ExecutionStatus.ACCEPTED]
        clob_index = 1
        best_order = 0
        for execution in accepted_executions:
            while clob_index < len(info.clobs):
                if info.clobs[clob_index].timestamp > execution.timestamp:
                    break
                else:
                    clob_index += 1
            clob = info.clobs[clob_index-1]
            if execution.side == OrderSide.BID:
                clob_price = clob.p_bid_array[0] if clob.p_bid_array else 0.0
            else:
                clob_price = clob.p_ask_array[0] if clob.p_ask_array else 0.0
            if round(execution.price, 6) == round(clob_price, 6):
                best_order += 1
        return round(best_order / max((len(accepted_executions), 1)), 6)


    def get_total_volume(self, info):
        """总成交量"""
        return info.trade_volume


    def get_average_volume_per_min(self, info):
        """平均每分钟成交量"""
        time_range = info.clobs[-1].timestamp - info.clobs[0].timestamp
        if not time_range:
            return 0.0
        return round(info.trade_volume / (time_range / 1000 / 60), 6)

    #####################   LP Performance  End   ######################

    
    def get_floating_pnl(self, info):
        """浮动损益"""
        return info.floating_pnl

    def get_floating_pnl_reporting(self, info):
        """浮动损益 reporting_currency"""
        return round(info.reporting_floating_pnl, 6)

    def get_realized_pnl(self, info):
        """平仓损益"""
        return info.realized_pnl

    def get_realized_pnl_reporting(self, info):
        """平仓损益 reporting_currency"""
        return round(info.reporting_realized_pnl, 6)
    
    def get_long_max(self, info):
        """历史最大多仓 历史最大多仓时间"""
        inventory = 0
        long_max = None
        long_max_timestamp = None
        for execution in info.executions:
            qty = execution.qty if execution.side == OrderSide.BID else -execution.qty
            inventory += qty
            if inventory > 0:
                if long_max is None:
                    long_max = inventory
                    long_max_timestamp = execution.timestamp
                elif long_max < inventory:
                    long_max = inventory
                    long_max_timestamp = execution.timestamp
        return long_max, long_max_timestamp

    def get_short_max(self, info):
        """历史最大空仓 历史最大空仓时间"""
        inventory = 0
        short_max = None
        short_max_timestamp = None
        for execution in info.executions:
            qty = execution.qty if execution.side == OrderSide.BID else -execution.qty
            inventory += qty
            if inventory < 0:
                if short_max is None:
                    short_max = inventory
                    short_max_timestamp = execution.timestamp
                elif short_max > inventory:
                    short_max = inventory
                    short_max_timestamp = execution.timestamp
        return short_max, short_max_timestamp


    def get_max_pnl_timepoint(self, info):
        """最大收益出现时间点"""
        max_pnl = list(info.ts_pnl.values())[0]
        max_pnl_ts  = list(info.ts_pnl.keys())[0]
        for ts, pnl in info.ts_pnl.items():
            if pnl > max_pnl:
                max_pnl = pnl
                max_pnl_ts = ts
        return max_pnl_ts

    def get_max_pnl_timepoint_reporting(self, info):
        """最大收益出现时间点  reporting_currency"""
        max_pnl = list(info.ts_reporting_pnl.values())[0]
        max_pnl_ts  = list(info.ts_reporting_pnl.keys())[0]
        for ts, pnl in info.ts_reporting_pnl.items():
            if pnl > max_pnl:
                max_pnl = pnl
                max_pnl_ts = ts
        return max_pnl_ts

    def get_average_transactions(self, info):
        """每颗粒度平均交易次数"""
        from finonelib.state import state
        time_type = state.settings['SYMBOL_TIME_TYPE'][info.symbol]
        time_range = info.clobs[-1].timestamp - info.clobs[0].timestamp        
        if not time_range:
            return 0.0
        num = time_range/ get_time_range_by_time_type(time_type)
        return round(self.get_total_transactions(info) / num, 2)

    def get_average_volume(self, info):
        """平均每颗粒度成交量"""
        from finonelib.state import state
        time_type = state.settings['SYMBOL_TIME_TYPE'][info.symbol]
        time_range = info.clobs[-1].timestamp - info.clobs[0].timestamp
        if not time_range:
            return 0.0
        num = time_range / get_time_range_by_time_type(time_type)
        return round(info.trade_volume / num, 6)


    ########################   LC Performance   ########################

    # 1086  资金使用率  capital_usage, 总开仓时间/总回测时间比值
    # 1087  开平仓胜率  win ratio ：统计每个开平仓次数中获利的， 除以总开平仓次数
    # 1099  统计开平仓次数
    # 1105  统计记录平均每年开平仓次数
    # 1101  统计策略单笔交易收益与交易费比值
    # 1094  最大单笔交易亏损       统计策略最大单笔亏损值
    # 1095  统计策略亏损最大五笔交易亏损情况
    # 1104  统计记录平均每笔交易时长
    # 1100  统计策略单笔交易平均收益

    # 1090  最大回撤   xup注: 同上面那个
    # 1093  最大回撤时长           统计策略最大回撤发生的时间跨度     xup注: 同上面那个
    # 1102  总收益  xup注: 同上面那个
    

    # 1088  最新两年内损益回撤比    统计最新两年的 损益(pnl)/回撤(max drawdown)
    # 1089  损益回撤比            计算策略总损益回撤比 损益(pnl)/回撤(max draw down)
    def get_pnl_retracement_ratio(self, info, years=None):
        ts_pnl_pairs = sorted(list(info.ts_pnl.items()), key=lambda x:x[0])
        timestamps = [x[0] for x in ts_pnl_pairs]
        pnls = [x[1] for x in ts_pnl_pairs]
        if timestamps:
            max_draw_down = self.get_max_drawdown_and_duration(info, 2)[0]
            if years is None:
                return round(pnls[-1] / max_draw_down, 6)
            else:
                current_timestamp = timestamps[-1]
                current_pnl = pnls[-1]
                current_time = datetime.datetime.fromtimestamp(current_timestamp/1000)
                pre_time = current_time - relativedelta(years=years)
                pre_timestamp = pre_time.timestamp() * 1000
                pre_pnl = 0
                for index, ts in enumerate(timestamps):
                    if ts > pre_timestamp:
                        break
                    pre_pnl = pnls[index]
                real_pnl = current_pnl - pre_pnl
                return round(real_pnl/max_draw_down, 6)
        else:
            return 0


    # 1091  六个月累计亏损最大值    计算策略损益最差六个月的累计亏损情况
    # 1092  一个月累计亏损最大值    统计策略最差一个月累计亏损值
    def get_acc_loss_maximum(self, info, month=1):
        ts_pnl_pairs = sorted(list(info.ts_pnl.items()), key=lambda x:x[0])
        timestamps = [x[0] for x in ts_pnl_pairs]
        pnls = [x[1] for x in ts_pnl_pairs]
        
        if timestamps:
            # 取每天最后一个点
            tmp_timestamps = []
            tmp_pnls = []
            start_date = datetime.datetime.fromtimestamp(timestamps[0]/1000).date()
            for index, ts in enumerate(timestamps):
                last_daily_ts = ts
                if datetime.datetime.fromtimestamp(ts/1000).date() != start_date:
                    tmp_timestamps.append(last_daily_ts)
                    tmp_pnls.append(pnls[index])
                    start_date = datetime.datetime.fromtimestamp(ts/1000).date()
            tmp_timestamps.append(last_daily_ts)
            tmp_pnls.append(pnls[index])

            timestamps = tmp_timestamps
            pnls = tmp_pnls
            timestamps.reverse()
            pnls.reverse()

            max_loss = 0
            pre_timestamp = None
            current_pnl = None
            for index, ts in enumerate(timestamps):
                current_time = datetime.datetime.fromtimestamp(ts/1000)
                current_pnl = pnls[index]
                pre_time = current_time - relativedelta(months=month)
                pre_timestamp = pre_time.timestamp() * 1000
                pre_pnl = pnls[0] if pnls else 0
                for tmp_index, tmp_ts in enumerate(timestamps):
                    pre_pnl = pnls[tmp_index]
                    if tmp_ts < pre_timestamp:
                        break
                max_loss = min([current_pnl - pre_pnl, max_loss])
            return round(max_loss, 6)
        else:
            return 0

    # 1096  统计过去两年平均年收益
    # 1097  统计策略过去一年年化收益
    # 1098  统计平均年华收益
    def get_annualized_income(self, info, years=None):
        msec_yearly = 260 * 8 * 60 * 60 * 1000
        if years is None:
            time_range = info.clobs[-1].timestamp - info.clobs[0].timestamp
            if not time_range:
                return 0.0
            return round((info.cash + info.floating_cash) * msec_yearly / time_range, 6)
        else:
            ts_pnl_pairs = sorted(list(info.ts_pnl.items()), key=lambda x:x[0])
            timestamps = [x[0] for x in ts_pnl_pairs]
            pnls = [x[1] for x in ts_pnl_pairs]
            
            if  timestamps:
                current_timestamp = timestamps[-1]
                current_time = datetime.datetime.fromtimestamp(current_timestamp/1000)
                current_pnl = pnls[-1]
                pre_time = current_time - relativedelta(years=years)
                pre_timestamp = pre_time.timestamp() * 1000
                pre_pnl = 0
                real_pre_timestamp = pre_timestamp
                for index, ts in enumerate(timestamps):
                    pre_pnl = pnls[index]
                    real_pre_timestamp = ts
                    if ts > pre_timestamp:
                        break
            
                pnl = current_pnl - pre_pnl
                return round(pnl * msec_yearly / (current_timestamp - real_pre_timestamp), 6)
            else:
                return 0

    
    # 1103  统计记录回测时长(时间开度)
    def get_backtest_time_range(self):
        from finonelib.state import state
        return state.settings.END_TIME - state.settings.START_TIME

    #####################   LC Performance  End   ######################
