
if __name__ == '__main__':
    from finonelib import license
    import sys
    if len(sys.argv) > 1:
        license.make_license(int(sys.argv[1]))
