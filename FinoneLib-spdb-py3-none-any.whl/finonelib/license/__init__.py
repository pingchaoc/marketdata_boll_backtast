def validate_license():
    import finonelib
    import ctypes
    path = f'{finonelib.__path__[0]}/license/license.so'
    lib = ctypes.CDLL(path)
    class GoString(ctypes.Structure):
        _fields_ = [("p", ctypes.c_char_p), ("n", ctypes.c_longlong)]
    lib.validate_license.argtypes = [GoString]
    text = bytes(finonelib.__path__[0], encoding='utf-8')
    gs = GoString(text, len(text))
    return bool(lib.validate_license(gs))

def make_license(days):
    import finonelib
    import ctypes
    path = f'{finonelib.__path__[0]}/license/license.so'
    lib = ctypes.CDLL(path)
    class GoString(ctypes.Structure):
        _fields_ = [("p", ctypes.c_char_p), ("n", ctypes.c_longlong)]
    lib.make_license.argtypes = [GoString]
    text = bytes(finonelib.__path__[0], encoding='utf-8')
    gs = GoString(text, len(text))
    lib.make_license(gs, days)

